Formalisation and proofs of ORAMs, including Simple ORAM and Path ORAM.

This repository is the artifact accompanying the paper submission.

## Checking the proofs

The proofs are mechanised in [EasyCrypt](https://www.easycrypt.info/).
Successful completion of either method below verifies that every `.ec`
file in `proofs/` type-checks and that all lemmas are discharged (no
`admit`s remain). A summary is written to `report.log`.

### Option 1: Docker (recommended)

Runs the proofs inside the official EasyCrypt container image, which
ships EasyCrypt and all required SMT provers pre-installed. The only
requirement on the host is Docker.

    make docker-check

The image is `ghcr.io/easycrypt/ec-test-box:r2026.03` and is pulled
automatically on first run.

**Parallelism.** By default a single EasyCrypt job is run at a time
(`JOBS=1`). This is the safe setting: higher values spawn that many
SMT solver calls in parallel, which contend for CPU and memory and can
push some queries past their internal timeout, causing spurious proof
failures. To speed things up on a machine with headroom, override on
the command line, e.g. `make docker-check JOBS=4`.

**macOS note.** The image is published for `linux/amd64` only. On Apple
Silicon it therefore runs under emulation, which is noticeably slower.
Without Rosetta, SMT solver calls are likely to hit their internal
timeouts and some proofs will fail to check even though they are
correct. Enabling Rosetta-based emulation is strongly recommended:

- *Docker Desktop*: Settings → General → *Use Rosetta for x86_64/amd64
  emulation*.
- *Colima*: ensure `~/.colima/default/colima.yaml` contains

        vmType: vz
        rosetta: true

    then restart Colima (`colima stop && colima start`, or via
    `brew services` if applicable).

### Option 2: Native EasyCrypt

Requires a local EasyCrypt installation together with the provers
pinned in [`easycrypt.project`](easycrypt.project) (currently Alt-Ergo
2.6 and Z3 4.13). Then, from the repository root:

    make

Generated `.eco` files can be removed with `make clean`.

## File structure

- `proofs/common/`
  - `Aux.ec`: auxiliary lemmas
  - `Chernoff.ec`: chernoff bound
  - `Derivative.ec`: foundations for limitation, convergence and derivative
  - `ORAM.ec`: basic definitions for tree-based oram
  - `RAM.ec`: the behavior of a normal ram
- `proofs/pathoram/`
  - `Assign.ec`: the implementation of a tricky step in PathORAM: split the stash into a list of nodes
  - `PathORAM.ec`: basic definitions and lemmas of path oram
  - `PathCorrectness.ec`: proof of the functional equivalence between pathoram and ram
  - `PathObliviousness.ec`: obliviousness (security) abstraction and proof
  - `TopLevel.ec`: top level statements and proofs
- `proofs/simpleoram/`
  - `Abstracting.ec`: the equivalence between concrete simple oram formalization and abstractions
  - `Bound.ec`: the proof for the overall bound
  - `DartGame.ec`: bound analysis of dart game, which the analysis of the internal nodes will be reduced to
  - `Internal.ec`: abstraction game for analyzing the overflow at internal nodes
  - `Leaf.ec`: abstraction game for analyzing the overflow at leaves
  - `Obliviousness.ec`: obliviousness (security) abstraction and proofs
  - `SimpleORAM.ec`: basic definitions and lemmas of simple oram
  - `TopLevel.ec`: top level statements and proofs
