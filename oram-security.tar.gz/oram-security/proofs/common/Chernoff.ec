(* -------------------------------------------------------------------- *)
require import AllCore List Ring StdRing StdOrder RealSeries RealExp.
require import StdBigop.
require import Distr DBool DList.
require import Derivative.
require import IntDiv.

import RField RealOrder Bigint Bigreal.
import Finite Biased.

require import Aux.

(* -------------------------------------------------------------------- *)
lemma idfun_compL ['a 'b] (f : 'a -> 'b) : idfun \o f = f.
proof. done. qed.

hint simplify idfun_compL.

import DistrUtils.

(* -------------------------------------------------------------------- *)
lemma Markov (d : real distr) (a : real) :
     0%r < a
  => (forall x, x \in d => 0%r <= x)
  => hasE d idfun
  => mu d (fun x => a <= x) <= E d idfun / a.
proof.
move=> gt0_a ge0_d Ed; rewrite ler_pdivl_mulr //.
rewrite (Ec_split (fun x => a <= x)) 1:// &(ler_paddr).
- apply: mulr_ge0; first by apply: ge0_mu.
  apply/divr_ge0; [apply: exp_ge0 | by apply: ge0_mu].
  by move=> x /ge0_d ge0_x /#.
rewrite /Ec; pose p := mu d _; case: (p = 0%r) => [->//|nz_p].
rewrite mulrCA divff //= /E /p muE /= -sumZr &(ler_sum_pos) /=.
- move=> x; case: (a <= x) => // ? @/idfun /=; rewrite [_*a]mulrC.
  by rewrite mulr_ge0 // ~-1:#smt:(ge0_mu) /= ler_wpmul2r.
- by apply: hasE_cond.
qed.

(* -------------------------------------------------------------------- *)
abbrev hamming (s : bool list) = count (pred1 true) s.

lemma Chernoff (n : int) (dt p : real) :
     0 <= n
  => 0%r < dt
  => 0%r <= p <= 1%r
  =>

  let d = dmap (dlist (dbiased p) n) hamming in
  let m = E d (fun x => x%r) in

     mu d (fun i => (1%r + dt) * m <= i%r)
  <= (exp dt / ((1%r + dt)^(1%r + dt))) ^ m.
proof.
move=> ge0_n gt0_dt rgp d m.
pose t0 := ln (1%r + dt); pose e := (1%r + dt) * m.

have mE: m = n%r * p.
- have eqf: ((%r) \o count (pred1 true)) == BRA.big predT b2r.
  - elim=> // x xs ih @/(\o) /=; rewrite BRA.big_consT -ih.
    by rewrite fromintD /(\o) /=; congr => /#.
  rewrite /m /d exp_dmap /= 1:hasE_dmap.
  - by rewrite (eq_hasE _ _ _ eqf) &(hasED_dlist) // &(hasE_dbiased).
  rewrite (eq_exp _ _ (BRA.big predT b2r)) /=; 1: by move=> xs _; apply/eqf.
  rewrite expXD_ll // 1?(hasE_dbiased, dbiased_ll).
  by rewrite exp_dbiased /= clamp_id // mulrC.

have ge0_m: 0%r <= m by smt().
have gt0_t0: 0%r < t0 by rewrite -ln1 /t0 ln_mono_ltr //#.
have ge0_e: 0%r <= e by smt().

pose Fe := fun x => RealExp.exp (t0 * x).
pose dexp := dmap d (Fe \o (%r)).
rewrite (_ : mu _ _ = mu dexp (fun x => exp (t0 * e) <= x)).
- rewrite /dexp [mu (dmap d _) _]dmapE /(\o).
  apply: mu_eq_support => x xd /=; rewrite exp_mono.
  by apply/eq_sym/eqboolP/ler_pmul2l.

have Eok: forall F, hasE dexp F.
- move=> F; apply/hasE_finite/finite_dmap/finite_dmap.
  by apply/finite_dlist/finite_dbiased.

have := Markov dexp (RealExp.exp (t0 * e)) (exp_gt0 _) _ _.
- by move=> x /supp_dmap[a /=] [_ ->]; apply/ltrW/exp_gt0.
- by apply: Eok.
rewrite ler_pdivl_mulr 1:exp_gt0 => leMk.

have bd_bern:
  E (dmap (dbiased p) (Fe \o b2r)) idfun <= exp (p * (exp t0 - 1%r)).
- rewrite exp_dmap 1:hasE_finite /(\o).
  - by apply/finite_dmap/(finite_leq predT)/finite_bool.
  rewrite exp_dbiased /= /Fe /idfun /= clamp_id // exp0 /=.
  have := le1Dx_exp (p * (exp t0 - 1%r)) _; 1: by smt(exp0 exp_mono).
  by apply/ler_trans/lerr_eq; ring.

have: E dexp idfun <= exp ((exp t0 - 1%r) * m).
- rewrite /dexp /d dmap_comp; pose G := Fe \o _ \o _.
  rewrite exp_dmap /= 1:hasE_dmap.
  - by apply/hasE_finite/finite_dlist/finite_dbiased.
  pose H s := BRM.big predT (fun b => exp (t0 * b2r b)) s.
  rewrite -(eq_exp _ H) /G /H => [bs _ /=|] @/(\o) @/Fe.
  - rewrite (_ : t0 * _ = BRA.big predT (fun b => t0 * b2r b) bs).
    - rewrite -size_filter -big_count sumr_ofint /=.
      have /= <- := (sumr_undup (pred1 true) (fun _ => 1%r)).
      rewrite -BRA.mulr_sumr BRA.big_mkcond; congr.
      by apply: BRA.eq_bigr => b _ /#.
    by rewrite exp_sum /=.
  rewrite expXM // ~-1:(hasE_dbiased, dbiased_ll).  
  rewrite exp_dbiased /= exp0 /= clamp_id // mE.
  rewrite mulrA mulrAC expM rpow_nat // 1:ltrW 1:exp_gt0.
  rewrite &(ler_pexp) //= addr_ge0 /= ~-1:#smt:(exp_gt0).
  by rewrite mulrBl /= -addrA [(-p)+_]addrC &(le1Dx_exp) #smt:(exp0 exp_mono).

move/(ler_trans _ _ _ leMk) => {leMk}.
rewrite -ler_pdivl_mulr 1:exp_gt0 => /ler_trans; apply.
rewrite &(lerr_eq) /e mulrA -expB -mulrBl expM; congr.
rewrite {1}/t0 expK 1:/# [_ - 1%r]addrAC /= expB.
by do 2! congr; rewrite expM expK 1:/#.
qed.

(* -------------------------------------------------------------------- *)
lemma chernoff_bound_small_enough (dt : real) (k : int) (u : real) :
     0%r <= dt
  => 0 < k
  => 0%r <= u <= 1%r
  => (1%r + dt) * u = 1%r + k%r
  =>    (exp dt / ((1%r + dt)^(1%r + dt)))^u
     <= 2%r ^ (-k %/ 2)%r.
proof.
move=> ge0_dt gt0_k rgu heq.
have uE: u = (1%r + k%r) / (1%r + dt).
+ suff : u * (1%r + dt) = (1%r + k%r) / (1%r + dt) * (1%r + dt).
  + by rewrite &(mulIf) 1:/#.
  by rewrite -divrK 1:/# mulrC.

pose d := (_ / _); have gt0_d: 0%r < d by apply/divr_gt0/rpow_gt0; smt(exp_gt0).
rewrite -ln_mono; first by apply/rpow_gt0.
- by rewrite rpow_gt0 //.
rewrite rpowE // lnK /= rpowE // lnK.
move => @/d => {d gt0_d}.
rewrite lnM -1:lnV ~-1:#smt:(exp_gt0 rpow_gt0) lnK. (* what does this ~ mean? *)
rewrite rpowE 1:/# lnK.

pose fu x := (1%r + k%r) / (1%r + x); rewrite uE -/(fu dt).
pose F x := (x - (1%r + x) * (ln (1%r + x))); rewrite -/(F dt).
pose dv x := - ((1%r + k%r) * x) / ((1%r + x) * (1%r + x)).
pose f x := fu x * F x; rewrite -/(f dt).

have range_dt: k%r <= dt by smt().
have f_drv: forall x, k%r <= x <= dt => hasdrvt f x /\ derivative f x = dv x.
- (* pre-building for the computation : a bottom-up pass over the expression tree *)
  move => x ?.

  have ?: hasdrvt (fun _ => 1%r + k%r) x by apply hasdrvtC.
  have ?: hasdrvt (fun _ => 1%r) x by apply hasdrvtC.
  have ?: hasdrvt idfun x by apply hasdrvt_idfun.
  have ?: hasdrvt (fun x => (1%r + x)) x by rewrite hasdrvtD.
  have ?: hasdrvt (fun x => (1%r + k%r) / (1%r + x)) x by rewrite hasdrvtV // /#.
  have ?: hasdrvt (fun x => ln (1%r + x)) x by rewrite hasdrvtL // /#.
  have ?: hasdrvt (fun x => (1%r + x) * ln (1%r + x)) x by rewrite hasdrvtM //.
  have ?: hasdrvt (fun x => -(1%r + x) * ln (1%r + x)) x by rewrite hasdrvtN //.
  have ?: hasdrvt (fun x => x - (1%r + x) * ln (1%r + x)) x by rewrite hasdrvtD //.

  split; first by apply/(hasdrvtM _ _ x).

  (* compute the derivative : a top-down pass over the expression tree *)
  rewrite derivativeM //.
  have nz_1x: 1%r + x <> 0%r by smt().
  have -> /=: derivative (fun x => (1%r + k%r) / (1%r + x)) x
      = -(1%r + k%r) / ((1%r + x) * (1%r + x)).
  - rewrite derivativeV //.
    have ->: derivative (fun _ => 1%r + k%r) x = 0%r.
    - by rewrite derivativeC.
    have ->: derivative (fun x0 => 1%r + x0) x = 1%r.
    - rewrite derivativeD //.
      by rewrite derivativeC derivative_idfun //.
    by smt().
  have ->: derivative (fun x => x - (1%r + x) * ln (1%r + x)) x
         = (fun x => - ln (1%r + x)) x.
  - rewrite derivativeD //.
    rewrite derivative_idfun.
    have ->: derivative (fun x => - (1%r + x) * ln (1%r + x)) x
           = - ln (1%r + x) - 1%r.
    - rewrite derivativeN //.
      - have ->: derivative (fun x => (1%r + x) * ln (1%r + x)) x
               = ln (1%r + x) + 1%r.
        - rewrite derivativeM //.
          have ->: derivative (fun x => 1%r + x) x = 1%r.
          - rewrite derivativeD //.
            by rewrite derivativeC derivative_idfun //.
        have ->: derivative (fun x => ln (1%r + x)) x
               = inv (1%r + x).
        - rewrite derivativeL // 1:/#.
          have ->: derivative (fun x => 1%r + x) x = 1%r.
          - rewrite derivativeD //.
            by rewrite derivativeC derivative_idfun //.
          by smt().
        by rewrite /= divff.
      by ring.
    by ring.
  rewrite /= /F /fu /dv.
  by field => //; smt(expr_gt0).

apply (ler_trans (f k%r)).
+ case: (k%r = dt) => [->|neq_kdt]; first by done.
  apply derivative_nonpos_implies_decrease.
  + by smt().
  + move=> x hx; apply/hasdrvt_continuous; have [] := f_drv x _; smt().
  + move=> x hx; have [] := f_drv x _; smt().
  + move=> x hx; have [] := f_drv x _; smt().

rewrite /f /fu /F.
rewrite (: _ / _ = 1%r).
+ by field; smt().
clear dt u ge0_dt rgu heq uE fu F dv f range_dt f_drv.
apply (ler_trans (- k%r * ln 2%r / 2%r)); 2: by smt(ln_gt0).
rewrite -subr_le0 /=.
pose f x := (1%r + ln 2%r / 2%r) * x - (1%r + x) * ln (1%r + x); rewrite -/(f k%r).
have k_rng: 1%r <= k%r by smt().
have k_drv: forall x, 1%r <= x <= k%r => hasdrvt f x /\ derivative f x = ln 2%r / 2%r - ln (1%r + x).
- move => x ?.

  have ?: hasdrvt (fun x => x) x by apply hasdrvt_idfun.
  have ?: hasdrvt (fun _ => 1%r + ln 2%r / 2%r) x by apply hasdrvtC.
  have ?: hasdrvt (fun x => (1%r + ln 2%r / 2%r) * x) x by rewrite hasdrvtM //.
  have ?: hasdrvt (fun _ => 1%r) x by apply hasdrvtC.
  have ?: hasdrvt (fun x => 1%r + x) x by apply hasdrvtD.
  have ?: hasdrvt (fun x => ln (1%r + x)) x by rewrite hasdrvtL // /#.
  have ?: hasdrvt (fun x => (1%r + x) * ln (1%r + x)) x by rewrite hasdrvtM //.
  have ?: hasdrvt (fun x => - (1%r + x) * ln (1%r + x)) x by rewrite hasdrvtN //.
  have ?: hasdrvt (fun x => (1%r + ln 2%r / 2%r) * x - (1%r + x) * ln (1%r + x)) x by rewrite hasdrvtD //.

  split; first done.

  rewrite derivativeD //.
  have->: derivative (fun x => (1%r + ln 2%r / 2%r) * x) x = 1%r + ln 2%r / 2%r.
  - rewrite derivativeM //.
    by rewrite derivativeC // derivative_idfun //.
  have->: derivative (fun x => -(1%r + x) * ln (1%r + x)) x = - 1%r - ln (1%r + x).
  - rewrite derivativeN //.
    rewrite derivativeM //.
    have ->: derivative (fun x => 1%r + x) x = 1%r.
    + rewrite derivativeD //.
      by rewrite derivativeC // derivative_idfun //.
    have -> /= : derivative (fun x => ln (1%r + x)) x = 1%r / (1%r + x).
    + rewrite derivativeL //; 1: by smt().
      by rewrite derivativeD // derivativeC // derivative_idfun //.
    by field; smt().
  by smt().

apply (ler_trans (f 1%r)).
- apply (ler_trans (f k%r)); 1: by smt().
  case: (1%r = k%r) => [<-|neq_1k]; first by done.
  apply derivative_nonpos_implies_decrease.
  - by smt().
  - move=> x hx; apply/hasdrvt_continuous; have [] := k_drv x _; smt().
  - move=> x hx; have [] := k_drv x _; smt().
  - move => x hx.
    have [_ ->] := k_drv x _; first by smt().
    have: ln 2%r <= ln (1%r + x) by smt(ln_mono).
    by smt(ln_gt0).
  - rewrite /f /=.
    have /#: 1%r <= (3%r / 2%r) * ln 2%r.
    rewrite -exp_mono -rpowE // -/e.
    rewrite (_: 3%r / 2%r = 1%r / 2%r + 1%r) 1:/#.
    by rewrite rpowD // rpow1 // div1r #smt:(e_lt_2sqrt2).
qed.
