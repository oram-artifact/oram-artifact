require import AllCore List IntDiv Distr DBool DList DInterval FMap FSet.
require import FinType RealExp Finite IntMin BitEncoding Xreal Ring.
require import StdOrder StdBigop.
require import Finite IntMin Array BitEncoding Xreal.
(*---*) import BS2Int.
require (*--*) BitWord.
(*---*) import IntOrder Bigint Bigreal.
require import DBool.
(*---*) import Biased.
require import RealSeries.

(* ==================== logic ==================== *)

(* -------------------------------------------------------------------- *)
lemma case_elim p q: ((p => q) /\ (!p => q)) <=> q.
proof. by smt(). qed.

lemma case_elim2 p q1 q2: q1 => (q1 <=> q2) => ((p => q1) /\ (!p => q2)).
proof. by smt(). qed.

(* -------------------------------------------------------------------- *)
lemma contra_congr ['a 'b] (f : 'a -> 'b) (x y : 'a) :
  f x <> f y => x <> y.
proof. by rewrite &(contra) &(congr1). qed.

(* -------------------------------------------------------------------- *)
lemma iff_trans (x y z : bool) :
  (x <=> y) => (y <=> z) => (x <=> z).
proof. by smt(). qed.

(* ==================== option =================== *)

(* -------------------------------------------------------------------- *)
lemma some_not_none ['a] (x : 'a option) :
  (exists y, x = Some y) <=> x <> None.
proof.
split.
- by move => [y ->].
- by move => /some_oget ->; exists (oget x).
qed.

(* -------------------------------------------------------------------- *)
lemma omap_some_oget ['a 'b] (f : 'a -> 'b) (x : 'a option) (y : 'b) :
  omap f x = Some y => f (oget x) = y.
proof.
move => H.
have <-: oget (omap f x) = y.
- by rewrite H oget_some.
by rewrite oget_omap_some /#.
qed.

(* -------------------------------------------------------------------- *)
lemma oget_ext ['a] (x y : 'a option) :
     x <> None
  => y <> None
  => oget x = oget y
  => x = y.
proof.
rewrite -some_not_none; elim => x0 ->.
rewrite -some_not_none; elim => y0 ->.
by rewrite !oget_some.
qed.

(* -------------------------------------------------------------------- *)
lemma oget_obind_some ['a 'b] (ox : 'a option) (f : 'a -> 'b option) :
     ox <> None
  => f (oget ox) <> None
  => oget (obind f ox) = oget (f (oget ox)).
proof. by case ox => // x _. qed.

(* -------------------------------------------------------------------- *)
lemma obind_not_none ['a 'b] (ox : 'a option) (f : 'a -> 'b option) :
  obind f ox <> None => (ox <> None /\ f (oget ox) <> None).
proof. by smt(). qed.

(* -------------------------------------------------------------------- *)
lemma omap_some ['a 'b] (ox : 'a option) (f : 'a -> 'b) :
  ox <> None => omap f ox = Some (f (oget ox)).
proof. by smt(). qed.

(* -------------------------------------------------------------------- *)
op (`|`) ['a 'b] (f g : 'a -> 'b option) : 'a -> 'b option =
  fun x => if g x <> None then g x else f x.

(* ==================== list ==================== *)

(* -------------------------------------------------------------------- *)
theory ListUtils.
  abbrev "_.[_]" ['a] (s : 'a list) (i : int) : 'a =
    nth witness s i.

  abbrev "_.[_<-_]" ['a] (s : 'a list) (i : int) (x : 'a) : 'a list =
    mkseq (fun k => if i = k then x else s.[k]) (size s).

  (* -------------------------------------------------------------------- *)
  lemma last_range (x0 : int) (n m : int) :
    n < m => last x0 (range n m) = m - 1.
  proof. by move => ?; rewrite -(nth_last x0) nth_range size_range /#. qed.

  (* -------------------------------------------------------------------- *)
  lemma map1 ['a 'b] (f : 'a -> 'b) (x : 'a) :
      map f [x] = [f x].
  proof. by smt(). qed.

  (* -------------------------------------------------------------------- *)
  lemma size1 ['a] (x : 'a) :
      size [x] = 1.
  proof. by apply size_eq1; exists x; done. qed.

  (* -------------------------------------------------------------------- *)
  lemma take1 ['a] (x0 : 'a) (s : 'a list) (n : int) :
      0 < size s => n = 1 => take n s = [head x0 s].
  proof. by smt(). qed.

  (* -------------------------------------------------------------------- *)
  lemma count1 ['a] (p : 'a -> bool) (x : 'a) :
      count p [x] = b2i (p x).
  proof. by smt(). qed.

  (* -------------------------------------------------------------------- *)
  lemma oget_onth ['a] (s : 'a list) (i : int) (x0 : 'a) :
      0 <= i < size s => oget (onth s i) = nth x0 s i.
  proof. by move => ?; rewrite (onth_nth x0) //. qed.

  (* -------------------------------------------------------------------- *)
  lemma mem_neq0 ['a] (s : 'a list) :
      (exists x, x \in s) <=> s <> [].
  proof. by smt(mem_eq0). qed.

  (* -------------------------------------------------------------------- *)
  lemma find_max (l : 'a list) (P : 'a -> bool) :
     find P l <= size l.
  proof.
  by elim l => //=;smt(find_ge0).
  qed.

  (* -------------------------------------------------------------------- *)
  lemma trim_id (l : 'a list) (i : int) :
     !(0 <= i < size l) => (trim l i) = l.
  proof.
  case (i < 0); 1: by smt(take0 drop0).
  by move => ??; rewrite /trim take_oversize 1:/# drop_oversize 1:/# cats0.
  qed.

  (* -------------------------------------------------------------------- *)
  lemma mem_trim ['a] (l : 'a list) (i : int) (v : 'a) :
    v \in trim l i => v \in l
    by smt(mem_take mem_drop mem_cat).

  (* -------------------------------------------------------------------- *)
  lemma find_rng_in ['a] (l : 'a list) (P : 'a -> bool) :
    has P l <=> (0 <= find P l < size l).
  proof.
  split.
  + elim l => //= x l Hi H; elim H; smt(List.size_ge0).
  elim l => //= x l Hi H; smt(has_find).
  qed.

  (* -------------------------------------------------------------------- *)
  lemma find_rng_out ['a] (l : 'a list) (P : 'a -> bool) :
    !has P l <=> !(find P l < size l).
  proof.
  split.
  + elim l => //=; smt(List.size_ge0).
  elim l => //= x l Hi H; smt(has_find).
  qed.

  (* -------------------------------------------------------------------- *)
  lemma trim_cons_false ['a] (l : 'a list) (x : 'a) (P : 'a -> bool) :
    !P x => trim (x :: l) (find P (x :: l)) = x :: trim l (find P l).
  proof.
  move => Hp /=; rewrite Hp /=.
  by rewrite /trim /= !ifF; 1,2: smt(find_ge0 find_rng_in find_rng_out).
  qed.

  (* -------------------------------------------------------------------- *)
  lemma trim_mem ['a] (l : 'a list) (x : 'a) (P : 'a -> bool) :
    x \in l => !P x => x \in trim l (find P l).
  proof.
  elim l => //= h t /= Hi H; elim H; smt(trim_cons_false).
  qed.

  (* -------------------------------------------------------------------- *)
  lemma find_trim_lt ['a] (l : 'a list) (P : 'a -> bool) (i : int) :
    0 <= i < (find P l) => nth witness l i = nth witness (trim l (find P l)) i.
  proof.
  move => ?; rewrite /trim nth_cat size_take 1:/#.
  by smt(nth_take find_max).
  qed.

  (* -------------------------------------------------------------------- *)
  lemma find_trim_ge ['a] (l : 'a list) (P : 'a -> bool) (i : int) :
    (find P l) < i < size l => nth witness l i = nth witness (trim l (find P l)) (i-1).
  proof.
  move => ?; rewrite /trim nth_cat size_take; 1: smt(find_ge0).
  rewrite ifF 1:/# ifT 1:/# nth_drop; smt(find_ge0).
  qed.

  (* -------------------------------------------------------------------- *)
  lemma mkseq_in_eq (f g : int -> 'a) (n : int) :
       0 <= n
    => (forall i, 0 <= i < n => f i = g i)
    => mkseq f n = mkseq g n.
  proof.
  move => ??.
  apply (eq_from_nth witness).
  + by rewrite !size_mkseq.
  + rewrite size_mkseq lez_maxr //= => i ?.
    by rewrite !nth_mkseq // /#.
  qed.

  (* -------------------------------------------------------------------- *)
  lemma rev_rev (l : 'a list) :
    l = rev (rev l).
  proof. by elim l => //= x l ih; rewrite rev_cons rev_rcons -ih. qed.

  (* -------------------------------------------------------------------- *)
  lemma find_le (p : 'a -> bool) (l : 'a list) (n : int) :
    0 <= n < size l => p (nth witness l n) => find p l <= n.
  proof. by move => ??; rewrite &(contraT) -ltzNge #smt:(before_find). qed.

  (* -------------------------------------------------------------------- *)
  lemma uniq_take (l : 'a list) (n : int) : uniq l => uniq (take n l).
  proof. by rewrite -{1}[l](cat_take_drop n) cat_uniq. qed.

  (* -------------------------------------------------------------------- *)
  lemma size_take_take ['a] (s : 'a list) (n m : int) :
       0 <= n <= size s
    => 0 <= m <= size s
    => size (take n (take m s)) = min n m.
  proof. by move => ??; rewrite take_take #smt:(size_take). qed.

  (* -------------------------------------------------------------------- *)
  lemma count_union ['a] (p q1 q2 : 'a -> bool) (s : 'a list) :
       (forall a, a \in s => (p a => q1 a \/ q2 a))
    => count p s <= count q1 s + count q2 s.
  proof. by elim s => //= /#. qed.

  (* -------------------------------------------------------------------- *)
  lemma count_disjoint_union ['a] (p p1 p2 : 'a -> bool) (s : 'a list) :
     (forall a, a \in s
         => ((p a <=> p1 a \/ p2 a) /\ !(p1 a /\ p2 a)))
       => count p s = count p1 s + count p2 s.
  proof. by elim s => //= /#. qed.

  (* Inclusion-exclusion principle for count *)
  lemma count_predU ['a] (P Q : 'a -> bool) (s : 'a list) :
    count (predU P Q) s = count P s + count Q s - count (predI P Q) s.
  proof. by elim: s => //= /#. qed.

  (* -------------------------------------------------------------------- *)
  lemma count_le ['a] (p1 p2 : 'a -> bool) (s : 'a list) :
    p1 <= p2 => count p1 s <= count p2 s.
  proof. by move=> lep; elim: s => //= x s ih; smt(). qed.

  hint simplify subseq_refl.

  (* -------------------------------------------------------------------- *)
  lemma subseq_behead ['a] (s : 'a list) : subseq (behead s) s.
  proof. by case: s => //= x s; apply: subseq_cons. qed.

  (* -------------------------------------------------------------------- *)
  lemma subseq_catR ['a] (s s1 s2 : 'a list) :
    subseq s s1 => subseq s (s1 ++ s2).
  proof. by move=> *; rewrite -[s]cats0 &(cat_subseq) // sub0seq. qed.

  (* -------------------------------------------------------------------- *)
  lemma subseq_catL ['a] (s s1 s2 : 'a list) :
    subseq s s2 => subseq s (s1 ++ s2).
  proof. by move=> *; rewrite -[s]cat0s &(cat_subseq) // sub0seq. qed.

  (* -------------------------------------------------------------------- *)
  lemma subseq_consI ['a] (x : 'a) (s1 s2 : 'a list) :
    subseq (x :: s1) s2 => subseq s1 s2.
  proof.
  case/subseqP=> m [eqsz h]; apply/subseqP.
  elim: m s2 eqsz h => [|b m ih] [|x2 s2] //=.
  move/addzI => eqsz; case: b => /= _.
  - by case=> <<- ->; exists (false :: m) => /#.
  by case/(ih _ eqsz) => m' [*]; exists (false :: m') => /= /#.
  qed.

  (* -------------------------------------------------------------------- *)
  lemma subseq_take ['a] (i : int) (s1 s2 : 'a list) :
    subseq s1 s2 => subseq (take i s1) s2.
  proof.
  move=> *; apply: (subseq_trans s1) => //.
  by rewrite -{2}[s1](cat_take_drop i) &(subseq_catR).
  qed.

  (* -------------------------------------------------------------------- *)
  lemma subseq_drop ['a] (i : int) (s1 s2 : 'a list) :
    subseq s1 s2 => subseq (drop i s1) s2.
  proof.
  move=> *; apply: (subseq_trans s1) => //.
  by rewrite -{2}[s1](cat_take_drop i) &(subseq_catL).
  qed.

  (* -------------------------------------------------------------------- *)
  lemma subseq_drop_congr ['a] (i : int) (s1 s2 : 'a list) :
    subseq s1 s2 => subseq (drop i s1) (drop i s2).
  proof.
  elim/natind: i s1 s2 => [i le0_i|i ge0_i ih].
  - by move=> *; rewrite !drop_le0.
  case=> [|x1 s1]; [by move=> *; apply: sub0seq | case=> //= x2 s2 h].
  rewrite !(ifF (_ <= 0)) ~-1:/#; apply: ih => //.
  by move: h; case: (x2 = x1) => //= ? /subseq_consI.
  qed.

  (* -------------------------------------------------------------------- *)
  lemma subseq_range (l1 l2 r1 r2 : int) :
     l1 <= l2 <= r2 <= r1 => subseq (range l2 r2) (range l1 r1).
  proof.
  move => ?.
  rewrite [range l1 r1] (range_cat l2) 1,2:/#.
  rewrite [range l2 r1] (range_cat r2) 1,2:/#.
  by rewrite &(subseq_catL) &(subseq_catR) subseq_refl.
  qed.
  
  (* ==================== prefix ==================== *)
  op isprefix ['a] (s1 s2 : 'a list) : bool =
    s1 = take (size s1) s2.

  op prefixes ['a] (path : 'a list) =
    map (fun i => take i path) (range 0 (size path + 1)).

  lemma isprefix_size (s1 s2 : 'a list) :
    isprefix s1 s2 => size s1 <= size s2.
  proof. by move=> @/isprefix ->; rewrite size_take //#. qed.

  lemma isprefixP (s1 s2 : bool list) :
    isprefix s1 s2 <=> (exists t, s1 ++ t = s2).
  proof.
  split=> @/isprefix.
  - by move=> ->; exists (drop (size s1) s2); rewrite cat_take_drop.
  - by case=> t <-; rewrite take_cat_le /= take_size.
  qed.

  lemma isprefix_catR ['a] (q2 q1 p : 'a list) : isprefix (q1 ++ q2) p => isprefix q1 p.
  proof.
  rewrite /isprefix => /> *.
  + have ?: take (size q1) (q1 ++ q2) = q1.
    + by rewrite take_cat /= take0 cats0.
    have ->: take (size q1) p = take (size q1) (take (size (q1 ++ q2)) p).
    + by rewrite size_cat take_take #smt:(List.size_ge0).
    by smt().
  qed.

  lemma isprefix_elem ['a] (s1 s2 : 'a list) :
      isprefix s1 s2 <=> (size s1 <= size s2
                       /\ forall i, 0 <= i < size s1 => s1.[i] = s2.[i]).
  proof.
  rewrite /isprefix; split.
  + by smt(size_take nth_take).
  + move => [#] *; apply (eq_from_nth witness).
    + by smt(size_take List.size_ge0).
    + by smt(nth_take).
  qed.

  lemma isprefix1 ['a] (s1 : 'a list) (x : 'a) :
      isprefix s1 (s1 ++ [x]).
  proof.
  by rewrite /isprefix take_cat /= cats0 //.
  qed.

  lemma app_isprefix ['a] (s1 s2 : 'a list) (x : 'a) :
      size s1 < size s2
   => isprefix s1 s2
   => s2.[size s1] = x
   => isprefix (s1 ++ [x]) s2.
  proof.
  rewrite /isprefix => /> ? H.
  by rewrite size_cat size1 {1} H cats1 (take_nth witness) /#.
  qed.

  lemma prefixes_size ['a] (s : 'a list) :
      size (prefixes s) = size s + 1.
  proof.
  by rewrite /prefixes size_map size_range ler_maxr #smt:(List.size_ge0).
  qed.

  lemma prefixes_isprefix ['a] (s1 s2 : 'a list) :
      s1 \in (prefixes s2) <=> isprefix s1 s2.
  proof.
  rewrite /prefixes /isprefix (nthP witness) => />; split.
  + move => i.
    rewrite size_map size_range lez_maxr 1:#smt:(List.size_ge0) //= => *.
    rewrite (nth_map witness witness) 1:#smt:(size_range List.size_ge0).
    by rewrite nth_range //= size_take // #smt:(take_take).
  + move => H.
    exists (size s1).
    rewrite size_map size_range lez_maxr 1:#smt:(List.size_ge0).
    have ?: size s1 <= size s2 by rewrite H size_take #smt:(List.size_ge0).
    rewrite (nth_map witness witness).
    + by rewrite size_range lez_maxr #smt:(List.size_ge0).
    by rewrite nth_range //= /#.
  qed.

  (* -------------------------------------------------------------------- *)
  lemma isprefix_nth ['a] (s1 s2 : 'a list) (n : int) :
    isprefix s1 s2 => 0 <= n < size s1 => s1.[n] = s2.[n].
  proof.
  by move => H ?; rewrite isprefix_elem in H; by smt().
  qed.

  (* -------------------------------------------------------------------- *)
  lemma isprefix_take ['a] (s : 'a list) (n : int) :
    isprefix (take n s) s.
  proof.
  rewrite /isprefix.
  case (n <= 0) => ?.
  + by rewrite take_le0 //= take0.
  case (n < size s) => ?.
  + by rewrite size_take /#.
  by rewrite !take_oversize /#.
  qed.

  (* ==================== rfind ==================== *)
  op rfind ['a] (p : 'a -> bool) (l : 'a list) : int =
    size l - find p (rev l) - 1.

  (* -------------------------------------------------------------------- *)
  lemma rfind_last ['a] (p : 'a -> bool) (l : 'a list) :
    l <> [] => (p (last witness l) <=> rfind p l = size l - 1).
  proof.
  move => ? @/rfind.
  apply (iff_trans _ (p (head witness (rev l)))).
  + by rewrite {1} (rev_rev l) last_rev.
  apply (iff_trans _ (find p (rev l) = 0)).
  + split.
    + move => ?; rewrite eqz_leq; split.
      + rewrite &(find_le).
        + by rewrite size_rev #smt:(List.size_ge0).
        + by rewrite nth0_head.
      + exact find_ge0.
    + move => H0.
      rewrite -nth0_head -H0 nth_find has_find.
      + by rewrite size_rev #smt:(List.size_ge0).
  by smt().
  qed.

  (* -------------------------------------------------------------------- *)
  lemma rfind_cat ['a] (p : 'a -> bool) (l1 l2 : 'a list) :
    rfind p (l1 ++ l2) = if has p l2 then size l1 + rfind p l2 else rfind p l1.
  proof. by rewrite /rfind rev_cat -has_rev size_cat find_cat size_rev /#. qed.

  (* -------------------------------------------------------------------- *)
  lemma rfind_catl ['a] (p : 'a -> bool) (l1 l2 : 'a list) :
    !has p l2 => rfind p (l1 ++ l2) = rfind p l1.
  proof.
  by rewrite rfind_cat => ->.
  qed.

  (* -------------------------------------------------------------------- *)
  lemma rfind_in_eq ['a] (p1 p2 : 'a -> bool) (l : 'a list) :
       (forall x, x \in l => (p1 x <=> p2 x))
    => rfind p1 l = rfind p2 l.
  proof.
  move => ? @/rfind.
  suff : find p1 (rev l) = find p2 (rev l) by smt().
  apply find_eq_in => x.
  by rewrite mem_rev /#.
  qed.

  lemma rfind_rng ['a] (p : 'a -> bool) (s : 'a list) :
    -1 <= rfind p s < size s.
  proof.
  rewrite /rfind; split.
  + suff : find p (rev s) <= size s by smt().
    by rewrite -(size_rev s) find_size.
  + suff : 0 <= find p (rev s) by smt().
    exact find_ge0.
  qed.

  lemma rfind_ge ['a] (p : 'a -> bool) (s : 'a list) (i : int) :
    0 <= i < size s => p s.[i] => i <= rfind p s.
  proof.
  move => Hirng Hp @/rfind.
  have Hrev : p (rev s).[size s - i - 1].
  + by rewrite nth_rev /#.
  suff : find p (rev s) <= size s - i - 1 by smt().
  apply find_le.
  + by rewrite size_rev /#.
  + by done.
  qed.

  lemma rfindP ['a] (p : 'a -> bool) (s : 'a list) :
    0 <= rfind p s => p s.[rfind p s].
  proof.
  move => @/rfind => Hge0.
  have Hhas : has p (rev s).
  + by rewrite has_find size_rev /#.
  have -> : s.[size s - find p (rev s) - 1] = (rev s).[find p (rev s)].
  + by rewrite nth_rev 1:#smt:(find_ge0 find_size size_rev) /#.
  by rewrite nth_find.
  qed.

  lemma rfind_after ['a] (p : 'a -> bool) (s : 'a list) (i : int) :
    rfind p s < i < size s => ! p s.[i].
  proof.
  move => Hirng.
  apply negP => Hp.
  have := rfind_ge p s i _ _ => //.
  + have := rfind_rng p s; smt().
  + by smt().
  qed.

  (* s[l..r) -- l is included and r is not included *)
  op interval ['a] (s : 'a list) (l r : int) = drop l (take r s).

  (* -------------------------------------------------------------------- *)
  lemma count_interval_le_count_drop ['a] (p : 'a -> bool) (s : 'a list) (l r : int) :
      count p (interval s l r) <= count p (drop l s).
  proof.
  apply: count_subseq => @/interval; rewrite -{2}[s](cat_take_drop r).
  rewrite drop_cat; case: (l < size (take r s)).
  - by move => _; exact subseq_catR.
  - by move=> /lezNgt => ?; rewrite drop_oversize // &(sub0seq).
  qed.

  (* -------------------------------------------------------------------- *)
  lemma interval_catR ['a] (s1 s2 : 'a list) (l r : int) :
      r <= size s1 => interval (s1 ++ s2) l r = interval s1 l r.
  proof. by move=> *; rewrite /interval take_cat_le ifT. qed.

  (* -------------------------------------------------------------------- *)
  lemma interval_size ['a] (s : 'a list) (l r : int) :
      0 <= l <= r <= size s => size (interval s l r) = r - l.
  proof.
  by move => ?; rewrite /interval size_drop 1:/# size_take /#.
  qed.

  (* -------------------------------------------------------------------- *)
  lemma interval_nth ['a] (s : 'a list) (m l r : int) (x : 'a) :
       0 <= l
    => 0 <= m < r - l
    => nth x (interval s l r) m = nth x s (m + l).
  proof.
  by move => ??; rewrite /interval nth_drop // 1:/# nth_take /#.
  qed.

  (* -------------------------------------------------------------------- *)
  lemma interval_split ['a] (s : 'a list) (m l r : int) :
      0 <= l <= m <= r <= size s => interval s l r = interval s l m ++ interval s m r.
  proof.
  move => ?.
  apply (eq_from_nth witness).
  + by rewrite size_cat !interval_size /#.
  + move => i; rewrite interval_size 1:/#.
    case: (i < m - l) => ??.
    + rewrite interval_nth 1,2:/# nth_cat interval_size 1:/#.
      by rewrite (: i < m - l) //= interval_nth /#.
    + rewrite nth_cat interval_size 1:/#.
      by rewrite (: !i < m - l) // interval_nth //= 1:/# interval_nth /#.
  qed.

  (* -------------------------------------------------------------------- *)
  lemma intervalS ['a] (s : 'a list) (n m : int) :
      0 <= n < m <= size s => m = n + 1 => interval s n m = [nth witness s n].
  proof.
  move => ??; rewrite /interval drop_take 1,2:/# (_ : _ - _ = 1) 1:/#.
  by rewrite (drop_take1_nth witness) /#.
  qed.

  (* -------------------------------------------------------------------- *)
  lemma interval_empty ['a] (s : 'a list) (l r : int) :
      r <= l => interval s l r = [].
  proof.
  move=> ?; rewrite /interval.
  case (l <= 0) => ?.
  + by rewrite drop_le0 // &(take_le0) /#.
  + rewrite drop_oversize //.
    case (r <= 0) => ?.
    + by rewrite take_le0 // /#.
    + by rewrite size_take /#.
  qed.

  (* -------------------------------------------------------------------- *)
  lemma interval_oversize ['a] (s : 'a list) (l r : int) :
      size s <= r => interval s l r = drop l s.
  proof. by move=> *; rewrite /interval take_oversize. qed.

  (* -------------------------------------------------------------------- *)
  lemma interval_subseq ['a] (s : 'a list) (l1 l2 r1 r2 : int) :
      0 <= l1 <= l2 <= r1 <= r2
   => subseq (interval s l2 r1) (interval s l1 r2).
  proof.
  move=> * @/interval; rewrite (_ : l2 = l1 + (l2 - l1)) 1:#ring.
  rewrite -drop_drop ~-1:/# &(subseq_drop_congr) &(subseq_drop).
  have := take_take s r1 r2; rewrite ifT 1:/# => <-.
  by apply: subseq_take.
  qed.

  (* -------------------------------------------------------------------- *)
  lemma interval_drop ['a] (s : 'a list) (l r : int) :
      size s <= r => interval s l r = drop l s.
  proof.
  by move => ? @/interval; rewrite take_oversize //.
  qed.

  (* -------------------------------------------------------------------- *)
  lemma interval_take ['a] (s : 'a list) (l r : int) :
      l <= 0 => interval s l r = take r s.
  proof.
  by move => ? @/interval; rewrite drop_le0 //.
  qed.

  (* -------------------------------------------------------------------- *)
  lemma count_interval_with1 ['a] (p : 'a -> bool) (s : 'a list) (l r : int) (x : 'a) :
       l < r
    => r = size s + 1
    => count p (interval (s ++ [x]) l r) = count p (drop l s) + (b2i (p x)).
  proof.
  move => ??.
  rewrite interval_drop.
  + by rewrite size_cat size1 /#.
  + rewrite drop_cat.
    have ? : l <= size s by smt().
    case: (l < size s).
    + by rewrite count_cat /#.
    + by move => ?; rewrite drop_oversize /#.
  qed.

  (* -------------------------------------------------------------------- *)
  lemma count_interval_mono ['a] (p : 'a -> bool) (s : 'a list) (l r1 r2 : int) (k : int) :
       0 < k
    => 0 <= l
    => l < r1 <= size s
    => l < r2 <= size s
    => count p (interval s l r1) = k
    => count p (interval s l r2) = k
    => p (nth witness s (r1 - 1))
    => r1 <= r2.
  proof.
  move => ???? Hr1 Hr2 Hr11.
  rewrite lerNgt &(negP) => ?.
  move: Hr1.
  rewrite (interval_split s (r1 - 1)) 1:/#.
  rewrite count_cat (intervalS _ (r1 - 1) r1) 1,2:/#.
  rewrite count1 /b2i Hr11 /=.
  have /# : k <= count p (interval s l (r1 - 1)).
  + by rewrite -Hr2 &(count_subseq) &(interval_subseq) /#.
  qed.

  (* -------------------------------------------------------------------- *)
  lemma nth_uniqP (s : 'a list) :
    uniq s <=>
    (forall (i j : int), 0 <= i < size s => 0 <= j < size s => i <> j =>
      nth witness s i <> nth witness s j).
  proof.
  split; last by apply nth_uniq.
  move=> uniq_s i j rng_i rng_j neq_ij.
  apply: contraL neq_ij => eq_nth.
  by rewrite -(index_uniq witness i s) // -(index_uniq witness j s) // eq_nth.
  qed.

  (* -------------------------------------------------------------------- *)
  op undup_mask ['a] (s : 'a list) =
    mkseq (fun i => !(nth witness s i \in drop (i+1) s)) (size s).
  
  (* -------------------------------------------------------------------- *)
  lemma undup_mask0 ['a] : undup_mask [<:'a>] = [].
  proof. by rewrite /undup_mask /= mkseq0. qed.
  
  (* -------------------------------------------------------------------- *)
  lemma undup_maskS ['a] (x : 'a) (s : 'a list) :
    undup_mask (x :: s) = ((!(x \in s)) :: undup_mask s).
  proof.
  rewrite /undup_mask /= [1 + _]addrC mkseqSr 1:size_ge0 /=.
  rewrite /(\o) /= /= drop0 /= &(eq_in_mkseq) => i rgi /=.
  by congr; rewrite !ifF ~-1:/# [1+_]addrC.
  qed.
  
  (* -------------------------------------------------------------------- *)
  hint simplify undup_mask0, undup_maskS.
  
  (* -------------------------------------------------------------------- *)
  lemma undup_mask_uniq ['a] (s : 'a list) :
    uniq s => undup_mask s = nseq (size s) true.
  proof.
  elim: s => /= [|x s ih]; first by rewrite nseq0.
  by rewrite [1+_]addrC nseqS //#.
  qed.
  
  (* -------------------------------------------------------------------- *)
  lemma mask0s ['a] (s : 'a list) : mask [] s = [].
  proof. by case: s. qed.
  
  hint simplify mask0s.
  
  (* -------------------------------------------------------------------- *)
  lemma mask_rcons ['a] (m : bool list) (b : bool) (s : 'a list) (x : 'a) :
    size m = size s => mask (rcons m b) (rcons s x) =
      if b then rcons (mask m s) x else mask m s.
  proof.
  by move=> eqsz; rewrite -!cats1 mask_cat; case: b => //; rewrite cats0.
  qed.
  
  (* -------------------------------------------------------------------- *)
  lemma mask_zip ['a 'b] (m : bool list) (xs : 'a list) (ys : 'b list) :
    size xs = size ys =>
    mask m (zip xs ys) = zip (mask m xs) (mask m ys).
  proof.
  elim: m xs ys => // b m ih xs ys.
  case: xs ys => [|x xs] [|y ys] //=; ~-1:smt(size_ge0).
  by move/addrI/ih => {ih}ih /#.
  qed.
  
  (* -------------------------------------------------------------------- *)
  lemma undup_from_mask ['a] (s : 'a list) :
    undup s = mask (undup_mask s) s.
  proof. by elim: s => //= x s ih; rewrite if_neg; case: (x \in s). qed.
  
  (* -------------------------------------------------------------------- *)
  lemma size_undup_mask ['a] (s : 'a list) : size (undup_mask s) = size s.
  proof. by rewrite /undup_mask size_mkseq //; smt(List.size_ge0). qed.

  (* -------------------------------------------------------------------- *)
  lemma assoc_seq1 ['a 'b] (x1 x2 : 'a) (y : 'b) :
     assoc [(x1, y)] x2 = (x1 = x2) ? Some y : None.
  proof. by rewrite assoc_cons assoc_nil [x2 = x1] eq_sym. qed.

  (* -------------------------------------------------------------------- *)
  lemma assoc_rev_uniq ['a 'b] (xs : 'a list) (vs : 'b list) :
       size xs = size vs
    => uniq xs
    => assoc (rev (zip xs vs)) = assoc (zip xs vs).
  proof.
  move => ??.
  apply fun_ext => x.
  case: (assoc (zip xs vs) x = None).
  - by smt(assoc_none mem_rev).
  - move => ?.
    have Hb: exists v, assoc (zip xs vs) x = Some v by smt().
  elim Hb => v Hsome; rewrite Hsome.
  apply mem_assoc_uniq.
  - rewrite map_rev rev_uniq.
    apply nth_uniq => i j.
    rewrite size_map size_zip lez_minl 1:IntOrder.lerr_eq // => ???.
    rewrite !(nth_map (witness, witness) witness) /=;
      1,2: by rewrite size_zip lez_minl 1:IntOrder.lerr_eq.
    rewrite !(nth_zip witness witness) 1,2:/# /=.
    by smt(nth_uniqP).
  - by rewrite mem_rev assoc_some.
  qed.

  (* -------------------------------------------------------------------- *)
  lemma assoc_undup_mask ['a 'b] (s : ('a * 'b) list) (x : 'a) :
    assoc (rev s) x = assoc (mask (undup_mask (unzip1 s)) s) x.
  proof.
  elim: s => // -[y v] s ih; rewrite rev_cons.
  rewrite -cats1 assoc_cat map_rev mem_rev /= if_neg.
  case: (y \in unzip1 s) => y_in_s1.
  - case: (x \in unzip1 s) => // nx_in_s1.
    rewrite assoc_seq1 ifF 1:/# eq_sym -negbK assocTP.
    apply: contra nx_in_s1; apply/subseq_mem/map_subseq/subseqP.
    by exists (undup_mask (unzip1 s)) => /=; rewrite size_undup_mask size_map.
  - case: (x \in unzip1 s) => [?|nx_in_s1]; first by rewrite assoc_cons ifF 1:/#.
    rewrite assoc_seq1 assoc_cons [y = _]eq_sym; case: (x = y) => // ne_xy.
    apply/eq_sym; rewrite -negbK assocTP.
    apply: contra nx_in_s1; apply/subseq_mem/map_subseq/subseqP.
    by exists (undup_mask (unzip1 s)) => /=; rewrite size_undup_mask size_map.
  qed.

  lemma take_succ_snoc ['a] (xs : 'a list) (n : int) :
    0 <= n < size xs =>
    take (n + 1) xs = take n xs ++ [xs.[n]].
  proof.
  move => Hn.
  have -> := take_nth witness n xs _ ; first by smt().
  by rewrite cats1.
  qed.

  lemma cat11 ['a] (x y : 'a) :
    [x; y] = [x] ++ [y].
  proof. by done. qed.

end ListUtils.

(* ======================== IntOrder ============================= *)

lemma ler_minr: forall (x y : int), y <= x <=> min x y = y by smt().
lemma ler_minl: forall (x y : int), x <= y <=> min x y = x by smt().

lemma minrE_lt (x y : int) : min x y = if x < y then x else y by smt().

lemma ler_min (w x y : int) : w <= min x y <=> (w <= x /\ w <= y) by smt().

(* ======================== big operator ============================= *)

lemma big_disjoint_union ['a] (P Q : 'a -> bool) (f : 'a -> real) (s : 'a list) :
     (forall x, x \in s => !(P x /\ Q x) /\ (P x \/ Q x))
  => Bigreal.BRM.big (predU P Q) f s = Bigreal.BRM.big P f s * Bigreal.BRM.big Q f s.
proof.
elim s.
+ by rewrite !Bigreal.BRM.big_nil /#.
+ move => @/predU x l ih ih_c.
  rewrite !Bigreal.BRM.big_cons /=.
  case _ : (P x) => /= ?.
  + have -> /= : ! Q x by smt().
    rewrite ih -1:/# => y.
    have := ih_c y.
    by rewrite in_cons /#.
  + have ^? -> /= : Q x by smt().
    rewrite ih -1:/# => y.
    have := ih_c y.
    by rewrite in_cons /#.
qed.

(* ======================== iter ========================= *)

lemma iter_expr (x : real) (n : int) :
  x <> 0%r => 0 <= n => iter n (( * ) x) 1%r = x ^ n.
proof.
move => ?.
elim n.
+ by rewrite iter0 1:// RField.expr0.
+ move => i ?; rewrite iterS 1:// => ->.
  by rewrite -{1} (RField.expr1 x) -RField.exprD 1:// /#.
qed.

(* ======================== fset ============================= *)
theory FSetUtils.
  pred fdisjoint ['a] (s1 s2 : 'a fset) =
    forall x, x \notin s1 \/ x \notin s2.

  pred f_big_disjoint ['a] (ms : 'a fset list) =
    forall i j, 0 <= i < size ms => 0 <= j < size ms => i <> j =>
      fdisjoint (nth fset0 ms i) (nth fset0 ms j).
end FSetUtils.

(* ======================== fmap ============================= *)

theory FMapUtils.
  (* Distributivity of map over join *)
  lemma map_join ['a 'b 'c] (m1 m2 : ('a, 'b) fmap) (f : 'a -> 'b -> 'c) :
    map f (m1 + m2) = (map f m1) + (map f m2).
  proof.
  rewrite -fmap_eqP => v.
  case (v \in m1 + m2) => Hv.
  + apply oget_ext.
    + by rewrite -domE mem_map.
    + by rewrite -domE mem_join !mem_map -mem_join.
    + rewrite oget_map 1:// (joinE (map f m1)).
      case (v \in m2) => Hm2.
      + by rewrite mem_map joinE !Hm2 /= oget_map.
      + rewrite mem_join in Hv.
        by rewrite mem_map joinE !Hm2 /= oget_map /#.
  + apply (eq_trans _ None).
    + by rewrite -domNE mem_map.
    + rewrite eq_sym -domNE mem_join !mem_map.
      by rewrite mem_join in Hv.
  qed.

  (* Distributivity of filter over join *)
  lemma filter_join_fset ['a 'b] (m1 m2 : ('a, 'b) fmap) (p : 'a -> 'b -> bool) :
       (forall v, !(v \in m1 /\ v \in m2))
    => filter p (m1 + m2) = (filter p m1) + (filter p m2).
  proof.
  rewrite -fmap_eqP => H v.
  rewrite joinE !filterE joinE mem_filter.
  case (v \in m1) => Hm1.
  + have Hm2 : v \notin m2 by smt().
    rewrite fmapP in Hm1; elim Hm1 => y1 ->.
    by rewrite Hm2.
  + by smt().
  qed.

  lemma filter_join_pred ['a 'b] (m : ('a, 'b) fmap) (p1 p2 : 'a -> 'b -> bool) :
    filter p1 m + filter p2 m = filter (fun a b => p1 a b \/ p2 a b) m.
  proof.
  rewrite -fmap_eqP => v.
  rewrite joinE !filterE /=.
  case (v \in m) => Hm.
  + case (p2 v (oget m.[v])) => Hp2.
    - by rewrite mem_filter Hm Hp2 /#.
    - by rewrite (:! v \in filter p2 m) /= 1:#smt:(mem_filter) /#.
  + by smt().
  qed.

  (* all: check that predicate holds for every binding in a map *)
  op all ['a 'b] (P : 'a -> 'b -> bool) (m : ('a, 'b) fmap) : bool =
    ! has (fun x y => ! P x y) m.

  lemma allP ['a 'b] (P : 'a -> 'b -> bool) (m : ('a, 'b) fmap) :
    all P m <=> (forall x y, m.[x] = Some y => P x y).
  proof.
  rewrite /all hasP /=; split.
  + move => Hnh x y Hxy; case (P x y) => // Hnp.
    by apply Hnh; exists x y.
  + by smt().
  qed.

  lemma all_empty ['a 'b] (P : 'a -> 'b -> bool) :
    all P empty<:'a, 'b>.
  proof. by rewrite allP => x y; rewrite emptyE. qed.

  lemma all_set ['a 'b] (P : 'a -> 'b -> bool) (m : ('a, 'b) fmap) x v :
    all P m.[x <- v] <=> P x v /\ all P (rem m x).
  proof.
  rewrite !allP; split.
  + move => H; split.
    - by have := H x v; rewrite get_set_sameE.
    - by move => x' y' Hx'; apply (H x' y'); smt(get_setE remE).
  + by move => [Hpxv Hrem] x' y'; smt(get_setE remE).
  qed.

  lemma all_filter ['a 'b] (P : 'a -> 'b -> bool) (Q : 'a -> 'b -> bool) (m : ('a, 'b) fmap) :
    all P m => all P (filter Q m).
  proof.
  rewrite !allP => H x y.
  by rewrite filterE; smt(domE oget_some).
  qed.

  lemma all_filter_imp ['a 'b] (P : 'a -> 'b -> bool) (Q : 'a -> 'b -> bool) (m : ('a, 'b) fmap) :
    (forall x y, Q x y => P x y) =>
    all P (filter Q m).
  proof.
  rewrite allP => H x y.
  by rewrite filterE; smt(domE oget_some).
  qed.

  lemma all_map ['a 'b 'c] (P : 'a -> 'c -> bool) (f : 'a -> 'b -> 'c) (m : ('a, 'b) fmap) :
    all P (map f m) <=> all (fun x y => P x (f x y)) m.
  proof.
  rewrite !allP; split.
  + move => H x y Hxy.
    have := H x (f x y).
    by rewrite mapE Hxy.
  + move => H x y Hmap.
    have Hxm : x \in m by smt(mem_map).
    have [v Hv] : exists v, m.[x] = Some v by smt(domE).
    have := H x v Hv => /=.
    by move: Hmap; rewrite mapE Hv /= => [->].
  qed.

  lemma eq_map ['a 'b 'c] (m1 m2 : ('a, 'b) fmap) (f1 f2 : 'a -> 'b -> 'c) :
    f1 = f2 => m1 = m2 => map f1 m1 = map f2 m2.
  proof. by move => -> ->. qed.

  lemma eq_map_in ['a 'b 'c] (m : ('a, 'b) fmap) (f1 f2 : 'a -> 'b -> 'c) :
       (forall x, x \in m => let y = oget m.[x] in f1 x y = f2 x y)
    => map f1 m = map f2 m.
  proof.
  move => H.
  rewrite -fmap_eqP => x.
  rewrite !mapE /=.
  case (m.[x] = None) => [ -> | ^Hsome ] //=.
  rewrite -domE &H /= in Hsome.
  by move /some_oget => ->.
  qed.

  lemma eq_filter ['a 'b] (m1 m2 : ('a, 'b) fmap) (p1 p2 : 'a -> 'b -> bool) :
    p1 = p2 => m1 = m2 => filter p1 m1 = filter p2 m2.
  proof. by move => -> ->. qed.

  lemma filter_filter ['a 'b] (m : ('a, 'b) fmap) (p1 p2 : 'a -> 'b -> bool) :
    filter p1 (filter p2 m) = filter (fun x y => p1 x y /\ p2 x y) m.
  proof.
  rewrite -fmap_eqP => x.
  by rewrite !filterE /#.
  qed.

  lemma map_map ['a 'b 'c 'd] (m : ('a, 'b) fmap)
                              (f1 : 'a -> 'b -> 'c)
                              (f2 : 'a -> 'c -> 'd) :
    map f2 (map f1 m) = map (fun x y => f2 x (f1 x y)) m.
  proof.
  rewrite -fmap_eqP => v.
  rewrite !mapE /=.
  case (m.[v] = None) => [ -> | ] //=.
  rewrite -some_not_none.
  by elim => y ->.
  qed.

  lemma filter_predT_in ['a 'b] (m : ('a, 'b) fmap) (p : 'a -> 'b -> bool) :
    (forall x, x \in m => p x (oget m.[x])) => filter p m = m.
  proof.
  move => H.
  rewrite -fmap_eqP => x.
  case (m.[x] = None) => [ ^? -> | ] //=.
  + by rewrite -domNE mem_filter /#.
  + rewrite -domNE /= => ?.
    by rewrite get_filter 1:#smt:(mem_filter).
  qed.

  lemma map_idfun_in ['a 'b] (m : ('a, 'b) fmap) (f : 'a -> 'b -> 'b) :
    (forall x, x \in m => f x (oget m.[x]) = oget m.[x]) => map f m = m.
  proof.
  move => H.
  rewrite -fmap_eqP => x.
  case (m.[x] = None) => [ ^? -> | ] //=.
  + by smt(domNE mem_map).
  + rewrite -domNE /= => ?.
    apply oget_ext.
    + by rewrite -domE mem_map.
    + by rewrite -domE.
    + by rewrite oget_map 1:// /#.
  qed.

  lemma empty_join ['a 'b] (m : ('a, 'b) fmap) :
    FMap.empty + m = m.
  proof.
  rewrite -fmap_eqP => v.
  rewrite joinE emptyE.
  by case (v \in m) => //= /#.
  qed.

  lemma join_empty ['a 'b] (m : ('a, 'b) fmap) :
    m = FMap.empty + m.
  proof.
  rewrite -fmap_eqP => v.
  rewrite joinE emptyE.
  by case (v \in m).
  qed.

  lemma joinC ['a 'b] (m1 m2 : ('a, 'b) fmap) :
       (forall v, !(v \in m1 /\ v \in m2))
    => m1 + m2 = m2 + m1.
  proof.
  move => ?.
  rewrite -fmap_eqP => v.
  by rewrite !joinE /#.
  qed.

  lemma joinA ['a 'b] (m1 m2 m3 : ('a, 'b) fmap) :
    (m1 + m2) + m3 = m1 + (m2 + m3).
  proof.
  rewrite -fmap_eqP => v.
  by rewrite !joinE mem_join /#.
  qed.

  lemma join0 ['a 'b] (m : ('a, 'b) fmap) :
    empty + m = m.
  proof. rewrite -fmap_eqP => x //=; by smt(joinE mem_empty emptyE). qed.

  lemma join0r ['a 'b] (m : ('a, 'b) fmap) :
    m + empty = m.
  proof. rewrite -fmap_eqP => x; by smt(joinE mem_empty emptyE). qed.

  lemma eq_join ['a 'b] (m1 m1' m2 m2' : ('a, 'b) fmap) :
       m1 = m1'
    => m2 = m2'
    => m1 + m2 = m1' + m2'.
  proof. by move => -> ->. qed.

  (* ------------------------------------------------------------------ *)
  (* Map difference: m1 - m2 removes all keys of m2 from m1             *)
  op (-) ['a 'b] (m1 m2 : ('a, 'b) fmap) : ('a, 'b) fmap =
    filter (fun k _ => k \notin m2) m1.

  (* ------------------------------------------------------------------ *)
  lemma get_none ['a, 'b]:
    forall (m : ('a, 'b) fmap) (x : 'a),
      x \notin m <=> m.[x] = None.
  proof. by smt(). qed.

  (* ------------------------------------------------------------------ *)
  (* big union *)
  op f_big_union ['a 'b] (ms : ('a, 'b) fmap list) : ('a, 'b) fmap =
    foldr (+) empty ms.

  (* ------------------------------------------------------------------ *)
  (* big disjoint *)
  pred f_big_disjoint ['a 'b] (ms : ('a, 'b) fmap list) =
    forall i j, 0 <= i < size ms => 0 <= j < size ms => i <> j =>
      forall x, x \in nth empty ms i => x \notin nth empty ms j.

  lemma f_big_union_cons ['a 'b] (m : ('a, 'b) fmap) (ms : ('a, 'b) fmap list) :
    f_big_union (m :: ms) = m + f_big_union ms.
  proof. by rewrite /f_big_union /=. qed.

  lemma f_big_union_nil ['a 'b] :
    f_big_union [<:('a, 'b) fmap>] = empty.
  proof. by rewrite /f_big_union /=. qed.


  lemma f_big_union_cat ['a 'b] (ms1 ms2 : ('a, 'b) fmap list) :
    f_big_union (ms1 ++ ms2) = f_big_union ms1 + f_big_union ms2.
  proof.
  elim: ms1 => /= [| m ms1 IH].
  + by rewrite /f_big_union /= join0.
  + by rewrite !f_big_union_cons IH joinA.
  qed.

  (* --- main lemmas --- *)

  lemma f_big_disjoint1 ['a 'b] (m : ('a, 'b) fmap) :
    f_big_disjoint [m].
  proof. rewrite /f_big_disjoint => i j Hi Hj Hneq. smt(). qed.

  (* Under disjointness, join is commutative *)
  lemma fmap_joinC_disj ['a 'b] (m1 m2 : ('a, 'b) fmap) :
    (forall x, x \in m1 => x \notin m2) =>
    m1 + m2 = m2 + m1.
  proof.
  move => Hdisj; rewrite -fmap_eqP => x.
  rewrite !joinE; case (x \in m1) => Hm1; case (x \in m2) => Hm2 => //.
  + by have := Hdisj x Hm1.
  + by smt(domE).
  qed.

  (* Disjointness of a sublist (drop head) *)
  lemma f_big_disjoint_cons ['a 'b] (m : ('a, 'b) fmap) (ms : ('a, 'b) fmap list) :
    f_big_disjoint (m :: ms) => f_big_disjoint ms.
  proof.
  rewrite /f_big_disjoint => Hdisj i j Hi Hj Hneq x Hx.
  have := Hdisj (i+1) (j+1) _ _ _ x _ => /=; smt().
  qed.

  (* Removing an element from the middle preserves disjointness *)
  lemma f_big_disjoint_remove ['a 'b] (m : ('a, 'b) fmap) (ms1 ms2 : ('a, 'b) fmap list) :
    f_big_disjoint (ms1 ++ m :: ms2) => f_big_disjoint (ms1 ++ ms2).
  proof.
  rewrite /f_big_disjoint => Hdisj i j Hi Hj Hneq x Hx.
  pose i' := if i < size ms1 then i else i + 1.
  pose j' := if j < size ms1 then j else j + 1.
  have Hi' : 0 <= i' < size (ms1 ++ m :: ms2) by rewrite /i'; smt(size_cat).
  have Hj' : 0 <= j' < size (ms1 ++ m :: ms2) by rewrite /j'; smt(size_cat).
  have Hneq' : i' <> j' by rewrite /i' /j'; smt(size_cat).
  have Eqi : nth empty (ms1 ++ ms2) i = nth empty (ms1 ++ m :: ms2) i'.
  + by rewrite /i' !nth_cat /=; smt().
  have Eqj : nth empty (ms1 ++ ms2) j = nth empty (ms1 ++ m :: ms2) j'.
  + by rewrite /j' !nth_cat /=; smt().
  move: Hx; rewrite Eqi => Hx; rewrite Eqj; exact (Hdisj i' j' Hi' Hj' Hneq' x Hx).
  qed.

  (* x in head means x not in f_big_union of tail *)
  lemma f_big_union_notin_head ['a 'b] (m : ('a, 'b) fmap) (ms : ('a, 'b) fmap list) (x : 'a) :
    f_big_disjoint (m :: ms) => x \in m => x \notin f_big_union ms.
  proof.
  rewrite /f_big_union.
  elim: ms => [| n ns IH] Hdisj Hm.
  + by rewrite mem_empty.
  + rewrite /= mem_join; apply/negP => -[Hn | Hns].
    - have := Hdisj 0 1 _ _ _ x _ => /=; by smt(List.size_ge0).
    - have Hdisj' : f_big_disjoint (m :: ns).
      * by apply (f_big_disjoint_remove n [m] ns).
      have := IH Hdisj' Hm.
      by smt(List.size_ge0).
  qed.

  (* Membership in nth implies membership in f_big_union *)
  lemma f_big_union_mem_nth ['a 'b] (ms : ('a, 'b) fmap list) (x : 'a) (i : int) :
    0 <= i < size ms => x \in nth empty ms i => x \in f_big_union ms.
  proof.
  elim: ms i => [| m ms IH] i Hi Hx; first by smt().
  rewrite f_big_union_cons mem_join.
  case (i = 0) => Hi0.
  + by left; smt().
  + right; apply (IH (i - 1) _ _); smt().
  qed.

  (* Not in f_big_union implies not in any nth *)
  lemma f_big_union_notin_nth ['a 'b] (ms : ('a, 'b) fmap list) (x : 'a) (i : int) :
    0 <= i < size ms => x \notin f_big_union ms => x \notin nth empty ms i.
  proof.
  move => Hi Hn; case (x \in nth empty ms i) => // Hx.
  by move: Hn; rewrite (f_big_union_mem_nth ms x i Hi Hx).
  qed.

  (* map distributes over f_big_union *)
  lemma map_f_big_union ['a 'b 'c] (f : 'a -> 'b -> 'c) (ms : ('a, 'b) fmap list) :
    FMap.map f (f_big_union ms) = f_big_union (List.map (FMap.map f) ms).
  proof.
  elim: ms => [| m ms IH].
  + by rewrite /f_big_union /= map_empty.
  + by rewrite f_big_union_cons map_join IH -f_big_union_cons.
  qed.

  (* Under disjointness, f_big_union (m :: ms) = f_big_union (ms ++ [m]) *)
  lemma f_big_union_disj_cons ['a 'b] (m : ('a, 'b) fmap) (ms : ('a, 'b) fmap list) :
    f_big_disjoint (m :: ms) =>
    f_big_union (m :: ms) = f_big_union (ms ++ [m]).
  proof.
  move => Hdisj.
  rewrite f_big_union_cons.
  rewrite (_ : f_big_union (ms ++ [m]) = f_big_union ms + f_big_union [m]).
  + by rewrite f_big_union_cat.
  rewrite f_big_union_cons f_big_union_nil join0r.
  rewrite fmap_joinC_disj //.
  by move => x Hm; apply (f_big_union_notin_head m ms x Hdisj Hm).
  qed.

  (* head is disjoint from each element of tail *)
  lemma f_big_disjoint_head ['a 'b] (m : ('a, 'b) fmap) (ms : ('a, 'b) fmap list) :
    f_big_disjoint (m :: ms) =>
    forall k, 0 <= k < size ms => forall x, x \in m => x \notin nth empty ms k.
  proof.
  rewrite /f_big_disjoint => Hdisj k Hk x Hx.
  have := Hdisj 0 (k+1) _ _ _ x Hx => /=; smt().
  qed.

  (* element of tail is disjoint from head *)
  lemma f_big_disjoint_head_rev ['a 'b] (m : ('a, 'b) fmap) (ms : ('a, 'b) fmap list) :
    f_big_disjoint (m :: ms) =>
    forall k, 0 <= k < size ms => forall x, x \in nth empty ms k => x \notin m.
  proof.
  rewrite /f_big_disjoint => Hdisj k Hk x Hx.
  have := Hdisj (k+1) 0 _ _ _ x _; smt().
  qed.

  lemma f_big_disjoint_perm_eq ['a 'b] (m1 m2 : ('a, 'b) fmap list) :
    perm_eq m1 m2 => f_big_disjoint m1 <=> f_big_disjoint m2.
  proof.
  move => Hperm; suff H : forall (s1 s2 : ('a, 'b) fmap list),
    perm_eq s1 s2 => f_big_disjoint s1 => f_big_disjoint s2.
  + by split; [apply H | apply H; apply perm_eq_sym].
  move => {m1 m2 Hperm}; elim => [| m ms IH] s2 Hperm Hdisj.
  + have -> // : s2 = [].
    by rewrite -perm_eq_nil perm_eq_sym.
  + have Hm_in : m \in s2 by smt(perm_eq_mem).
    have [t1 t2 ->>] := splitPr s2 m Hm_in.
    have Hperm2 : perm_eq ms (t1 ++ t2).
    + have /perm_eqlP Hp1 := perm_catCA t1 [m] t2.
      have /perm_eqlP Hp2 := Hperm.
      have Hp3 : perm_eq (m :: ms) (m :: t1 ++ t2).
      * by rewrite Hp2 -cat1s catA Hp1 /= perm_eq_refl.
      smt(perm_cons).
    have Hdisj_ms := f_big_disjoint_cons m ms Hdisj.
    have Hdisj_t := IH _ Hperm2 Hdisj_ms.
    rewrite /f_big_disjoint => i j Hi Hj Hneq x Hx.
    have Hsz := size_cat t1 (m :: t2).
    have Hszt := size_cat t1 t2.
    have Hhead := f_big_disjoint_head m ms Hdisj.
    have Hhead_r := f_big_disjoint_head_rev m ms Hdisj.
    case (i = size t1) => Hi_eq; case (j = size t1) => Hj_eq.
    - by smt().
    - subst i; rewrite nth_cat /= in Hx.
      have Hj2 : 0 <= (if j < size t1 then j else j-1) < size (t1 ++ t2) by smt().
      have Hntj : nth empty (t1 ++ m :: t2) j = nth empty (t1 ++ t2) (if j < size t1 then j else j-1) by smt(nth_cat).
      rewrite Hntj.
      have Hin : nth empty (t1 ++ t2) (if j < size t1 then j else j-1) \in (t1 ++ t2) by smt(mem_nth).
      have Hin_ms : nth empty (t1 ++ t2) (if j < size t1 then j else j-1) \in ms by smt(perm_eq_mem).
      have /nthP Hnth := Hin_ms.
      have [k [Hk Hkv]] := Hnth empty.
      by rewrite -Hkv; apply (Hhead k) => /#.
    - (* j = size t1, so nth at j = m. Need x \notin m.
         x in nth (t1++m::t2) i where i <> size t1, so x is in some t1++t2 element.
         That element is in ms by perm. So x \notin m by Hhead_r. *)
      have Hi2 : 0 <= (if i < size t1 then i else i-1) < size (t1 ++ t2) by smt().
      have Hnti : nth empty (t1 ++ m :: t2) i = nth empty (t1 ++ t2) (if i < size t1 then i else i-1) by smt(nth_cat).
      have Hx2 : x \in nth empty (t1 ++ t2) (if i < size t1 then i else i-1) by smt().
      have Hin : nth empty (t1 ++ t2) (if i < size t1 then i else i-1) \in (t1 ++ t2) by smt(mem_nth).
      have Hin_ms : nth empty (t1 ++ t2) (if i < size t1 then i else i-1) \in ms by smt(perm_eq_mem).
      have /nthP Hnth := Hin_ms; have [k [Hk Hkv]] := Hnth empty.
      have Hx3 : x \in nth empty ms k by smt().
      by smt(nth_cat).
    - have Hi2 : 0 <= (if i < size t1 then i else i-1) < size (t1 ++ t2) by smt(List.size_ge0).
      have Hj2 : 0 <= (if j < size t1 then j else j-1) < size (t1 ++ t2) by smt(List.size_ge0).
      have Hneq2 : (if i < size t1 then i else i-1) <> (if j < size t1 then j else j-1) by smt().
      have := Hdisj_t _ _ Hi2 Hj2 Hneq2 x.
      smt(nth_cat).
  qed.

  lemma big_union_perm_eq ['a 'b] (m1 m2 : ('a, 'b) fmap list) :
       perm_eq m1 m2
    => f_big_disjoint m1
    => f_big_union m1 = f_big_union m2.
  proof.
  elim: m1 m2 => [| m ms IH] m2 Hperm Hdisj.
  + by have -> : m2 = [] by smt(perm_eq_sym perm_eq_nil).
  + have Hm_in : m \in m2 by smt(perm_eq_mem).
    have [s1 s2 ->>] := splitPr m2 m Hm_in.
    rewrite f_big_union_cons.
    have Hperm2 : perm_eq ms (s1 ++ s2).
    + have /perm_eqlP Hp1 := perm_catCA s1 [m] s2.
      have /perm_eqlP Hp2 := Hperm.
      have Hp3 : perm_eq (m :: ms) (m :: s1 ++ s2).
      * by rewrite Hp2 -cat1s catA Hp1 /= perm_eq_refl.
      smt(perm_cons).
    have Hdisj_ms := f_big_disjoint_cons m ms Hdisj.
    rewrite (IH (s1 ++ s2) Hperm2 Hdisj_ms).
    rewrite f_big_union_cat.
    rewrite -f_big_union_cat -f_big_union_cons.
    rewrite f_big_union_disj_cons.
    - by rewrite (f_big_disjoint_perm_eq _ (m :: ms)) //; smt(perm_cons perm_eq_sym).
    rewrite -catA !f_big_union_cat f_big_union_cons f_big_union_nil join0r.
    congr.
    have Hdisj2 : f_big_disjoint (m :: s1 ++ s2).
    + by rewrite (f_big_disjoint_perm_eq _ (m :: ms)) //; smt(perm_cons perm_eq_sym).
    rewrite fmap_joinC_disj // => x Hx.
    case (x \in m) => // Hxm.
    have := f_big_union_notin_head m (s1 ++ s2) x Hdisj2 Hxm.
    by rewrite f_big_union_cat mem_join Hx.
  qed.

  (* f_big_union distributes over ++ *)
  lemma f_big_disjoint_cat ['a 'b] (ms1 ms2 : ('a, 'b) fmap list) :
    f_big_disjoint (ms1 ++ ms2) => f_big_disjoint ms1 /\ f_big_disjoint ms2.
  proof.
  elim: ms1 => [| m ms1 IH] Hdisj.
  + by split => //; rewrite /f_big_disjoint /= /#.
  + have Hdm := f_big_disjoint_cons m (ms1 ++ ms2) Hdisj.
    have [H1 H2] := IH Hdm.
    split => //.
    (* show f_big_disjoint (m :: ms1) *)
    rewrite /f_big_disjoint => i j Hi Hj Hneq x Hx.
    have Hi2 : 0 <= i < size (m :: ms1 ++ ms2) by smt(size_cat List.size_ge0).
    have Hj2 : 0 <= j < size (m :: ms1 ++ ms2).
    + by rewrite /= size_cat; smt(List.size_ge0).
    have Hxi : nth empty (m :: ms1) i = nth empty (m :: ms1 ++ ms2) i.
    + case (i = 0) => [->|Hne] //=; by rewrite !nth_cat /= /#.
    have Hxj : nth empty (m :: ms1) j = nth empty (m :: ms1 ++ ms2) j.
    + case (j = 0) => [->|Hne] //=; by rewrite !nth_cat /= /#.
    smt().
  qed.

  lemma f_big_disjoint_union ['a 'b] (a b c d : ('a, 'b) fmap list) :
       f_big_union a = f_big_union c
    => f_big_union b = f_big_union d
    => all f_big_disjoint [a; b; c; d]
    => ((f_big_disjoint (a ++ b) <=> f_big_disjoint (c ++ d))
         /\ f_big_union (a ++ b) = f_big_union (c ++ d)
       ).
  proof.
  move => Hac Hbd Hall.
  split; last by rewrite !f_big_union_cat Hac Hbd.
  (* Helper: element of ms.[i] is in f_big_union ms *)
  have Hmem_union : forall (ms : ('a,'b) fmap list), f_big_disjoint ms =>
    forall x i, 0 <= i < size ms => x \in nth empty ms i => x \in f_big_union ms.
  + elim => [| m ms IH] Hdisj x i Hi Hx; first by smt().
    rewrite f_big_union_cons mem_join.
    case (i = 0) => Hi0; first by left; smt().
    right; apply (IH (f_big_disjoint_cons m ms Hdisj) x (i-1) _ _); smt().
  (* Helper: f_big_union notin means not in any element *)
  have Hnotin_all : forall (ms : ('a,'b) fmap list) x, f_big_disjoint ms =>
    x \notin f_big_union ms => forall i, 0 <= i < size ms => x \notin nth empty ms i.
  + by move => ms x Hd Hn i Hi; case (x \in nth empty ms i) => // Hx; move: Hn; rewrite (Hmem_union ms Hd x i Hi Hx).
  (* Helper: x in f_big_union ms implies x in some element *)
  have Hmem_union_inv : forall (ms : ('a,'b) fmap list) x,
    x \in f_big_union ms => exists i, 0 <= i < size ms /\ x \in nth empty ms i.
  + elim => [| m ms IH] x; first by rewrite f_big_union_nil mem_empty.
    rewrite f_big_union_cons mem_join => -[Hm | Hms].
    - by exists 0 => /=; smt(List.size_ge0).
    - have [i [Hi Hx]] := IH x Hms.
      by exists (i + 1); smt().
  (* Helper: cross-disjointness of unions from disjoint concatenation *)
  have Hcross_disj : forall (s1 s2 : ('a,'b) fmap list) x,
    f_big_disjoint (s1 ++ s2) => x \in f_big_union s1 => x \notin f_big_union s2.
  + move => s1 s2 x0 Hd Hx0.
    have [k [Hk Hx0k]] := Hmem_union_inv s1 x0 Hx0.
    apply/negP => Habs.
    have [l [Hl Hx0l]] := Hmem_union_inv s2 x0 Habs.
    have := Hd k (size s1 + l) _ _ _ x0 _; smt(size_cat nth_cat).
  (* Main: show one direction, the other is symmetric *)
  suff Hdir : forall (a0 b0 c0 d0 : ('a,'b) fmap list),
    f_big_union a0 = f_big_union c0 => f_big_union b0 = f_big_union d0 =>
    all f_big_disjoint [a0; b0; c0; d0] =>
    f_big_disjoint (a0 ++ b0) => f_big_disjoint (c0 ++ d0).
  + by split; [apply Hdir | apply (Hdir c d a b)]; rewrite // /#.
  move => {a b c d Hac Hbd Hall} a b c d Hac Hbd Hall Hdisj_ab.
  have [Hdisj_a Hdisj_b] := f_big_disjoint_cat a b Hdisj_ab.
  have Hdisj_c : f_big_disjoint c by smt().
  have Hdisj_d : f_big_disjoint d by smt().
  rewrite /f_big_disjoint => i j Hi Hj Hneq x Hx.
  have Hszc := size_cat c d; have Hsza := size_cat a b.
  case (i < size c) => Hic; case (j < size c) => Hjc.
  + (* both in c: use internal disjointness of c *)
    smt(nth_cat).
  + (* i in c, j in d: cross-disjointness via unions *)
    have Hx_c : x \in f_big_union c by apply (Hmem_union c Hdisj_c x i); smt(nth_cat).
    have Hx_a : x \in f_big_union a by rewrite Hac.
    have Hx_notin_b := Hcross_disj a b x Hdisj_ab Hx_a.
    have Hx_notin_d : x \notin f_big_union d by rewrite -Hbd.
    have := Hnotin_all d x Hdisj_d Hx_notin_d (j - size c) _.
    - by smt().
    - by smt(nth_cat).
  + (* i in d, j in c: symmetric *)
    have Hx_d : x \in f_big_union d by apply (Hmem_union d Hdisj_d x (i - size c)); smt(nth_cat).
    have Hx_b : x \in f_big_union b by rewrite Hbd.
    have Hdisj_ba : f_big_disjoint (b ++ a) by rewrite (f_big_disjoint_perm_eq _ (a++b)) // perm_catC.
    have Hx_notin_a := Hcross_disj b a x Hdisj_ba Hx_b.
    have Hx_notin_c : x \notin f_big_union c by rewrite -Hac.
    have := Hnotin_all c x Hdisj_c Hx_notin_c j _.
    - by smt().
    - by smt(nth_cat).
  + (* both in d *)
    smt(nth_cat).
  qed.

  lemma f_big_union1 ['a 'b] (m : ('a, 'b) fmap) :
    f_big_union [m] = m.
  proof. by rewrite /f_big_union /= join0r. qed.

  lemma f_big_union2 ['a 'b] (m1 m2 : ('a, 'b) fmap) :
    f_big_union [m1 ; m2] = m1 + m2.
  proof. by rewrite /f_big_union /= join0r. qed.

end FMapUtils.

(* ======================== distribution ============================== *)
theory DistrUtils.
  lemma muC ['a] (d : 'a distr) (b : bool) :
    mu d (fun _ => b) = b2r b * weight d.
  proof. by case: b => _; rewrite ?mu0. qed.

  lemma eq_mu ['a] (d1 d2 : 'a distr) (p q : 'a -> bool) :
    d1 = d2 => p = q => mu d1 p = mu d2 q.
  proof. by move => -> -> //. qed.

  lemma dprod_dunitL ['a 'b] (a : 'a) (db : 'b distr) :
    dunit a `*` db = dmap db (fun b => (a, b)).
  proof. by rewrite dprod_dlet dlet_unit /= dlet_dunit. qed.

  lemma finite_dmap ['a 'b] (d : 'a distr) (f : 'a -> 'b) :
    is_finite (support d) => is_finite (support (dmap d f)).
  proof.
  move=> fin_d; apply: finite_dlet => // @/(\o) /=.
  by move=> x _; apply: finite_dunit.
  qed.

  lemma finite_dlist ['a] (n : int) (d : 'a distr) :
    is_finite (support d) => is_finite (support (dlist d n)).
  proof.
  move=> dfin; elim/natind: n => [n le0_n|n ge0_n ih].
  - by exists [[]] => xs /=; rewrite supp_dlist0.
  - by rewrite dlistS //=; apply/finite_dmap/finite_dprod.
  qed.

  lemma dprod_fst ['a 'b] (d1 : 'a distr) (d2 : 'b distr) :
    weight d2 = 1%r => dfst (d1 `*` d2) = d1.
  proof.
  move => ?.
  apply eq_distr => x.
  rewrite dmap1E /(\o).
  rewrite (mu_eq (d1 `*` d2) _
                 (fun (x0 : 'a * 'b) => pred1 x x0.`1 /\ predT x0.`2)) 1:/#.
  by rewrite (dprodE (pred1 x) predT) /#.
  qed.

  lemma dlist_take ['a] (d : 'a distr) n1 n2:
       0 <= n1 <= n2
    => is_lossless d
    => dlist d n1 = dmap (dlist d n2) (take n1).
  proof.
  move => Hn Hlossless.
  rewrite (: n2 = n1 + (n2 - n1)) 1:/#.
  rewrite dlist_add 1,2:/# dmap_comp /(\o).
  rewrite (eq_dmap_in _ _
             (fun (x : 'a list * 'a list) => x.`1)).
  + move => x.
    rewrite supp_dprod !supp_dlist 1,2:/# => [#] ???? /=.
    by rewrite take_catl 1:/# take_oversize /#.
  rewrite dprod_fst -1://.
  rewrite weight_dlist 1:/#.
  by rewrite Hlossless RField.expr1z.
  qed.

  lemma hasED ['a] (d : 'a distr) (f1 f2 : 'a -> real) :
    hasE d f1 => hasE d f2 => hasE d (fun x => f1 x + f2 x).
  proof.
  move=> h1 h2; have /= := summableD _ _ h1 h2.
  by apply: eq_summable => x /=; ring.
  qed.

  lemma hasE_dunit ['a] (a : 'a) (f : 'a -> real) : hasE (dunit a) f.
  proof. by apply/hasE_finite/finite_dunit. qed.

  lemma hasE_dmap ['a 'b] (da : 'a distr) (f : 'a -> 'b) F :
    hasE (dmap da f) F <=> hasE da (F \o f).
  proof.
  split; last first.
  - move/(summable_partition f); apply: eq_summable => /=.
    by move=> b; rewrite dmap1E muE -sumZ /= &(eq_sum) => a /#.
  case=> M hM; exists M => J uqJ @/(\o).
  have h := hM (undup (map f J)) _; first by apply: undup_uniq.
  apply: (RealOrder.ler_trans _ _ _ _ h).
  pose d b := BRA.big (fun a => b = f a) (fun a => mu1 da a) J.
  pose e := BRA.big predT (fun b => `|F b| * d b) (undup (map f J)).
  apply: (RealOrder.ler_trans e) => @/e => {e}; last first.
  - rewrite !BRA.big_seq; apply: Bigreal.ler_sum => b _ /=.
    rewrite RealOrder.normrM &(RealOrder.ler_wpmul2l) 1:RealOrder.normr_ge0.
    rewrite RealOrder.ger0_norm 1:ge0_mu /d BRA.big_mkcond /=.
    rewrite dmap1E /pred1 /(\o) /= muE.
    apply: (RealOrder.ler_trans _ _ _ _ (ler_big_sum _ J _ uqJ _)) => /=.
    - apply/RealOrder.lerr_eq/BRA.eq_bigr => a _ /=.
      by rewrite [b = f a]eq_sym.
    - by move=> x; case: (_ = b).
    - by apply/summable_cond/summable_mu1.
  apply: RealOrder.lerr_eq; have -> := BRA.partition_big f predT predT
    (fun a => `|F (f a) * mu1 da a|) J (undup (map f J)) _ _.
  - by apply: undup_uniq.
  - by move=> a aJ _ @/predT /=; rewrite mem_undup &(mapP); exists a.
  rewrite !BRA.big_seq &(BRA.eq_bigr) /= => b.
  rewrite mem_undup => /mapP[a] [aJ ->>] @/d.
  rewrite BRA.mulr_sumr &(BRA.eq_big) /= 1:/#.
  by move=> a' [_ ->]; rewrite RealOrder.normrM [`|mu1 _ _|] RealOrder.ger0_norm.
  qed.

  lemma hasED_dprod ['a 'b] (da : 'a distr) (db : 'b distr) fa fb :
       hasE da fa
    => hasE db fb
    => hasE (da `*` db) (fun ab : _ * _ => fa ab.`1 + fb ab.`2).
  proof.
  pose famu := fun a => fa a * mu1 da a.
  pose fbmu := fun b => fb b * mu1 db b.
  move=> ha hb; apply: hasED.
  - have /= := summableM_prod famu (mu1 db) ha (summable_mu1 _).
    by apply: eq_summable => -[a b] /=; rewrite dprod1E /famu #ring.
  - have /= := summableM_prod (mu1 da) fbmu (summable_mu1 _) hb.
    by apply: eq_summable => -[a b] /=; rewrite dprod1E /fbmu #ring.
  qed.

  lemma hasED_dlist ['a] (da : 'a distr) (n : int) f : 0 <= n =>
    hasE da f => hasE (dlist da n) (BRA.big predT f).
  proof.
  move=> ge0_n Ef; elim: n ge0_n; first by rewrite dlist0 // hasE_dunit.
  move=> n ge0_n ih; rewrite dlistS //= hasE_dmap /(\o) /=.
  have := hasED_dprod _ _ _ _ Ef ih; apply: eq_summable => /=.
  by case=> [x xs] /=; rewrite BRA.big_consT.
  qed.

  lemma expD_dprod ['a 'b] (da : 'a distr) (db : 'b distr) fa fb :
       hasE da fa
    => hasE db fb
    =>   E (da `*` db) (fun ab : _ * _ => fa ab.`1 + fb ab.`2)
       = weight db * E da fa + weight da * E db fb.
  proof.
  move=> hEa hEb.
  apply: (eq_trans _ (E da (fun a => E db (fun b => fa a + fb b)))).
  - rewrite dprod_dlet exp_dlet; 1: by rewrite -dprod_dlet &(hasED_dprod).
    apply: eq_exp=> a _ /=; rewrite dlet_dunit exp_dmap //.
    by rewrite -dprod_dunitL &(hasED_dprod) // &(hasE_dunit).
  apply: (eq_trans _ (E da (fun a => weight db * (fa a) + E db fb))).
  - by apply: eq_exp=> a _ /=; rewrite expD // 1:&(hasEC) expC #ring.
  - by rewrite expD 1:&(hasEZ) // 1:&(hasEC) expC expZ #ring.
  qed.

  lemma expD_dprodll ['a 'b] (da : 'a distr) (db : 'b distr) fa fb :
       hasE da fa
    => hasE db fb
    => is_lossless da
    => is_lossless db
    =>   E (da `*` db) (fun ab : _ * _ => fa ab.`1 + fb ab.`2)
       = E da fa + E db fb.
  proof.
  move=> ?? lla llb; have := expD_dprod da db fa fb // //.
  by rewrite lla llb /=.
  qed.

  lemma hasEM_dprod ['a 'b] (da : 'a distr) (db : 'b distr) fa fb :
       hasE da fa
    => hasE db fb
    => hasE (da `*` db) (fun ab : _ * _ => fa ab.`1 * fb ab.`2).
  proof.
  pose F (ab : _ * _) := (fa ab.`1 * mu1 da ab.`1) * (fb ab.`2 * mu1 db ab.`2).
  move=> hEa hEb @/hasE; rewrite (eq_summable _ F) /F /= => {F}.
  - by case=> a b /=; rewrite dprod1E #ring.
  by apply: (summableM_prod (fun a => fa a * mu1 da a) (fun b => fb b * mu1 db b)).
  qed.

  lemma hasEM_dlist ['a] (d : 'a distr) (n : int) f : 0 <= n =>
    hasE d f => hasE (dlist d n) (BRM.big predT f).
  proof.
  move=> ge0_n Ef; elim: n ge0_n => [|n ge0_n ih].
  - by rewrite dlist0 // hasE_dunit.
  rewrite dlistS //= hasE_dmap /(\o) /=.
  have := hasEM_dprod _ _ _ _ Ef ih; apply: eq_summable => /=.
  by case=> [x xs] /=; rewrite BRM.big_consT /=.
  qed.

  lemma expM_dprod ['a 'b] (da : 'a distr) (db : 'b distr) fa fb :
       hasE da fa
    => hasE db fb
    =>   E (da `*` db) (fun ab : _ * _ => fa ab.`1 * fb ab.`2)
       = E da fa * E db fb.
  proof.
  move=> hEa hEb @/E; rewrite sum_pair /= 1:&(hasEM_dprod) //.
  rewrite -sumZr /= &(eq_sum) => a /=.
  rewrite -sumZ /= &(eq_sum) => b /=.
  by rewrite dprod1E #ring.
  qed.

  lemma expXD_ll ['a] (d : 'a distr) (n : int) f : 0 <= n =>
       hasE d f
    => is_lossless d
    => E (dlist d n) (BRA.big predT (fun x => f x)) = (E d f) * n%r.
  proof.
  move=> ge0_n Ef lld; elim: n ge0_n => [|n ge0_n ih].
  - by rewrite dlist0 // exp_dunit BRA.big_nil.
  rewrite dlistS //= exp_dmap /(\o) /=.
  - have := hasED_dprod _ _ _ _ Ef (hasED_dlist _ n f ge0_n Ef).
    rewrite hasE_dmap /(\o) /= &(eq_summable) => -[x xs] /=.
    by rewrite BRA.big_consT RField.mulrDl.
  rewrite fromintD RField.mulrDr /= RField.addrC -ih -expD_dprodll //.
  - by apply: hasED_dlist.
  - by apply: dlist_ll.
  qed.

  lemma expXM ['a] (d : 'a distr) (n : int) f : 0 <= n =>
       hasE d f
    => is_lossless d
    => E (dlist d n) (BRM.big predT (fun x => f x)) = (E d f) ^ n.
  proof.
  move=> ge0_n Ef lld; elim: n ge0_n => [|n ge0_n ih].
  - by rewrite dlist0 // exp_dunit BRM.big_nil RField.expr0.
  rewrite dlistS //= exp_dmap /(\o) /=.
  - have := hasEM_dprod _ _ _ _ Ef (hasEM_dlist _ n f ge0_n Ef).
    rewrite hasE_dmap /(\o) /= &(eq_summable) => -[x xs] /=.
    by rewrite BRM.big_consT.
  by rewrite RField.exprS // -ih -expM_dprod // &(hasEM_dlist).
  qed.

  lemma finite_dbiased (p : real) : is_finite (support (dbiased p)).
  proof. by apply/(finite_leq predT)/finite_bool. qed.

  lemma hasE_dbiased (p : real) f : hasE (dbiased p) f.
  proof. by apply/hasE_finite/finite_dbiased. qed.

  lemma exp_dbiased (p : real) f :
    E (dbiased p) f = f false * (1%r - clamp p) + f true * clamp p.
  proof.
  rewrite /E (sumE_fin _ [true; false]) ~-1://#.
  by rewrite BRA.big_consT BRA.big_seq1 /= !dbiased1E /= #ring.
  qed.

  lemma Ep_dbiased : forall (p : real) (f: bool -> _),
    Ep (dbiased p) f = clamp p ** f true + (1%r - clamp p) ** f false.
  proof.
  move => p f; rewrite (Ep_fin [true; false]) //; 1: by case.
  by rewrite /BXA.big /predT /= !dbiased1E /=.
  qed.

  (* -------------------------------------------------------------------- *)
  lemma dlist_subseq ['a] (d : 'a distr) (n p : int) (s : bool list) :
       0 <= n
    => 0 <= p
    => is_lossless d
    => size s = n + p
    => count idfun s = n
    => dmap (dlist d (n + p)) (mask s) = dlist d n.
  proof.
  move=> + + ll_d; elim: s n p => [|b s ih] /= n p ge0_n ge0_p.
  - by move=> + <<- - /= <<-; rewrite dlist0 // dmap_dunit.
  case: b => _; rewrite ?(b2i1, b2i0) /=; last first.
  - move=> *; have gt0_p: 0 < p by smt(count_size).
    rewrite (_ : n + p = (n + (p - 1)) + 1) 1:#ring dlistS 1:/# /=.
    rewrite dmap_comp /(\o) /= (dprod_marginalR _ _ (mask s)).
    by rewrite ll_d dscalar1 ih //#.
  - move=> *; have gt0_n: 0 < n by smt(count_ge0).
    rewrite (_ : n + p = ((n - 1) + p) + 1) 1:#ring dlistS 1:/# /=.
    rewrite dmap_comp /(\o) /= (dmap_dprod_comp _ _ idfun (mask s) (::)).
    by rewrite ih ~-1://# dmap_id (dlistS _ (n - 1)) 1:/#.
  qed.

  (* -------------------------------------------------------------------- *)
  (* When the random tape is in a uniform distribution,                    *)
  (*   the partial permutation of the random tape                          *)
  (*   is also in a uniform distribution.                                  *)
  lemma dmap_dlist_partial_perm ['a] (x0 : 'a) (d : 'a distr) (f : int -> int) (n k : int) :
       0 <= k
    => 0 <= n
    => is_lossless d
    => (forall i j, 0 <= i < k => 0 <= j < k => f i = f j => i = j)
    => (forall i, 0 <= i < k => 0 <= f i < n)
    =>   dmap (dlist d n) (fun xs => mkseq (fun i => nth x0 xs (f i)) k)
       = dlist d k.
  proof.
  move=> ge0_k ge0_n lld injf inrgf.
  elim: k ge0_k n ge0_n f injf inrgf.
  - move=> n ge0_n f injf inrgf; rewrite [dlist d 0]dlist0 //.
    rewrite -(eq_dmap _ (fun _ => [])) //=.
    - by move=> ? /=; rewrite mkseq0.
    by rewrite dmap_cst //; apply/dlist_ll/lld.
  move=> k ge0_k ih n ge0_n f injf inrgf.
  pose k1 := f k; pose k2 := n - (k1 + 1).
  have ->: n = (k1 + 1) + k2 by rewrite /k1 /k2 #ring.
  rewrite dlist_djoin 1:/# -cat_nseq ~-1:/# nseqSr 1:/#.
  rewrite -cats1 -catA /= djoin_perm_s1s /= dmap_dlet /=.
  rewrite -!dlist_djoin ~-1:/# /=.
  pose c (i : int) := f i - b2i (k1 <= f i).
  pose h (a : 'a list) := mkseq (fun i => nth x0 a (c i)) k.
  pose C (a : 'a list * 'a list) := a.`1 ++ a.`2.
  pose F (a : 'a list) (x : 'a) := rcons (h a) x.
  rewrite -(in_eq_dlet (fun (ds : 'a list * 'a list) => dmap d (F (C ds)))).
  - move=> ds /supp_dprod => /= []; rewrite !supp_dlist ~-1:/#.
    move=> [#] hsz1 _ hsz2 _; rewrite dmap_comp &(eq_dmap) /=.
    move=> x @/(\o) /=; rewrite mkseqS 1:/# /F /=; congr; last first.
    - by rewrite nth_cat ifF 1:/# /= ifT 1:/#.
    apply: eq_in_mkseq => i rgi /=; rewrite !nth_cat.
    rewrite /c hsz1 lezNgt; case: (f i < k1) => /= [->//|?].
    by rewrite !ifF ~-1:/# addrAC.
  rewrite -(dlet_dmap _ C (fun ds => dmap d (F ds))) -dlist_add ~-1:/#.
  rewrite -(dmap_dprodE _ _ (fun (xy : _ * _) => F xy.`1 xy.`2)) /F /=.
  rewrite dlistSr ~-1:/# /= !dmap_dprodE_swap /= &(in_eq_dlet) /=.
  move=> x _; rewrite -(dmap_comp h (fun xs => rcons xs x)); congr.
  by apply: ih; smt().
  qed.

end DistrUtils.

(* ======================== PosMap ============================= *)
theory PosMapUtils.
  (* -------------------------------------------------------------------- *)
  op update ['a 'b] (f : 'a -> 'b option) (xvs : ('a * 'b) list) =
    foldl (fun f (xv : 'a * 'b) => f.[xv.`1 <- Some xv.`2]) f xvs.

  (* -------------------------------------------------------------------- *)
  lemma update0 ['a 'b] (f : 'a -> 'b option) : update f [] = f.
  proof. by rewrite /update. qed.

  (* -------------------------------------------------------------------- *)
  lemma updateS ['a 'b] (f : 'a -> 'b option) x v xvs :
    update f ((x, v) :: xvs) = update f.[x <- Some v] xvs.
  proof. by rewrite /update. qed.

  (* -------------------------------------------------------------------- *)
  lemma updateSr ['a 'b] (f : 'a -> 'b option) x v xvs :
    update f (rcons xvs (x, v)) = (update f xvs).[x <- Some v].
  proof. by rewrite /update foldl_rcons. qed.

  (* -------------------------------------------------------------------- *)
  lemma updateE ['a 'b] (f : 'a -> 'b option) xvs y :
    (update f xvs) y =
      if y \in unzip1 xvs then assoc (rev xvs) y else f y.
  proof.
  elim/last_ind: xvs => /= [|xvs [x v] ih]; first by rewrite update0.
  rewrite map_rcons mem_rcons /=; case: (y = x) => [<<-|ne_yx] /=.
  - by rewrite rev_rcons assoc_cons /= updateSr fupdate_eq.
  - by rewrite updateSr fupdate_neq 1:/# rev_rcons assoc_cons ne_yx.
  qed.

  (* -------------------------------------------------------------------- *)
  lemma init_from_assoc ['a 'b] (xvs : ('a * 'b) list) :
    (update (fun _ => None) xvs) = assoc (mask (ListUtils.undup_mask (unzip1 xvs)) xvs).
  proof.
  apply/fun_ext => y.
  rewrite updateE /= ListUtils.assoc_undup_mask; case _: (y \in _)%List => //= h.
  apply/eq_sym; rewrite -negbK assocTP; apply: contra h.
  apply/subseq_mem/map_subseq/subseqP; exists (ListUtils.undup_mask (unzip1 xvs)) => /=.
  by rewrite ListUtils.size_undup_mask size_map.
  qed.

  (* -------------------------------------------------------------------- *)
  lemma init_undup ['a 'b] (xvs : ('a * 'b) list) :
      update (fun _ => None) xvs
    = update (fun _ => None) (mask (ListUtils.undup_mask (unzip1 xvs)) xvs).
  proof.
  rewrite !init_from_assoc; congr; pose s := mask _ xvs.
  rewrite ListUtils.undup_mask_uniq -1:mask_true //.
  - by rewrite /s map_mask -ListUtils.undup_from_mask undup_uniq.
  - by rewrite size_map.
  qed.

  (* -------------------------------------------------------------------- *)
  op d_of_update ['a 'b] (d : 'b distr) (xs : 'a list) =
    dmap
      (dlist d (size xs))
      (fun vs => update (fun _ => None) (zip xs vs)).

  (* -------------------------------------------------------------------- *)
  op d_of_undup_update ['a 'b] (d : 'b distr) (xs : 'a list) =
    dmap
      (dlist d (size (undup xs)))
      (fun vs => update (fun _ => None) (zip (undup xs) vs)).

  (* -------------------------------------------------------------------- *)
  lemma d_of_update_undup ['a 'b] (d : 'b distr) (xs : 'a list) :
    is_lossless d => d_of_update d xs = d_of_undup_update d xs.
  proof.
  move=> lld; rewrite /d_of_update /d_of_undup_update.
  do 2! rewrite -(dmap_comp _ (update (fun _ => None))) /= &(eq_sym).
  pose D := dmap _ (zip (undup _)); pose m := ListUtils.undup_mask xs.
  have ->/=: D = dmap (dlist d (size xs)) (fun vs => zip (mask m xs) (mask m vs)).
  - have ->: size xs = size (undup xs) + (size xs - size (undup xs)) by ring.
    rewrite -(dmap_comp _ (zip (mask m xs))) /= DistrUtils.dlist_subseq // /D => {D}.
    - by rewrite IntOrder.subr_ge0 &(size_undup).
    - by rewrite ListUtils.size_undup_mask; ring.
    - by rewrite -(size_mask _ xs) 1:ListUtils.size_undup_mask // -ListUtils.undup_from_mask.
    - by rewrite -ListUtils.undup_from_mask.
  rewrite !dmap_comp /(\o) /= &(eq_dmap_in) => /= vs.
  have := supp_dlist_size d (size xs) vs.
  rewrite [0 <= size xs] List.size_ge0 /=.
  move => H /H eq_sz.
  by rewrite init_undup unzip1_zip 1:/# -/m ListUtils.mask_zip //#.
  qed.

  (* -------------------------------------------------------------------- *)
  lemma update_fetch ['a 'b] (f0 : 'a -> 'b option) (xs : 'a list)
                             (vs : 'b list) (i : int) :
       size xs = size vs
    => 0 <= i < size vs
    => uniq xs
    => oget (update f0 (zip xs vs) (nth witness xs i)) = nth witness vs i.
  proof.
  move => eq_sz rg_i uniq_xs; rewrite updateE.
  have -> /=: (nth witness xs i) \in unzip1 (zip xs vs).
  - by rewrite unzip1_zip 1:IntOrder.lerr_eq // mem_nth /#.
  rewrite (: assoc (rev (zip xs vs)) (nth witness xs i) = onth vs i).
  rewrite ListUtils.assoc_rev_uniq // (onth_nth witness) 1:#smt:(size_rcons).
  apply mem_assoc_uniq.
  - by rewrite unzip1_zip 1:&(IntOrder.lerr_eq) // !size_rcons.
  - rewrite (nthP (witness, witness)).
    by exists i; split; [ smt(size_zip) | smt(nth_zip) ].
  exact ListUtils.oget_onth.
  qed.
end PosMapUtils.

(* ==================== exponential ==================== *)
(* -------------------------------------------------------------------- *)
axiom e_lt_2sqrt2 :
  e < 2%r * sqrt 2%r.

(* -------------------------------------------------------------------- *)
(* This lemma can be stronger as iff *)
lemma rpow_mono_base_ge1 (x n m : real) :
  1%r <= x => n <= m => x ^ n <= x ^ m.
proof.
move => ??.
case (n < 0%r).
- case (m < 0%r).
  - move => ??.
    rewrite (: n = - - n) // (: m = - - m) //.
    rewrite rpowN 1:/# (rpowN _ (-m)) 1:/#.
    by rewrite RealOrder.ler_pinv 1,2,3,4:#smt:(rpow_gt0) &(rexpr_hmono) /#.
  - move => ??; apply (RealOrder.ler_trans 1%r).
    - rewrite (: n = - - n) // -RField.invr1 -(rpow0 x) rpowN 1:/#.
      by rewrite RealOrder.ler_pinv 1,2,3,4:#smt:(rpow_gt0) &(rexpr_hmono) /#.
    - by rewrite -(rpow0 x) &(rexpr_hmono) /#.
- by move => ?; apply rexpr_hmono => /#.
qed.

(* -------------------------------------------------------------------- *)
lemma rpowN1 (x n : real) :
  0%r <= x => x ^ -n = 1%r / (x ^ n).
proof. by smt(rpowN). qed.

(* -------------------------------------------------------------------- *)
lemma int2rpow (x n : int) :
  0 < x => 0 <= n => (x ^ n)%r = (x%r) ^ (n%r).
proof.
move => ?; elim n.
- by rewrite expr0 rpow0.
- move => i i_ge0 ih.
  rewrite exprSr //.
  rewrite (: (i + 1)%r = i%r + 1%r); 1: by ring.
  by rewrite rpowD 1:/# rpow1 /#.
qed.

(* -------------------------------------------------------------------- *)
lemma exp2n_lt (i j : int) : 0 <= i => 0 <= j => 2^i < 2^j <=> i < j.
proof.
move => ??; rewrite -!lt_fromint !int2rpow //; split.
- apply contraLR => ?.
  have /#: 2%r ^ j%r <= 2%r ^ i%r.
  apply rexpr_hmono => // /#.
- by move => ?; apply rexpr_hmono_ltr => // /#.
qed.

(* -------------------------------------------------------------------- *)
lemma exp2n_inj (i j : int) : 0 <= i => 0 <= j => 2^i = 2^j => i = j.
proof. smt(exp2n_lt). qed.

(* -------------------------------------------------------------------- *)
abbrev ipow2 (i : int) = 2%r^(- (i%r)).

(* -------------------------------------------------------------------- *)
lemma gt0_ipow2 (i : int) : 0%r < ipow2 i.
proof. by rewrite rpowN // RealOrder.invr_gt0 rpow_gt0. qed.

(* -------------------------------------------------------------------- *)
lemma lt1_ipow2 (i : int) : 0 < i => ipow2 i < 1%r.
proof.
move=> ?; have ?: 1%r < 2%r ^ i%r.
- rewrite rpow_nat ~-1://# (_ : 1%r = 2%r^0) 1:RField.expr0 //.
  by rewrite !RField.fromintXn ~-1://# lt_fromint exp2n_lt //#.
by rewrite rpowN // RealOrder.invr_lt1 1:RealOrder.gtr_eqF //#.
qed.

(* -------------------------------------------------------------------- *)
lemma rg_ipow2 (i : int) : 0 < i => 0%r < ipow2 i < 1%r.
proof. by smt(gt0_ipow2 lt1_ipow2). qed.

(* -------------------------------------------------------------------- *)
lemma expB (a b : real):
  RealExp.exp (a - b) = (RealExp.exp a) / (RealExp.exp b).
proof. by rewrite expD expN. qed.

(* -------------------------------------------------------------------- *)
lemma expM (a b : real): RealExp.exp (a * b) = (RealExp.exp a)^b.
proof. by rewrite rpowE 1:exp_gt0 lnK RField.mulrC. qed.

(* -------------------------------------------------------------------- *)
theory FinBool.
  clone include FinType
    with type t <= bool, op enum = [false; true] proof *.

  realize enum_spec.
  proof. by case. qed.

  lemma cardE : card = 2.
  proof. by done. qed.
end FinBool.

(* -------------------------------------------------------------------- *)
theory BoolTuple.
  clone include Tuple
    with type t <- bool, theory Support <- FinBool.

  (* ------------------------------------------------------------------ *)
  op subwordn (n : int) : bool list list =
    flatten (mkseq wordn (n + 1)).

  (* ------------------------------------------------------------------ *)
  lemma neq0_wordn (n : int): wordn n <> [].
  proof.
  rewrite -size_eq0 size_wordn FinBool.cardE.
  by rewrite gtr_eqF // expr_gt0.
  qed.

  (* ------------------------------------------------------------------ *)
  lemma subwordn_lt0 (h : int) :
    h < 0 => BoolTuple.subwordn h = [].
  proof.
  rewrite /BoolTuple.subwordn => ?.
  by rewrite mkseq0_le 1:/# flatten_nil.
  qed.

  (* ------------------------------------------------------------------ *)
  lemma filter_prefix_wordn (n : int) (bs : bool list) : size bs <= n =>
    perm_eq
      (filter (ListUtils.isprefix bs) (wordn n))
      (map (fun bs' => bs ++ bs') (wordn (n - size bs))).
  proof.
  move=> hsz; have ge0_n: 0 <= n by smt(List.size_ge0).
  apply: uniq_perm_eq.
  - by apply/filter_uniq/uniq_wordn.
  - apply/map_inj_in_uniq/uniq_wordn => /=.
    by move=> bs1 bs2 _ _ /catsI.
  move=> bs'; split; last first.
  - case/mapP=> bs'' /= [hsz'' ->>]; rewrite mem_filter; split.
    - by apply/ListUtils.isprefixP; exists bs''.
    - by rewrite wordnP size_cat (in_wordn_size _ _ hsz'') //#.
  rewrite mem_filter => -[] /ListUtils.isprefixP[bs'' <<-].
  move/in_wordn_size; rewrite lez_maxr 1:/# size_cat => ?.
  by apply/mapP; exists bs'' => /=; apply/wordnP => /#.
  qed.

  (* ------------------------------------------------------------------ *)
  lemma uniq_subwordn (n : int) : uniq (subwordn n).
  proof.
  rewrite uniq_flatten.
  - apply/allP=> ns /mkseqP[i] [rgi ->].
    by apply: uniq_wordn.
  - move=> ns ms /mkseqP[i] [rgi ->] /mkseqP[j] [rgj ->]; case/List.hasP.
    move=> rs [] /in_wordn_size + /in_wordn_size.
    by move=> ->; rewrite !lez_maxr //#.
  apply/map_inj_in_uniq/iota_uniq.
  move=> i j /mem_iota [ge0_i _] /mem_iota [ge0_j _].
  move/(congr1 List.size); rewrite !size_wordn.
  by rewrite !lez_maxr // FinBool.cardE &(exp2n_inj).
  qed.

  (* ------------------------------------------------------------------ *)
  lemma mem_subwordn (n : int) (bs : bool list) : 0 <= n =>
    bs \in subwordn n <=> size bs <= n.
  proof.
  move=> ge0_n; split.
  - case/flattenP=> [ns] [] /mkseqP[i] [rgi ->].
    by move/in_wordn_size => -> /#.
  - move=> hsz; apply/flattenP; exists (wordn (size bs)); split.
    - by apply/mkseqP; exists (size bs) => /=; smt(List.size_ge0).
    - by apply/wordnP; smt(List.size_ge0).
  qed.

  (* ------------------------------------------------------------------ *)
  lemma size_subwordn (n : int) : 0 <= n =>
    size (subwordn n) = 2^(n+1) - 1.
  proof.
  move=> ge0_n.
  rewrite size_flatten (_ : map List.size _ = mkseq (fun i => 2^i) (n + 1)).
  - rewrite /mkseq -map_comp &(eq_in_map) => i /mem_iota[/= ??].
    by rewrite /(\o) /= size_wordn lez_maxr //.
  - rewrite sumzE BIA.big_mapT /(\o) /= -/(range 0 (n+1)).
    elim: n ge0_n => /=.
    - by rewrite expr1 /= BIA.big_ltn //= BIA.big_geq // expr0.
    move=> i ge0_i ih; rewrite (BIA.big_int_recr (i+1)) 1:/# ih.
    by rewrite addrAC [2^(i+2)](IntID.exprS _ (i+1)) /#.
  qed.

end BoolTuple.
