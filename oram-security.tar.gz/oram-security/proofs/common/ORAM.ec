require import AllCore List Distr DList FinType FSet FMap SmtMap.

require (*--*) Subtype.

require import IntMin Finite StdOrder.
(*---*) import IntOrder.

require import Aux.
(*---*) import ListUtils FinBool BoolTuple FMapUtils.

require import PROM.

(* -------------------------------------------------------------------- *)
(* Height of the ORAM tree                                              *)
op h : { int | 0 < h } as gt0_h.

(* Bucket size                                                          *)
op K : { int | 0 < K } as gt0_K.

(* -------------------------------------------------------------------- *)
type vars.

clone FinType as FinVars with type t <= vars.

lemma varsfun_isfinite (f : vars -> bool) :
  is_finite f.
proof. by rewrite (finite_leq predT) // &(FinVars.is_finite). qed.

lemma vars_fmap_access ['a] (f : vars -> 'a option) (v : vars) :
  (ofmap (offun f)).[v] = f v.
proof. by rewrite FMap.getE ofmapK 1:&(varsfun_isfinite) offunE /#. qed.

(* We assume that we do not have more than 2^h variables                *)
axiom vars_count_ub : FinVars.card <= 2^h.

(* -------------------------------------------------------------------- *)
type value.

(* -------------------------------------------------------------------- *)
type inst = [
  | Rd of vars
  | Wt of (vars * value)
].

type prog = inst list.

op isRd(i : inst) =
  with i = Rd c => true
  with i = Wt c => false.

op isWt(i : inst) =
  with i = Rd _ => false
  with i = Wt _ => true.

op varV(i : inst) =
  with i = Rd c => c
  with i = Wt cv => cv.`1.

op valV(i : inst) =
  with i = Rd c => None
  with i = Wt cv => Some cv.`2.

lemma isWt_varV (i : inst) (v : vars) (val : value) :
  isWt i => i = Wt (v, val) => varV i = v.
proof. by move => _; move => ->. qed.

lemma isWt_dest (i : inst) : isWt i => exists v val, i = Wt (v, val).
proof. case: i => //= cv; exists cv.`1 cv.`2; smt(). qed.

op well_formed_prog (p : prog) =
  (forall ii cc, (0 <= ii < size p /\ isRd p.[ii] /\ varV p.[ii] = cc)
     => (exists jj, 0 <= jj < ii /\ isWt p.[jj] /\ varV p.[jj] = cc)).

(* -------------------------------------------------------------------- *)
theory Path.
  type prepath = bool list.

  subtype path = { p : prepath | size p = h }
    rename "to_path", "of_path".

  realize inhabited.
  by exists (nseq h false); rewrite size_nseq #smt:(gt0_h).
  qed.

  op "_.[_]" (p : path) (i : int) =
    (of_path p).[i].
end Path.

export Path.

(* -------------------------------------------------------------------- *)
theory FinPath.
  clone include FinType
    with
      type t    <= path,
      op   enum  = map to_pathd (BoolTuple.wordn h)
    proof *.

  realize enum_spec.
  proof.
  move=> p; rewrite count_map /preim -(eq_in_count (pred1 (of_path p))) /=.
  - move=> bs /BoolTuple.wordnP /=; rewrite lez_maxr 1:#smt:(gt0_h) => hsz.
    rewrite /pred1; split; first by move=> ->; rewrite of_pathKd.
    by move=> <-; rewrite to_pathdK.
  - by rewrite BoolTuple.word_spec // of_pathP #smt:(gt0_h).
  qed.

  lemma cardE : card = 2^h.
  proof.
  rewrite /FinPath.enum /card size_map BoolTuple.size_wordn.
  by rewrite FinBool.cardE lez_maxr // #smt:(gt0_h).
  qed.
end FinPath.

import FinPath.

(* -------------------------------------------------------------------- *)
clone import MFinite as UniPath with
  type t <- path, theory Support <- FinPath
  rename "dunifin" as "dunipath".

lemma dunipathE_sub :
  dunipath = dmap (duniform (BoolTuple.wordn h)) to_pathd.
proof.
apply/eq_distr => p; rewrite dunipathE dmap1E duniformE.
rewrite undup_id 1:BoolTuple.uniq_wordn /card /enum size_map.
by do 2! congr; rewrite count_map &(eq_count) => ps /=.
qed.

(* -------------------------------------------------------------------- *)
theory Node.
  type prenode = bool list.

  subtype node = { n : prenode | size n <= h }
    rename "to_node", "of_node".

  realize inhabited. by exists []; smt(gt0_h). qed.

  op size (n : node) : int =
    size (of_node n).

  op child (n : node, b : bool) : node option =
    to_node ((of_node n) ++ [b]).
end Node.

export Node.

(* -------------------------------------------------------------------- *)
clone include FinType
  with
    type t    <= node,
    op   enum  = map to_noded (subwordn h)
  proof *.

realize enum_spec.
proof.
move=> n; rewrite count_map /preim -(eq_in_count (pred1 (of_node n))) /=.
- move=> ps hps; have hsz: size ps <= h by apply/mem_subwordn; smt(gt0_h).
  by rewrite /pred1; split=>[-> | <-]; [rewrite of_nodeKd | rewrite to_nodedK].
by rewrite count_uniq_mem 1:uniq_subwordn mem_subwordn 1:#smt:(gt0_h) of_nodeP.
qed.

(* -------------------------------------------------------------------- *)
theory Depth.
  subtype depth = { i : int | 0 <= i <= h }
    rename "to_depth", "of_depth".

  realize inhabited by exists 0; smt(gt0_h).
end Depth.

export Depth.

(* -------------------------------------------------------------------- *)
(* Returns all the nodes along the path [p], top-down.                  *)
op nodes_of_path (p : path) =
  map (fun i => to_noded (take i (of_path p))) (range 0 (h+1)).

(* Return the node at depth [i] along the path [p]                      *)
op node_at_depth (p : path) (d : depth) : node =
  to_noded (take (of_depth d) (of_path p)).

(* -------------------------------------------------------------------- *)
(* There're two ways of define the longest common prefix:               *)
(* 1. Compute the length of the longest common prefix as the maximum of *)
(*    a length which is a prefix of p1 or p2.                           *)
(*    Then, we can cut the first few elements from p1 or p2.            *)
(* 2. The node n so that n is the prefix of p1 and p2, and              *)
(*    for any c, if c is a prefix of p1 and p2, c is a prefix of n.     *)
(*    We need axiom choice to give such a definition.                   *)
(* For the moment, we give definition 1 and prove 2 as a property.      *)
op cprefix (p1 : path) (p2 : path) : node =
  let plen =
    maxz (fun i => i <= size (of_path p1)
                /\ i <= size (of_path p2)
                /\ take i (of_path p1) = take i (of_path p2))
  in to_noded (take plen (of_path p1)).

(* -------------------------------------------------------------------- *)
op depth_of_node (n : node) : depth =
  to_depthd (size n).

(* -------------------------------------------------------------------- *)
op isleaf (n : node) : bool =
  size (of_node n) = h.

(* -------------------------------------------------------------------- *)
op node_of_path (p : path) : node =
  to_noded (of_path p).

(* -------------------------------------------------------------------- *)
op isprefix (p1 p2 : node) : bool =
  isprefix (of_node p1) (of_node p2).

(* -------------------------------------------------------------------- *)
(* Check whether a node is on a path                                    *)
op node_is_on_path (n : node) (p : path) : bool =
  isprefix (of_node n) (of_path p).

(* ==================================================================== *)
(* Lemmas about common tree operations                                  *)

(* -------------------------------------------------------------------- *)
lemma of_node_at_depth (p : path) (d : depth) :
  of_node (node_at_depth p d) = take (of_depth d) (of_path p).
proof.
rewrite /node_at_depth to_nodedK // size_take_condle.
- by smt(of_depthP).
- by rewrite ifT #smt:(of_depthP of_pathP).
qed.

(* -------------------------------------------------------------------- *)
lemma isprefix_node_path (p : path) (d : depth) :
  isprefix (of_node (node_at_depth p d)) (of_path p).
proof.
rewrite /isprefix of_node_at_depth.
by rewrite size_takel 1:#smt:(of_depthP of_pathP).
qed.

(* -------------------------------------------------------------------- *)
lemma size_node_at_depth (p : path) (d : depth) :
  size (node_at_depth p d) = of_depth d.
proof.
rewrite /size /node_at_depth of_node_at_depth.
by rewrite size_takel 1:#smt:(of_depthP of_pathP).
qed.

(* -------------------------------------------------------------------- *)
lemma depth_of_node_at_depth (p : path) (d : depth) :
  depth_of_node (node_at_depth p d) = d.
proof.
rewrite /depth_of_node /node_at_depth /Node.size to_nodedK.
+ by rewrite size_take #smt:(of_depthP of_pathP).
by rewrite size_take #smt:(of_depthP of_depthK of_pathP).
qed.

(* -------------------------------------------------------------------- *)
lemma rng_size_cprefix (p1 p2 : path) :
  0 <= size (cprefix p1 p2) <= h.
proof.
split => [| ? @/cprefix /=].
+ exact List.size_ge0.
+ by rewrite /Node.size to_nodedK size_take 1,3:&(ge0_argmax) #smt:(of_pathP).
qed.

(* -------------------------------------------------------------------- *)
lemma size_depth_path (d: depth) (p : path) :
  size (to_noded (take (of_depth d) (of_path p))) = of_depth d.
proof.
rewrite /Node.size to_nodedK.
+ by rewrite size_take 1:#smt:(of_depthP) #smt:(of_pathP).
rewrite size_take 1:#smt:(of_depthP).
case (of_depth d < List.size (of_path p)).
+ done.
+ by smt(of_depthP of_pathP).
qed.

(* -------------------------------------------------------------------- *)
lemma common_prefix (n : node) (p1 p2 : path) :
     isprefix (of_node n) (of_path p1)
  /\ isprefix (of_node n) (of_path p2)
  <=> isprefix n (cprefix p1 p2).
proof.
rewrite /cprefix /=.

pose P (i : int) := i <= size (of_path p1)
                 /\ i <= size (of_path p2)
                 /\ take i (of_path p1) = take i (of_path p2).

(* P is non-increasing *)
have ? : forall i j, i <= j => P j => P i.
+ move => i j ? @/P [#] ?? Hj; do split.
  + by smt().
  + by smt().
  + apply (eq_trans _ (take i (take j (of_path p1)))).
    + by rewrite take_take /#.
    by rewrite Hj take_take /#.

(* the maximum point satisfies P *)
have ? : P (maxz P).
+ apply (argmaxP idfun P 0 (h + 1)) => //.
  + by smt(gt0_h).
  + by rewrite /P /idfun /= !List.size_ge0 !take0.
  + by smt(of_pathP).

(* range of maxz P *)
have ? : 0 <= (maxz P)
           <= min (size (of_path p1)) (size (of_path p2))
           <= h.
+ do (split => *).
  + exact ge0_argmax.
  + case ((size (of_path p1) <= size (of_path p2))) => Hcase.
    + by rewrite minrE Hcase /= -le_argmax 1:&(List.size_ge0) /#.
    + by rewrite minrE Hcase /= -le_argmax 1:&(List.size_ge0) /#.
  + by smt(of_pathP).

split.
+ (* the core is to prove that: n <= p1 /\ n <= p2 => P (size n) *)
  move => [#] ^Hp1 /isprefix_size ? ^Hp2 /isprefix_size ? @/isprefix.
  rewrite to_nodedK 1:#smt:(size_take) take_take.
  rewrite (: size (of_node n) <= _) /=.
  + case (size (of_node n) = 0) => [ -> | ? ].
    + exact ge0_argmax.
    + rewrite -ge_argmax 1:#smt:(List.size_ge0); split.
      + exists (h + 1); split => /=.
        + by smt(gt0_h).
        + by smt(of_pathP).
      + by exists (size (of_node n)) => /#.
  by smt().
+ (* the core is to prove P (size n), which is proved by a contradiction *)
  rewrite /isprefix to_nodedK 1:#smt:(size_take) take_take.
  case _ : (Node.size _ <= maxz _) => ^Hcase -> /=.
  + by move => H; split => [ // | /# ].
  + move /(congr1 List.size).
    rewrite size_take 1:/#.
    by rewrite (: maxz P < List.size _) 1:#smt:(of_pathP of_nodeP) /#.
qed.

(* -------------------------------------------------------------------- *)
lemma isprefix_size (s1 s2 : node) :
  isprefix s1 s2 => size s1 <= size s2.
proof. by smt(isprefix_size). qed.

(* -------------------------------------------------------------------- *)
lemma cprefix_take_eq (p1 p2 : path) (i : int) :
  0 <= i <= size (cprefix p1 p2) =>
  take i (of_path p1) = take i (of_path p2).
proof.
move => Hi.
pose P := fun j => j <= size (of_path p1) /\ j <= size (of_path p2)
               /\ take j (of_path p1) = take j (of_path p2).
have Hsz : size (cprefix p1 p2) = maxz P.
+ rewrite /cprefix /P /Node.size /=.
  rewrite to_nodedK.
  - smt(size_take ge0_argmax of_pathP size_ge0).
  smt(size_take ge0_argmax of_pathP size_ge0 le_argmax).
have HP : P (maxz P).
+ apply (argmaxP idfun P 0 (h + 1)) => //.
  + by smt(gt0_h).
  + by rewrite /P /idfun /= !List.size_ge0 !take0.
  + by smt(of_pathP).
have [_ [_ Htake]] := HP.
have H1 : take i (of_path p1) = take i (take (maxz P) (of_path p1)) by smt(take_take).
have H2 : take i (of_path p2) = take i (take (maxz P) (of_path p2)) by smt(take_take).
by rewrite H1 Htake -H2.
qed.

(* -------------------------------------------------------------------- *)
(* If the cprefix has size >= i, then node_at_depth p1 i is on p2 *)
lemma node_is_on_path_cprefix (p1 p2 : path) (i : int) :
  0 <= i <= size (cprefix p1 p2) =>
  node_is_on_path (node_at_depth p1 (to_depthd i)) p2.
proof.
move => Hi; rewrite /node_is_on_path of_node_at_depth.
have Hsz_i : of_depth (to_depthd i) = i by smt(to_depthdK rng_size_cprefix).
rewrite Hsz_i (cprefix_take_eq p1 p2 i Hi).
rewrite -/(ListUtils.isprefix _ _).
by apply isprefix_take; rewrite size_take; smt(of_pathP).
qed.

(* ==================================================================== *)
(* Tree-oriented API: blocks                                             *)

(* Each node stores a set of blocks = path * value (without depth)       *)
type block = { bpath: path; bvalue: value }.

(* -------------------------------------------------------------------- *)
type opkind = [Read | Write].

(* -------------------------------------------------------------------- *)
type leakage = (opkind * node) list.

(* ==================================================================== *)
(* Last index: the rightmost j < i such that varV p.[j] = varV p.[i]    *)
op last_index (p : prog) (i : int) =
  rfind
    (fun j => varV p.[j] = varV p.[i])
    (range 0 i).

(* -------------------------------------------------------------------- *)
lemma last_index_rng (p : prog) (i : int) :
  0 <= i => -1 <= last_index p i < i.
proof.
move=> rgi; have := rfind_rng (fun j => varV p.[j] = varV p.[i]) (range 0 i).
by rewrite size_range /= lez_maxr.
qed.

(* ==================================================================== *)
(* Pre-sampled random tape                                               *)

abstract theory TapeSampler.

type out_t.
op dout : out_t distr.

clone include FullRO with
  type in_t <- int,
  type out_t <- out_t,
  op dout <- fun _ => dout.

module TapeSampler (RO : RO) = {
  var counter : int

  proc init(n : int) = {
    var i : int;
    RO.init();
    counter <- 0;
    i <- 0;
    while (i < n) {
      RO.sample(i);
      i <- i + 1;
    }
  }

  proc sample() : out_t = {
    var r : out_t;
    r <@ RO.get(counter);
    counter <- counter + 1;
    return r;
  }
}.

end TapeSampler.

clone include TapeSampler with
  type out_t <- path,
  op dout <- dunipath,
  type d_in_t <- prog,
  type d_out_t <- unit.

(* ==================================================================== *)
(* Clone Program for path sampling                                       *)
clone Program as PathSampler with
  type t <- path,
  op d <- dunipath.

(* ==================================================================== *)
type sleakage = path.
