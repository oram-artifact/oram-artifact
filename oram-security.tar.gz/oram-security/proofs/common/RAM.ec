require import AllCore List FMap.

require import ORAM.
(*---*) import UniPath.

require import Aux.
(*---*) import ListUtils.

module RAM = {
  var mem : (vars, value) fmap

  proc step(i : inst) = {
    var val : value;

    match i with
    | Rd v => { val <- oget (mem.[v]); }
    | Wt t => { mem <- mem.[t.`1 <- t.`2]; val <- t.`2; }
    end;

    return val;
  }

  proc compile(prog : prog) = {
    var i : int;
    var result : value;
    var results : value list;
    i <- 0;
    results <- [];
    mem <- FMap.empty;
    while (i < size prog) {
      result <@ step(prog.[i]);
      results <- result :: results;
      i <- i + 1;
    }
    return results;
  }
}.

(* -------------------------------------------------------------------- *)
(* Module types for correctness TV-distance statement                    *)

module type Compile_t = {
  proc compile(p : prog) : value list
}.

module type CDist_t = {
  proc dist(vs : value list) : bool
}.

module CORRECT_IND(O : Compile_t, D : CDist_t) = {
  proc main(p : prog) : bool = {
    var vs, b;
    vs <@ O.compile(p);
    b  <@ D.dist(vs);
    return b;
  }
}.
