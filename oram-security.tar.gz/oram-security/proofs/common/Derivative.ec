(* -------------------------------------------------------------------- *)
require import AllCore StdRing StdOrder RealExp RealSeq.

import RField RealOrder.

(* -------------------------------------------------------------------- *)
op cvgto (f : real -> real) (x0 : real) (l : real) =
  forall e, 0%r < e => exists a, 0%r < a /\
    forall x, 0%r < `|x - x0| < a => `|f x - l| < e.

op cvg (f : real -> real) (x0 : real) =
  exists l, cvgto f x0 l.

op lim (f : real -> real) (x0 : real) =
  choiceb (fun l => cvgto f x0 l) 0%r.

op continuous (f : real -> real) (x0 : real) =
  cvgto f x0 (f x0).

op slope (f : real -> real) (x0 : real) =
  fun h => (f (x0 + h) - f x0) / h.

op derivative (f : real -> real) (x0 : real) =
  lim (slope f x0) 0%r.

op hasdrvt (f : real -> real) (x0 : real) =
  cvg (slope f x0) 0%r.

(* -------------------------------------------------------------------- *)
lemma uniq_cvgto (f : real -> real) (x0 : real) (l1 l2 : real) :
  cvgto f x0 l1 => cvgto f x0 l2 => l1 = l2.
proof.
move=> cvg1 cvg2; apply: contraT => ne_l1l2; pose e := `|l2 - l1| / 2%r.
have ^/cvg1 [a1 [? +]] /cvg2 [a2 [?]]: 0%r < e by smt().
pose a := minr a1 a2; pose x1 := x0 + a / 2%r.
by move=> /(_ x1 _) => [/#|?] => /(_ x1 _) => [/#|?] /#.
qed.

(* -------------------------------------------------------------------- *)
lemma eq_cvgto (f2 f1 : real -> real) (x0 : real) (l : real) :
     (exists e, 0%r < e /\ forall x, x <> x0 => `|x - x0| < e => f1 x = f2 x)
  => cvgto f1 x0 l
  => cvgto f2 x0 l.
proof.
case=> e [gt0_e heq] hcvg e' gt0_e'.
have [a [gt0_a h]] := hcvg e' _; first by smt().
by exists (minr a e); split=> [/#|x rgx]; rewrite -heq //#.
qed.

(* -------------------------------------------------------------------- *)
lemma cvgto_lim (f : real -> real) (x0 : real) (l : real) :
  cvgto f x0 l => lim f x0 = l.
proof.
by move=> hcvg; apply: (choicebW _ _ (pred1 l)) => /=; smt(uniq_cvgto).
qed.

(* -------------------------------------------------------------------- *)
lemma Ncvg_lim (f : real -> real) (x0 : real) :
  !cvg f x0 => lim f x0 = 0%r.
proof. by move=> h @/lim; rewrite choiceb_dfl //#. qed.

(* -------------------------------------------------------------------- *)
lemma eq_lim_r (f2 f1 : real -> real) (x0 : real) :
     (exists e, 0%r < e /\ forall x, x <> x0 => `|x - x0| < e => f1 x = f2 x)
  => lim f1 x0 = lim f2 x0.
proof.
move=> h; case: (cvg f1 x0).
- case=> l; move=> ^h1 /(eq_cvgto _ _ _ _ h) => h2.
  by rewrite (cvgto_lim _ _ _ h1) (cvgto_lim _ _ _ h2).
- move=> h1; suff h2: !cvg f2 x0 by rewrite !Ncvg_lim.
  by apply: contra h1 => -[l hl]; exists l; apply: eq_cvgto hl => /#.
qed.

(* -------------------------------------------------------------------- *)
lemma eq_lim (f2 f1 : real -> real) (x0 : real) :
     (forall x, x <> x0 => f1 x = f2 x)
  => lim f1 x0 = lim f2 x0.
proof. by move=> x; apply: eq_lim_r; exists 1%r; split=> //#. qed.

(* -------------------------------------------------------------------- *)
lemma cvgtoC (c : real) (x0 : real) : cvgto (fun _ => c) x0 c.
proof. by move=> e gt0_e; exists 1%r => /= x _; rewrite ger0_norm. qed.

(* -------------------------------------------------------------------- *)
lemma cvgC (c : real) (x0 : real) : cvg (fun _ => c) x0.
proof. by exists c; apply: cvgtoC. qed.

(* -------------------------------------------------------------------- *)
lemma limC (c : real) (x0 : real) : lim (fun _ => c) x0 = c.
proof. by apply/cvgto_lim/cvgtoC. qed.

(* -------------------------------------------------------------------- *)
lemma cvgtoN (f: real -> real) (x0 : real) (l : real) :
  cvgto f x0 l => cvgto (fun x => -f x) x0 (-l).
proof.
move=> hcvg e /hcvg[a [? h]]; exists a; split=> //.
by move=> x; rewrite -opprD normrN &(h).
qed.

(* -------------------------------------------------------------------- *)
lemma cvgN (f : real -> real) (x0 : real) :
  cvg f x0 => cvg (fun x => -f x) x0.
proof. by case=> [l h]; exists (-l); apply: cvgtoN. qed.

(* -------------------------------------------------------------------- *)
lemma limN (f : real -> real) (x0 : real) :
  cvg f x0 => lim (fun x => -f x) x0 = -lim f x0.
proof.
by case=> [l h]; have := cvgtoN _ _ _ h; smt(cvgto_lim).
qed.

(* -------------------------------------------------------------------- *)
lemma cvgtoD (f1 f2 : real -> real) (x0 : real) (l1 l2 : real) :
  cvgto f1 x0 l1 => cvgto f2 x0 l2 => cvgto (fun x => f1 x + f2 x) x0 (l1 + l2).
proof.
move=> cvg1 cvg2 e gt0_e; have: 0%r < e / 2%r by smt().
move=> ^/cvg1[a1 [? h1]] /cvg2[a2 [? h2]]; exists (minr a1 a2).
split=> [/#|x ltx]; rewrite opprD addrACA.
by apply: (ler_lt_trans _ _ _ (ler_norm_add _ _)) => /#.
qed.

(* -------------------------------------------------------------------- *)
lemma cvgD (f1 f2 : real -> real) (x0 : real) :
  cvg f1 x0 => cvg f2 x0 => cvg (fun x => f1 x + f2 x) x0.
proof. by case=> [l1 h1] [l2 h2]; exists (l1 + l2); apply: cvgtoD. qed.

(* -------------------------------------------------------------------- *)
lemma limD (f1 f2 : real -> real) (x0 : real) :
     cvg f1 x0
  => cvg f2 x0
  => lim (fun x => f1 x + f2 x) x0 = lim f1 x0 + lim f2 x0.
proof.
by case=> [l1 h1] [l2 h2]; have := cvgtoD _ _ _ _ _ h1 h2; smt(cvgto_lim).
qed.

(* -------------------------------------------------------------------- *)
lemma cvgtoZ (f : real -> real) (c : real) (x0 : real) (l : real) :
  cvgto f x0 l => cvgto (fun x => c * f x) x0 (c * l).
proof.
case: (c = 0%r) => [->>|nz_c].
+ by move=> _ /=; apply: cvgtoC.
move=> hcvg e gt0_e; have: 0%r < e / `|c| by smt().
move=> /hcvg[a [? h]]; exists a; split=> // x ?.
by rewrite -mulrBr normrM /#.
qed.

(* -------------------------------------------------------------------- *)
lemma cvgZ (f : real -> real) (c : real) (x0 : real) :
  cvg f x0 => cvg (fun x => c * f x) x0.
proof. by case=> l h; exists (c * l); apply/cvgtoZ. qed.

(* -------------------------------------------------------------------- *)
lemma limZ (f : real -> real) (c : real) (x0 : real) :
  cvg f x0 => lim (fun x => c * f x) x0 = c * lim f x0.
proof.
by case=> [l h]; have := cvgtoZ _ c _ _ h; smt(cvgto_lim).
qed.

(* -------------------------------------------------------------------- *)
lemma cvgtoM (f1 f2 : real -> real) (x0 : real) (l1 l2 : real) :
  cvgto f1 x0 l1 => cvgto f2 x0 l2 => cvgto (fun x => f1 x * f2 x) x0 (l1 * l2).
proof.
move=> cvg1 cvg2 e gt0_e;
  pose e1 := e / (2%r * (1%r + `|l1|));
  pose e2 := e / (2%r * (1%r + `|l2|)).
have /cvg1[a1 [gt0_a1 h1]]: 0%r < e2 by smt().
have /cvg2[a2 [gt0_a2 h2]]: 0%r < e1 by smt().
have [a0 [gt0_a0 h0]] := cvg2 1%r ltr01.
pose a := minr a0 (minr a1 a2); exists a; split=> [/#|x rgx].
pose z := `|f1 x - l1| * `|f2 x| + `|l1| * `|f2 x - l2|.
apply: (ler_lt_trans z) => @/z => {z}; last by smt().
rewrite -!normrM &(ler_trans _ _ _ _ (ler_norm_add _ _)).
by apply: lerr_eq; congr; ring.
qed.

(* -------------------------------------------------------------------- *)
lemma cvgtoV (f : real -> real) (x0 : real) (l : real) :
  l <> 0%r => cvgto f x0 l => cvgto (fun x => inv (f x)) x0 (inv l).
proof.
move=> nz_l hcvg e gt0_e.
pose e' := minr (`|l| / 2%r) (e * l * l / 2%r).
have gt0_e': 0%r < e' by smt().
have [a [gt0_a h]] := hcvg e' gt0_e'.
exists a; split=> // x rgx.
have hfx := h x rgx.
have bound_fl: `|f x - l| < `|l| / 2%r by smt().
have nz_fx: f x <> 0%r by smt().
have bound_fx: `|l| / 2%r <= `|f x| by smt().
have eq_inv: inv (f x) - inv l = (l - f x) / (f x * l) by field; smt().
rewrite eq_inv.
have nz_prod: f x * l <> 0%r by smt().
rewrite normrM normrV //.
have step1: `|l - f x| / `|f x * l| < e' / (`|l| / 2%r * `|l|) by smt().
by apply: (ltr_le_trans _ _ _ step1) => /#.
qed.

(* -------------------------------------------------------------------- *)
lemma cvgV (f : real -> real) (x0 : real) (l : real) :
  l <> 0%r => cvgto f x0 l => cvg (fun x => inv (f x)) x0.
proof. by move=> nz_l hcvg; exists (inv l); apply: cvgtoV. qed.

(* -------------------------------------------------------------------- *)
lemma cvgM (f1 f2 : real -> real) (x0 : real) :
  cvg f1 x0 => cvg f2 x0 => cvg (fun x => f1 x * f2 x) x0.
proof. by case=> [l1 h1] [l2 h2]; exists (l1 * l2); apply: cvgtoM. qed.

(* -------------------------------------------------------------------- *)
lemma limM (f1 f2 : real -> real) (x0 : real) :
     cvg f1 x0
  => cvg f2 x0
  => lim (fun x => f1 x * f2 x) x0 = lim f1 x0 * lim f2 x0.
proof.
by case=> [l1 h1] [l2 h2]; have := cvgtoM _ _ _ _ _ h1 h2; smt(cvgto_lim).
qed.

(* -------------------------------------------------------------------- *)
(* Helper lemmas for explicit arithmetic reasoning *)
(* These are standard facts that could be proved with smt but we avoid it *)

lemma norm_triangle_sub (a b c : real) :
  `|a - b| <= `|a - c| + `|c - b|.
proof.
have ->: a - b = (a - c) + (c - b) by ring.
by apply/ler_norm_add.
qed.

lemma norm_mul_bound (a b M : real) :
  `|a| <= M => `|a * b| <= M * `|b|.
proof. by move=> ?; rewrite normrM; apply/ler_wpmul2r => //; apply/normr_ge0. qed.

lemma norm_bound_add (a l e : real) :
  `|a - l| < e => `|a| <= `|l| + e.
proof. by smt(). qed.

lemma mul_bound_compose (x s M e : real) :
  0%r < M => `|x| < e / M => `|s| <= M => `|x * s| < e.
proof. by smt(). qed.

(* -------------------------------------------------------------------- *)
lemma hasdrvt_continuous (f : real -> real) (x0 : real) :
  hasdrvt f x0 => continuous f x0.
proof.
move=> @/hasdrvt @/continuous [l hcvg] e gt0_e.
(* Get δ1 such that |slope h - l| < 1 when |h| < δ1 *)
have gt0_1: 0%r < 1%r by done.
have [a1 [gt0_a1 h1]] := hcvg 1%r gt0_1.
(* Define M = |l| + 1, so |slope h| <= M when |h| < a1 *)
pose M := `|l| + 1%r.
have gt0_M: 0%r < M.
+ rewrite /M; have: 0%r <= `|l| by apply/normr_ge0.
  smt().
(* Choose δ = min(a1, e/M) *)
pose a := minr a1 (e / M).
have gt0_a: 0%r < a.
+ rewrite /a; have ge0_div: 0%r < e / M by apply/divr_gt0.
  smt().
exists a; split => // x.
have ->: `|(x - x0) - 0%r| = `|x - x0| by rewrite subr0.
move=> rg_x.
(* Case split: x = x0 or x <> x0 *)
case: (x = x0) => [->|ne_x].
+ by rewrite subrr normr0.
(* f(x) - f(x0) = (x - x0) * slope f x0 (x - x0) *)
have ->: f x - f x0 = (x - x0) * slope f x0 (x - x0).
+ rewrite /slope; have ->: x0 + (x - x0) = x by ring.
  by field; smt().
(* Now bound |(x - x0) * slope f x0 (x - x0)| *)
have h_a1: `|x - x0| < a1.
+ apply/(ltr_le_trans a) => //; rewrite /a; smt().
have bound_slope: `|slope f x0 (x - x0) - l| < 1%r by smt().
have bound_s: `|slope f x0 (x - x0)| <= M.
+ by apply/norm_bound_add/bound_slope.
have bound_x: `|x - x0| < e / M.
+ apply/(ltr_le_trans a) => //; rewrite /a; smt().
by apply/(mul_bound_compose (x - x0) (slope f x0 (x - x0)) M e).
qed.

(* -------------------------------------------------------------------- *)
lemma eq_derivative_r (f2 f1 : real -> real) (x0 : real) :
    (exists e, 0%r < e /\
       forall x, x <> 0%r => `|x| < e => slope f1 x0 x = slope f2 x0 x)
  => derivative f1 x0 = derivative f2 x0.
proof. by move=> h @/derivative; apply/eq_lim_r/h. qed.

(* -------------------------------------------------------------------- *)
lemma eq_derivative (f2 f1 : real -> real) (x0 : real) :
     (forall x, x <> 0%r => slope f1 x0 x = slope f2 x0 x)
  => derivative f1 x0 = derivative f2 x0.
proof. by move=> h; apply/eq_derivative_r; exists 1%r; split=> //#. qed.

(* -------------------------------------------------------------------- *)
lemma derivativeC (c : real) (x0 : real) :
  derivative (fun _ => c) x0 = 0%r.
proof. by rewrite /derivative /slope /= limC. qed.

(* -------------------------------------------------------------------- *)
lemma hasdrvtC (c : real) (x0 : real) :
  hasdrvt (fun _ => c) x0.
proof. by rewrite /hasdrvt /slope /=; apply/cvgC. qed.

(* -------------------------------------------------------------------- *)
lemma derivative_idfun (x0 : real) :
  derivative idfun x0 = 1%r.
proof.
rewrite /derivative (eq_lim (fun _ => 1%r)) -1:limC //.
by move=> x nz_x @/slope @/idfun /=; field.
qed.

(* -------------------------------------------------------------------- *)
lemma hasdrvt_idfun (x0 : real) :
  hasdrvt idfun x0.
proof.
rewrite /hasdrvt /cvg; exists 1%r => @/cvgto e gt0_e.
exists 1%r; split=> // x /= rgx @/slope @/idfun /=.
by have ->: (x0 + x - x0) / x = 1%r by smt(); rewrite ger0_norm //= /#.
qed.

(* -------------------------------------------------------------------- *)
lemma slopeD (f1 f2 : real -> real) (x0 : real) :
  slope (fun x => f1 x + f2 x) x0 = (fun x => slope f1 x0 x + slope f2 x0 x).
proof. by apply/fun_ext=> x @/slope /=; rewrite -mulrDl; congr; ring. qed.

(* -------------------------------------------------------------------- *)
lemma hasdrvtD (f1 f2 : real -> real) (x0 : real) :
  hasdrvt f1 x0 => hasdrvt f2 x0 => hasdrvt (fun x => f1 x + f2 x) x0.
proof. by move=> @/hasdrvt h1 h2; rewrite slopeD &(cvgD). qed.

(* -------------------------------------------------------------------- *)
lemma derivativeD (f1 f2 : real -> real) (x0 : real) :
     hasdrvt f1 x0
  => hasdrvt f2 x0
  =>   derivative (fun x => f1 x + f2 x) x0
     = derivative f1 x0 + derivative f2 x0.
proof. by move=> h1 h2 @/derivative; rewrite slopeD limD. qed.

(* -------------------------------------------------------------------- *)
lemma slopeZ (f : real -> real) (c : real) (x0 : real) :
  slope (fun x => c * f x) x0 = (fun x => c * slope f x0 x).
proof. by apply/fun_ext=> x @/slope /=; congr; ring. qed.

(* -------------------------------------------------------------------- *)
lemma hasdrvtZ (f : real -> real) (c : real) (x0 : real) :
  hasdrvt f x0 => hasdrvt (fun x => c * f x) x0.
proof. by move=> @/hasdrvt h; rewrite slopeZ &(cvgZ). qed.

(* -------------------------------------------------------------------- *)
lemma derivativeZ (f : real -> real) (c : real) (x0 : real) :
  hasdrvt f x0 => derivative (fun x => c * f x) x0 = c * derivative f x0.
proof. by move=> h @/derivative; rewrite slopeZ limZ. qed.

(* -------------------------------------------------------------------- *)
lemma slopeM (f1 f2 : real -> real) (x0 : real) :
    slope (fun x => f1 x * f2 x) x0
  = (fun h => slope f1 x0 h * f2 (x0 + h) + f1 x0 * slope f2 x0 h).
proof.
apply/fun_ext=> h @/slope.
by rewrite !mulrA [_ / h * _]mulrAC -mulrDl #ring.
qed.

(* -------------------------------------------------------------------- *)
lemma hasdrvtM (f1 f2 : real -> real) (x0 : real) :
  hasdrvt f1 x0 => hasdrvt f2 x0 => hasdrvt (fun x => f1 x * f2 x) x0.
proof.
move=> h1 h2; have h: cvgto (fun x => f2 (x0 + x)) 0%r (f2 x0).
- by apply/hasdrvt_continuous.
rewrite /hasdrvt slopeM; apply/cvgD.
- by apply/cvgM => //#.
- by apply/cvgZ/h2.
qed.

(* -------------------------------------------------------------------- *)
lemma derivativeM (f1 f2 : real -> real) (x0 : real) :
     hasdrvt f1 x0
  => hasdrvt f2 x0
  =>   derivative (fun x => f1 x * f2 x) x0
     = derivative f1 x0 * f2 x0 + f1 x0 * derivative f2 x0.
proof.
move=> h1 h2; have h: cvgto (fun x => f2 (x0 + x)) 0%r (f2 x0).
- by apply/hasdrvt_continuous.
move=> @/derivative; rewrite slopeM limD.
- by apply/cvgM => //#.
- by apply/cvgZ/h2.
- have hcvg_f2: cvg (fun x => f2 (x0 + x)) 0%r by exists (f2 x0).
    have ->: lim (fun h => slope f1 x0 h * f2 (x0 + h)) 0%r
           = lim (slope f1 x0) 0%r * lim (fun x => f2 (x0 + x)) 0%r.
    + by apply/limM.
    have ->: lim (fun h => f1 x0 * slope f2 x0 h) 0%r
           = f1 x0 * lim (slope f2 x0) 0%r.
    + by apply/limZ.
    by rewrite /= (cvgto_lim _ _ _ h).
qed.

(* -------------------------------------------------------------------- *)
lemma eq_hasdrvt (f1 f2 : real -> real) (x0 : real) :
  (forall x, f1 x = f2 x) => hasdrvt f1 x0 => hasdrvt f2 x0.
proof.
move=> heq @/hasdrvt [l hcvg].
exists l; apply: (eq_cvgto _ (slope f1 x0)).
- by exists 1%r; split=> // x _ _; rewrite /slope !heq.
by apply hcvg.
qed.

(* -------------------------------------------------------------------- *)
lemma slopeInv (f : real -> real) (x0 : real) (h : real) :
  h <> 0%r => f x0 <> 0%r => f (x0 + h) <> 0%r =>
    slope (fun x => inv (f x)) x0 h
  = - slope f x0 h * inv (f (x0 + h)) * inv (f x0).
proof.
move=> nz_h nz_f0 nz_fh @/slope /=.
have step: inv (f (x0 + h)) - inv (f x0) = (f x0 - f (x0 + h)) / (f (x0 + h) * f x0).
- by field; smt().
rewrite step /=.
by field; smt().
qed.

(* -------------------------------------------------------------------- *)
lemma hasdrvtInv (f : real -> real) (x0 : real) :
  hasdrvt f x0 => f x0 <> 0%r => hasdrvt (fun x => inv (f x)) x0.
proof.
move=> hf nz_f0.
(* f is continuous at x0 since it has a derivative *)
have cont_f := hasdrvt_continuous _ _ hf.
(* f(x0+h) -> f(x0) as h -> 0 : translate continuity cvgto f x0 (f x0) *)
have hfx: cvgto (fun h => f (x0 + h)) 0%r (f x0).
- move=> e gt0_e.
  have [a [gt0_a hcont]] := cont_f e gt0_e.
  exists a; split=> // h rgh.
  have hne: x0 + h <> x0 by smt().
  have hdist: 0%r < `|(x0 + h) - x0| < a by smt().
  by apply: hcont.
(* inv(f(x0+h)) -> inv(f(x0)) as h -> 0 *)
have hinv: cvgto (fun h => inv (f (x0 + h))) 0%r (inv (f x0)) 
  by apply: cvgtoV.
(* Now the slope of inv(f) equals -slope(f) / (f(x0+h) * f(x0)) *)
rewrite /hasdrvt.
case: hf => l hcvg_slope.
(* slope of inv(f) converges to -l / (f x0)^2 *)
pose L := -l * inv (f x0) * inv (f x0).
exists L.
(* Use eq_cvgto to relate slope of inv(f) to expression involving slope f *)
have hcvg_prod: cvgto (fun h => slope f x0 h * inv (f (x0 + h)) * inv (f x0)) 0%r 
                      (l * inv (f x0) * inv (f x0)).
- apply: cvgtoM; first by apply: cvgtoM => //#.
  by apply: cvgtoC.
(* slope(inv f, x0, h) = -slope(f, x0, h) * inv(f(x0+h)) * inv(f(x0)) for h in neighborhood *)
have heq: exists e, 0%r < e /\ forall h, h <> 0%r => `|h| < e => 
            slope (fun x => inv (f x)) x0 h = - slope f x0 h * inv (f (x0 + h)) * inv (f x0).
- have [a' [gt0_a' hf_nz]]: exists a', 0%r < a' /\ forall (h : real), `|h| < a' => f (x0 + h) <> 0%r.
  + have gt0_half: 0%r < `|f x0| / 2%r by smt().
    have [a'' [gt0_a'' hbnd]] := hfx _ gt0_half.
    exists a''; split=> // h hh.
    case: (h = 0%r) => [->|nz_h].
    * have ->: f (x0 + 0%r) = f x0 by ring. smt().
    have hh': 0%r < `|h - 0%r| < a'' by smt().
    have := hbnd h hh'. smt().
  exists a'; split=> // h nz_h hh.
  by apply: slopeInv => //#.
(* Now use eq_cvgto to transport convergence *)
apply: (eq_cvgto _ (fun h => - slope f x0 h * inv (f (x0 + h)) * inv (f x0))).
- case: heq => e [gt0_e he].
  exists e; split=> // h nz_h hh.
  by rewrite he.
(* -slope f * inv(f(x0+h)) * inv(f x0) -> -l * inv(f x0) * inv(f x0) = L *)
rewrite /L.
apply: cvgtoN.
apply: cvgtoM; last by apply: cvgtoC.
apply: cvgtoM => //#.
qed.

(* -------------------------------------------------------------------- *)
lemma derivativeInv (f : real -> real) (x0 : real) :
     hasdrvt f x0
  => f x0 <> 0%r
  => derivative (fun x => inv (f x)) x0 = - derivative f x0 / (f x0 * f x0).
proof.
move=> hf nz_f0.
(* We use hasdrvtInv and show that the slope converges to the expected value *)
have hinv := hasdrvtInv _ _ hf nz_f0.
(* Establish continuity *)
have cont_f := hasdrvt_continuous _ _ hf.
have hfx: cvgto (fun h => f (x0 + h)) 0%r (f x0).
+ move=> e gt0_e.
  have [a [gt0_a hcont]] := cont_f e gt0_e.
  exists a; split=> // h rgh.
  have hne: x0 + h <> x0 by smt().
  have hdist: 0%r < `|(x0 + h) - x0| < a by smt().
  by apply: hcont.
have hinv_cvg: cvgto (fun h => inv (f (x0 + h))) 0%r (inv (f x0)) 
  by apply: cvgtoV.
(* Neighborhood where slope identity holds *)
have heq: exists e, 0%r < e /\ forall h, h <> 0%r => `|h| < e => 
            slope (fun x => inv (f x)) x0 h = - slope f x0 h * inv (f (x0 + h)) * inv (f x0).
+ have [a' [gt0_a' hf_nz]]: exists a', 0%r < a' /\ forall (h : real), `|h| < a' => f (x0 + h) <> 0%r.
  * have gt0_half: 0%r < `|f x0| / 2%r by smt().
    have [a'' [gt0_a'' hbnd]] := hfx _ gt0_half.
    exists a''; split=> // h hh.
    case: (h = 0%r) => [->|nz_h].
    - have ->: f (x0 + 0%r) = f x0 by ring. smt().
    have hh': 0%r < `|h - 0%r| < a'' by smt().
    have := hbnd h hh'. smt().
  exists a'; split=> // h nz_h hh.
  by apply: slopeInv => //#.
(* Define the limits *)
pose lf := derivative f x0.
pose linv := derivative (fun x => inv (f x)) x0.
(* Show that slope f x0 converges to lf - we need cvg and then use the unique limit *)
have hcvg_f: cvgto (slope f x0) 0%r lf.
+ rewrite /lf /derivative.
  have hcvg_exists: cvg (slope f x0) 0%r by rewrite /hasdrvt in hf.
  (* cvg gives us exists l, cvgto ... l. Use this directly *)
  (* The goal is cvgto (slope f x0) 0%r (lim (slope f x0) 0%r) *)
  (* lim returns the unique limit, so we need to show cvgto ... (lim ...) *)
  case: hcvg_exists => l' hl'.
  (* Goal: cvgto (slope f x0) 0%r (lim (slope f x0) 0%r) *)
  (* We have hl' in scope. Use rewrite to substitute *)
  rewrite (cvgto_lim (slope f x0) 0%r l') //#.
(* Show that slope (inv f) converges to linv *)
have hcvg_inv: cvgto (slope (fun x => inv (f x)) x0) 0%r linv.
+ rewrite /linv /derivative.
  move: hinv. rewrite /hasdrvt.
  by case=> l' hl'; smt(cvgto_lim).
(* Show linv = -lf / (f x0)^2 using uniqueness *)
have hcvg_alt: cvgto (slope (fun x => inv (f x)) x0) 0%r 
                     (- lf * inv (f x0) * inv (f x0)).
+ apply: (eq_cvgto _ (fun h => - slope f x0 h * inv (f (x0 + h)) * inv (f x0))).
  * case: heq => e [gt0_e he].
    exists e; split=> // h nz_h hh.
    by rewrite he.
  apply: cvgtoN.
  apply: cvgtoM; last by apply: cvgtoC.
  by apply: cvgtoM.
have eq_linv: linv = - lf * inv (f x0) * inv (f x0) by apply: uniq_cvgto hcvg_inv hcvg_alt.
rewrite -/lf -/linv eq_linv.
smt().
qed.

(* -------------------------------------------------------------------- *)
(* Generated by AI *)
lemma derivativeV (f1 f2 : real -> real) (x0 : real) :
     hasdrvt f1 x0
  => hasdrvt f2 x0
  => f2 x0 <> 0%r
  =>   derivative (fun x => f1 x / f2 x) x0
     = (derivative f1 x0 * f2 x0 - f1 x0 * derivative f2 x0) / (f2 x0 * f2 x0).
proof.
move=> h1 h2 nz_f2.
(* f1/f2 = f1 * inv(f2) *)
have heq: (fun x => f1 x / f2 x) = (fun x => f1 x * inv (f2 x)).
+ by apply/fun_ext => x /=.
(* derivative of inv(f2) *)
have h_inv: hasdrvt (fun x => inv (f2 x)) x0 by apply: hasdrvtInv.
(* Apply product rule *)
rewrite heq derivativeM //.
(* Now need to show:
   derivative f1 x0 * inv (f2 x0) + f1 x0 * derivative (fun x => inv (f2 x)) x0
   = (derivative f1 x0 * f2 x0 - f1 x0 * derivative f2 x0) / (f2 x0 * f2 x0) *)
rewrite derivativeInv //.
smt().
qed.

(* -------------------------------------------------------------------- *)
lemma hasdrvtV (f1 f2 : real -> real) (x0 : real) :
     hasdrvt f1 x0
  => hasdrvt f2 x0
  => f2 x0 <> 0%r
  => hasdrvt (fun x => f1 x / f2 x) x0.
proof.
move=> h1 h2 nz_f2.
have h_inv: hasdrvt (fun x => inv (f2 x)) x0 by apply: hasdrvtInv.
have heq: (fun x => f1 x / f2 x) = (fun x => f1 x * inv (f2 x)).
+ by apply/fun_ext => x /=.
rewrite heq.
by apply: hasdrvtM.
qed.

(* -------------------------------------------------------------------- *)
lemma slopeN (f : real -> real) (x0 : real) :
  slope (fun x => - f x) x0 = (fun x => - slope f x0 x).
proof. by apply/fun_ext=> x @/slope /=; smt(). qed.

(* -------------------------------------------------------------------- *)
lemma derivativeN (f : real -> real) (x0 : real) :
     hasdrvt f x0
  =>   derivative (fun x => - f x) x0
     = -((derivative f) x0).
proof. by move=> h @/derivative; rewrite slopeN limN. qed.

(* -------------------------------------------------------------------- *)
lemma hasdrvtN (f : real -> real) (x0 : real) :
     hasdrvt f x0 => hasdrvt (fun x => - f x) x0.
proof. by move=> @/hasdrvt h; rewrite slopeN &(cvgN). qed.

(* -------------------------------------------------------------------- *)
(* Chain rule for derivatives *)
lemma slopeComp (f g : real -> real) (x0 : real) (h : real) :
  h <> 0%r => g (x0 + h) <> g x0 =>
    slope (fun x => f (g x)) x0 h 
  = slope f (g x0) (g (x0 + h) - g x0) * slope g x0 h.
proof.
move=> nz_h nz_gh @/slope /=.
pose dg := g (x0 + h) - g x0.
have nz_dg: dg <> 0%r by rewrite /dg /#.
have ->: g x0 + dg = g (x0 + h) by rewrite /dg; ring.
field; smt().
qed.

axiom hasdrvt_ln (y : real) : 0%r < y => hasdrvt ln y.

axiom derivative_ln (y : real) : 0%r < y => derivative ln y = inv y.

(* -------------------------------------------------------------------- *)
lemma hasdrvtComp (f g : real -> real) (x0 : real) :
     hasdrvt g x0
  => hasdrvt f (g x0)
  => hasdrvt (fun x => f (g x)) x0.
proof.
move=> @/hasdrvt [lg hg] [lf hf].
exists (lf * lg) => e gt0_e.
(* Get continuity of g *)
have cont_g: continuous g x0 by apply/hasdrvt_continuous; exists lg.
(* Set up epsilon splitting *)
pose Mg := `|lg| + 1%r.
pose Mf := `|lf| + 1%r.
have gt0_Mg: 0%r < Mg by smt().
have gt0_Mf: 0%r < Mf by smt().
pose e1 := e / (3%r * Mg).
pose e2 := e / (3%r * Mf).
pose e3 := e / 3%r.
have gt0_e1: 0%r < e1 by smt().
have gt0_e2: 0%r < e2 by smt().
have gt0_e3: 0%r < e3 by smt().
(* Get convergence deltas *)
have [df [gt0_df hdf]] := hf e1 gt0_e1.
have [dg [gt0_dg hdg]] := hg e2 gt0_e2.
have [d1 [gt0_d1 hd1]] := hg 1%r _; first by done.
have [d2 [gt0_d2 hd2]] := hf 1%r _; first by done.
(* Get continuity delta for g to ensure g(x0+h) is in the convergence region *)
have [dc [gt0_dc hdc]] := cont_g (minr df d2) _; first by smt().
(* The delta for when g(x0+h) = g(x0): we need |slope(f,g(x0),0) - lf| but slope is 0/0 *)
(* So we need separate handling for that case *)
(* Choose d small enough for all conditions *)
pose d := minr (minr (minr d1 dg) dc) e3.
have gt0_d: 0%r < d by smt().
exists d; split=> // h rgh.
(* Case split: g(x0+h) = g(x0) or g(x0+h) <> g(x0) *)
case: (g (x0 + h) = g x0) => [geq|gne].
+ (* When g(x0+h) = g(x0), the composed function has zero slope *)
  (* The slope is (f(g(x0+h)) - f(g(x0)))/h = 0 since g(x0+h) = g(x0) *)
  have nz_h: h <> 0%r by smt().
  have slope_fg: slope (fun x => f (g x)) x0 h = 0%r.
  - rewrite /slope /= geq; ring.
  rewrite slope_fg.
  (* Need: |0 - lf * lg| < e *)
  have h_lt_dg: `|h - 0%r| < dg by smt().
  have rgh_dg: 0%r < `|h - 0%r| < dg by smt().
  have slopeg_eq: slope g x0 h = 0%r by rewrite /slope geq; ring.
  have hlg_e2: `|slope g x0 h - lg| < e2 by apply: hdg; smt().
  have lg_bound: `|lg| < e2 by smt().
  (* Now |lf*lg| = |lf|*|lg| < Mf * e2 = Mf * e/(3*Mf) = e/3 < e *)
  have lf_bound: `|lf| < Mf by smt().
  (* |0 - lf*lg| = |lf*lg| = |lf| * |lg| *)
  have step1: `|0%r - lf * lg| = `|lf * lg| by smt().
  rewrite step1 normrM.
  (* |lf| * |lg| < Mf * e2 *)
  have step2: `|lf| * `|lg| < Mf * e2 by smt(normr_ge0 ltr_pmul).
  (* Mf * e2 = Mf * (e / (3 * Mf)) = e / 3 *)
  have step3: Mf * e2 = e / 3%r by rewrite /e2 /Mf; by field; smt().
  (* e / 3 < e *)
  by smt().
+ (* When g(x0+h) <> g(x0), use the chain rule factorization *)
  have nz_h: h <> 0%r by smt().
  pose dg' := g (x0 + h) - g x0.
  have nz_dg': dg' <> 0%r by rewrite /dg' /#.
  (* Use slopeComp: slope(f∘g, x0, h) = slope(f, g(x0), dg') * slope(g, x0, h) *)
  have scomp := slopeComp f g x0 h nz_h gne.
  rewrite scomp.
  (* Now we need: |slope f (g x0) dg' * slope g x0 h - lf * lg| < e *)
  (* Write as: slope f (g x0) dg' * slope g x0 h - lf * lg
             = (slope f (g x0) dg' - lf) * slope g x0 h 
               + lf * (slope g x0 h - lg) *)
  pose sf := slope f (g x0) dg'.
  pose sg := slope g x0 h.
  have eq: sf * sg - lf * lg = (sf - lf) * sg + lf * (sg - lg) by ring.
  rewrite eq.
  (* Bound each term *)
  (* First: |(sf - lf) * sg| *)
  (* We have |sg - lg| < e2, so |sg| <= |lg| + e2 < Mg *)
  have h_lt_dg: `|h - 0%r| < dg by smt().
  have rgh_dg: 0%r < `|h - 0%r| < dg by smt().
  have hsg: `|sg - lg| < e2 by rewrite /sg; apply: hdg; smt().
  have sg_bound: `|sg| < Mg by smt().
  (* For |sf - lf|: we need |dg'| in range and 0 < |dg'| *)
  (* From continuity: |g(x0+h) - g(x0)| < minr df d2 when |h| < dc *)
  have h_lt_dc: `|h| < dc by smt().
  have hdist: `|(x0 + h) - x0| = `|h| by smt().
  have hdist': 0%r < `|(x0+h) - x0| by smt().
  have hcont: `|g (x0 + h) - g x0| < minr df d2.
  - have := hdc (x0 + h) _; first by smt().
    smt().
  have dg'_lt_df: `|dg'| < df by rewrite /dg'; smt().
  have dg'_lt_d2: `|dg'| < d2 by rewrite /dg'; smt().
  (* Since |dg'| < df and 0 < |dg'|, we get |sf - lf| < e1 *)
  have hsf: `|sf - lf| < e1.
  - rewrite /sf /dg'.
    have rgdg': 0%r < `|(g (x0+h) - g x0) - 0%r| < df by smt().
    by apply: hdf.
  (* Now bound the full expression *)
  (* |(sf - lf) * sg + lf * (sg - lg)| <= |sf - lf| * |sg| + |lf| * |sg - lg| *)
  (*                                    < e1 * Mg + |lf| * e2 *)
  (*                                    < e1 * Mg + Mf * e2 *)
  (*                                    = e/(3*Mg) * Mg + Mf * e/(3*Mf) *)
  (*                                    = e/3 + e/3 = 2e/3 < e *)
  have term1: `|(sf - lf) * sg| < e1 * Mg.
  - rewrite normrM; have h1: `|sf - lf| < e1 by done.
    have h2: `|sg| < Mg by done.
    by smt(normr_ge0 ltr_pmul).
  have lf_bound: `|lf| < Mf by smt().
  have term2: `|lf * (sg - lg)| < Mf * e2.
  - by rewrite normrM &(ltr_pmul) 1,2:&(normr_ge0) //.
  have sum_bound: `|(sf - lf) * sg + lf * (sg - lg)| < e1 * Mg + Mf * e2.
  - have tri := ler_norm_add ((sf - lf) * sg) (lf * (sg - lg)).
    smt().
  (* e1 * Mg = e/(3*Mg) * Mg = e/3 and Mf * e2 = Mf * e/(3*Mf) = e/3 *)
  apply (ltr_trans (e1 * Mg + Mf * e2)) => //.
  rewrite /e1 /e2 &(ler_lt_trans (e * 2%r / 3%r)).
  - by apply lerr_eq; field; smt(normr_ge0).
  by smt().
qed.

(* -------------------------------------------------------------------- *)
lemma derivativeComp (f g : real -> real) (x0 : real) :
     hasdrvt g x0
  => hasdrvt f (g x0)
  => derivative (fun x => f (g x)) x0 = derivative f (g x0) * derivative g x0.
proof.
move=> hg hf.
(* Use hasdrvtComp to show composition has a derivative *)
have hcomp: hasdrvt (fun x => f (g x)) x0 by apply: (hasdrvtComp f g x0).
(* The derivative is the limit of the slope function *)
(* We need to show lim (slope (f∘g) x0) 0 = lf * lg where lf = derivative f (g x0), lg = derivative g x0 *)
pose lf := derivative f (g x0).
pose lg := derivative g x0.
pose lfg := derivative (fun x => f (g x)) x0.
(* From hasdrvt, we know the limits exist and are unique *)
have hcvg_f: cvgto (slope f (g x0)) 0%r lf.
- rewrite /lf /derivative.
  move: hf; rewrite /hasdrvt => -[l' hl'].
  by rewrite (cvgto_lim _ _ _ hl').
have hcvg_g: cvgto (slope g x0) 0%r lg.
- rewrite /lg /derivative.
  move: hg; rewrite /hasdrvt => -[l' hl'].
  by rewrite (cvgto_lim _ _ _ hl').
(* From the proof of hasdrvtComp, we know the limit is lf * lg *)
(* We need to show lfg = lf * lg *)
(* The proof of hasdrvtComp constructs a convergence proof to lf * lg *)
(* By uniqueness of limits, lfg = lf * lg *)
have hcvg_fg: cvgto (slope (fun x => f (g x)) x0) 0%r lfg.
- rewrite /lfg /derivative.
  move: hcomp; rewrite /hasdrvt => -[l' hl'].
  by rewrite (cvgto_lim _ _ _ hl').
(* Now we need to show the limit is lf * lg *)
(* Rebuild the convergence proof from hasdrvtComp *)
move: hg hf; rewrite /hasdrvt => -[lg' hcvg_g'] [lf' hcvg_f'].
(* By cvgto_lim, lg' = lg and lf' = lf *)
have eq_lg: lg' = lg by rewrite /lg /derivative (cvgto_lim _ _ _ hcvg_g').
have eq_lf: lf' = lf by rewrite /lf /derivative (cvgto_lim _ _ _ hcvg_f').
(* From hasdrvtComp proof, there is a convergence to lf' * lg' *)
(* We'll reconstruct the key convergence *)
have hcvg_prod: cvgto (slope (fun x => f (g x)) x0) 0%r (lf * lg).
- (* Get continuity of g *)
  have cont_g: continuous g x0 by apply/hasdrvt_continuous; exists lg'.
  (* Bound constants *)
  pose Mg := `|lg| + 1%r.
  pose Mf := `|lf| + 1%r.
  have gt0_Mg: 0%r < Mg by smt().
  have gt0_Mf: 0%r < Mf by smt().
  (* Define the cvgto proof *)
  move=> e gt0_e.
  pose e1 := e / (3%r * Mg).
  pose e2 := e / (3%r * Mf).
  pose e3 := e / 3%r.
  have gt0_e1: 0%r < e1 by smt().
  have gt0_e2: 0%r < e2 by smt().
  have gt0_e3: 0%r < e3 by smt().
  have [df [gt0_df hdf]] := hcvg_f' e1 gt0_e1.
  have [dg [gt0_dg hdg]] := hcvg_g' e2 gt0_e2.
  have [d1 [gt0_d1 hd1]] := hcvg_g' 1%r _; first by done.
  have [d2 [gt0_d2 hd2]] := hcvg_f' 1%r _; first by done.
  have [dc [gt0_dc hdc]] := cont_g (minr df d2) _; first by smt().
  pose d := minr (minr (minr d1 dg) dc) e3.
  have gt0_d: 0%r < d by smt().
  exists d; split=> // h rgh.
  case: (g (x0 + h) = g x0) => [geq|gne].
  + have nz_h: h <> 0%r by smt().
    have slope_fg: slope (fun x => f (g x)) x0 h = 0%r.
    - rewrite /slope /= geq; ring.
    rewrite slope_fg.
    have h_lt_dg: `|h - 0%r| < dg by smt().
    have rgh_dg: 0%r < `|h - 0%r| < dg by smt().
    have slopeg_eq: slope g x0 h = 0%r by rewrite /slope geq; ring.
    have hlg_e2: `|slope g x0 h - lg'| < e2 by apply: hdg.
    have lg'_bound: `|lg'| < e2 by smt().
    have lf'_bound: `|lf'| < Mf by smt().
    (* lg' = lg and lf' = lf *)
    have lg_bound: `|lg| < e2 by smt().
    have lf_bound: `|lf| < Mf by smt().
    have step1: `|0%r - lf * lg| = `|lf * lg| by smt().
    rewrite step1 normrM.
    have step2: `|lf| * `|lg| < Mf * e2 by smt(normr_ge0 ltr_pmul).
    rewrite &(ltr_trans (Mf * e2)) // /e2 &(ler_lt_trans (e / 3%r)).
    apply lerr_eq; field; smt(normr_ge0).
    by smt().
  + have nz_h: h <> 0%r by smt().
    pose dg' := g (x0 + h) - g x0.
    have nz_dg': dg' <> 0%r by rewrite /dg' /#.
    have scomp := slopeComp f g x0 h nz_h gne.
    rewrite scomp.
    pose sf := slope f (g x0) dg'.
    pose sg := slope g x0 h.
    have eq: sf * sg - lf * lg = (sf - lf) * sg + lf * (sg - lg) by ring.
    rewrite eq.
    have h_lt_dg: `|h - 0%r| < dg by smt().
    have rgh_dg: 0%r < `|h - 0%r| < dg by smt().
    have hsg: `|sg - lg'| < e2 by rewrite /sg; apply: hdg; smt().
    have hsg_lg: `|sg - lg| < e2 by smt().
    have sg_bound: `|sg| < Mg by smt().
    have h_lt_dc: `|h| < dc by smt().
    have hdist: `|(x0 + h) - x0| = `|h| by smt().
    have hdist': 0%r < `|(x0+h) - x0| by smt().
    have hcont: `|g (x0 + h) - g x0| < minr df d2.
    - have := hdc (x0 + h) _; first by smt(). smt().
    have dg'_lt_df: `|dg'| < df by rewrite /dg'; smt().
    have dg'_lt_d2: `|dg'| < d2 by rewrite /dg'; smt().
    have hsf': `|sf - lf'| < e1.
    - rewrite /sf /dg'.
      have rgdg': 0%r < `|(g (x0+h) - g x0) - 0%r| < df by smt().
      by apply: hdf.
    have hsf: `|sf - lf| < e1 by smt().
    have term1: `|(sf - lf) * sg| < e1 * Mg.
    - by rewrite normrM &(ltr_pmul) 1,2:&(normr_ge0) //.
    have lf_bound: `|lf| < Mf by smt().
    have term2: `|lf * (sg - lg)| < Mf * e2.
    - by rewrite normrM &(ltr_pmul) 1,2:&(normr_ge0) //.
    have sum_bound: `|(sf - lf) * sg + lf * (sg - lg)| < e1 * Mg + Mf * e2.
    - have tri := ler_norm_add ((sf - lf) * sg) (lf * (sg - lg)).
      by smt(normr_ge0 ltr_pmul).
    apply (ltr_trans (e1 * Mg + Mf * e2)) => //.
    apply (ler_lt_trans (e * 2%r / 3%r)).
    - by rewrite /e1 /e2 &(lerr_eq); field; smt(normr_ge0).
    by smt().
(* By uniqueness of limits *)
have huniq := uniq_cvgto (slope (fun x => f (g x)) x0) 0%r lfg (lf * lg) hcvg_fg.
by smt().
qed.

(* -------------------------------------------------------------------- *)
lemma derivativeL (f : real -> real) (x0 : real) :
     0%r < f x0
  => hasdrvt f x0
  =>   derivative (fun x => ln (f x)) x0
     = inv (f x0) * derivative f x0.
proof.
move=> gt0_fx0 hf.
by rewrite derivativeComp // 1:&(hasdrvt_ln) // derivative_ln.
qed.

(* -------------------------------------------------------------------- *)
lemma hasdrvtL (f : real -> real) (x0 : real) :
  0%r < f x0 => hasdrvt f x0 => hasdrvt (fun x => ln (f x)) x0.
proof.
move=> gt0_fx0 hf.
by rewrite &(hasdrvtComp) // &(hasdrvt_ln).
qed.

(* -------------------------------------------------------------------- *)
(* Bisection sequences for the Extreme Value Theorem proof.
   We define nested intervals [ba n, bb n] that bisect [l, r] such that
   the invariant "f is unbounded above on [ba n, bb n]" is maintained.
   This lets us derive a contradiction with continuity. *)

(* The bisection pair: given current interval [a,b] where f is unbounded,
   returns the half-interval where f is also unbounded. *)
op bisect_step (f : real -> real) (ab : real * real) : real * real =
  let (a, b) = ab in
  let m = (a + b) / 2%r in
  (* If f is unbounded on [m, b], take right half; else take left half *)
  if (forall B, exists x, m <= x <= b /\ f x > B)
  then (m, b) else (a, m).

(* The n-th bisection interval *)
op bisect (f : real -> real) (l r : real) : int -> real * real =
  fun n => iter n (bisect_step f) (l, r).

(* Left and right endpoints *)
op ba (f : real -> real) (l r : real) (n : int) : real =
  (bisect f l r n).`1.

op bb (f : real -> real) (l r : real) (n : int) : real =
  (bisect f l r n).`2.

(* Key properties of the bisection *)
lemma bisect0 (f : real -> real) (l r : real) :
  bisect f l r 0 = (l, r).
proof. by rewrite /bisect iter0. qed.

lemma bisectS (f : real -> real) (l r : real) (n : int) :
  0 <= n =>
  bisect f l r (n + 1) = bisect_step f (bisect f l r n).
proof. by move=> ge0n; rewrite /bisect iterS. qed.

lemma ba0 (f : real -> real) (l r : real) : ba f l r 0 = l.
proof. by rewrite /ba bisect0. qed.

lemma bb0 (f : real -> real) (l r : real) : bb f l r 0 = r.
proof. by rewrite /bb bisect0. qed.

(* If f unbounded on right half, ba advances to midpoint, bb stays *)
lemma ba_bb_step_right (f : real -> real) (l r : real) (n : int) :
  0 <= n =>
  (forall B, exists x, (ba f l r n + bb f l r n) / 2%r <= x <= bb f l r n /\ f x > B) =>
  ba f l r (n+1) = (ba f l r n + bb f l r n) / 2%r /\
  bb f l r (n+1) = bb f l r n.
proof.
move=> ge0n @/ba @/bb hunbdd.
have hkey : bisect f l r (n+1) = ((ba f l r n + bb f l r n) / 2%r, bb f l r n).
+ by rewrite bisectS 1:// /ba /bb /bisect_step /= /#.
by rewrite /ba /bb hkey /=; split.
qed.

(* If f NOT unbounded on right half, ba stays, bb advances to midpoint *)
lemma ba_bb_step_left (f : real -> real) (l r : real) (n : int) :
  0 <= n =>
  !(forall B, exists x, (ba f l r n + bb f l r n) / 2%r <= x <= bb f l r n /\ f x > B) =>
  ba f l r (n+1) = ba f l r n /\
  bb f l r (n+1) = (ba f l r n + bb f l r n) / 2%r.
proof.
move=> ge0n @/ba @/bb hnunbdd.
have hkey : bisect f l r (n+1) = (ba f l r n, (ba f l r n + bb f l r n) / 2%r).
+ by rewrite bisectS // /ba /bb /bisect_step /#.
rewrite /ba /bb hkey /=; by split.
qed.

(* The interval width decreases by half each step *)
lemma bisect_width (f : real -> real) (l r : real) (n : int) :
  0 <= n => l < r =>
  bb f l r n - ba f l r n = (r - l) / 2%r ^ n.
proof.
move=> ge0n lt_lr; elim: n ge0n => [|n ge0n ih].
- by rewrite /ba /bb bisect0 /= expr0 divr1.
- have width_pos : 0%r < bb f l r n - ba f l r n.
    rewrite ih; apply/divr_gt0; first by smt().
    by apply/expr_gt0; smt().
  have [hcond|hncond] : (forall B, exists x,
      (ba f l r n + bb f l r n) / 2%r <= x <= bb f l r n /\ f x > B) \/
    !(forall B, exists x,
      (ba f l r n + bb f l r n) / 2%r <= x <= bb f l r n /\ f x > B) by smt().
  + have [h1 h2] := ba_bb_step_right f l r n ge0n hcond.
    rewrite h1 h2; have hpow: 0%r < 2%r ^ n by apply/expr_gt0; smt().
    (* smt(exprS expr_gt0). *)
    (* the following four lines are hand-written, as smt does not finish in PG. *)
    rewrite exprS 1:// &(inj_eq (fun x => x * 2%r)) 1:/# /=.
    rewrite (: (r - l) * 2%r / (2%r * 2%r ^ n) = (r - l) / 2%r ^ n).
    + by field; smt(expr_gt0).
    by rewrite -ih /#.
  + have [h1 h2] := ba_bb_step_left f l r n ge0n hncond.
    rewrite h1 h2; have hpow: 0%r < 2%r ^ n by apply/expr_gt0; smt().
    (* smt(exprS expr_gt0). *)
    (* the following four lines are hand-written, as smt does not finish in PG. *)
    rewrite exprS 1:// &(inj_eq (fun x => x * 2%r)) 1:/# /=.
    rewrite (: (r - l) * 2%r / (2%r * 2%r ^ n) = (r - l) / 2%r ^ n).
    + by field; smt(expr_gt0).
    by rewrite -ih /#.
qed.

(* The left endpoint is non-decreasing *)
lemma ba_mono (f : real -> real) (l r : real) (n : int) :
  0 <= n => l < r =>
  ba f l r n <= ba f l r (n+1).
proof.
move=> ge0n lt_lr.
have width_pos : 0%r < bb f l r n - ba f l r n.
  rewrite bisect_width // divr_gt0 ?subr_gt0 // expr_gt0; smt().
have [hcond|hncond] : (forall B, exists x,
    (ba f l r n + bb f l r n) / 2%r <= x <= bb f l r n /\ f x > B) \/
  !(forall B, exists x,
    (ba f l r n + bb f l r n) / 2%r <= x <= bb f l r n /\ f x > B) by smt().
+ have [h1 _] := ba_bb_step_right f l r n ge0n hcond; rewrite h1; smt().
+ have [h1 _] := ba_bb_step_left f l r n ge0n hncond; rewrite h1; smt().
qed.

(* The right endpoint is non-increasing *)
lemma bb_mono (f : real -> real) (l r : real) (n : int) :
  0 <= n => l < r =>
  bb f l r (n+1) <= bb f l r n.
proof.
move=> ge0n lt_lr.
have width_pos : 0%r < bb f l r n - ba f l r n.
  rewrite bisect_width // divr_gt0 ?subr_gt0 // expr_gt0; smt().
have [hcond|hncond] : (forall B, exists x,
    (ba f l r n + bb f l r n) / 2%r <= x <= bb f l r n /\ f x > B) \/
  !(forall B, exists x,
    (ba f l r n + bb f l r n) / 2%r <= x <= bb f l r n /\ f x > B) by smt().
+ have [_ h2] := ba_bb_step_right f l r n ge0n hcond; rewrite h2; smt().
+ have [_ h2] := ba_bb_step_left f l r n ge0n hncond; rewrite h2; smt().
qed.

(* Both endpoints stay in [l, r] - proved jointly to avoid mutual dependency *)
lemma ba_bb_in_interval (f : real -> real) (l r : real) (n : int) :
  0 <= n => l <= r =>
  (l <= ba f l r n <= r) /\ (l <= bb f l r n <= r).
proof.
move=> ge0n le_lr; elim: n ge0n => [|n ge0n ih].
- by rewrite ba0 bb0; smt().
- case: (l < r) => [lt_lr|nlt_lr].
  + have [iha ihb] := ih.
    have width_pos : 0%r < bb f l r n - ba f l r n.
      rewrite bisect_width // divr_gt0 ?subr_gt0 // expr_gt0; smt().
    have [hcond|hncond] : (forall B, exists x,
        (ba f l r n + bb f l r n) / 2%r <= x <= bb f l r n /\ f x > B) \/
      !(forall B, exists x,
        (ba f l r n + bb f l r n) / 2%r <= x <= bb f l r n /\ f x > B) by smt().
    * have [h1 h2] := ba_bb_step_right f l r n ge0n hcond; rewrite h1 h2; smt().
    * have [h1 h2] := ba_bb_step_left f l r n ge0n hncond; rewrite h1 h2; smt().
  + have eq_lr: l = r by smt().
    subst; rewrite /ba /bb /bisect.
    have hbase: iter 0 (bisect_step f) (r, r) = (r, r) by rewrite iter0.
    have hstep: forall k, 0 <= k => iter k (bisect_step f) (r, r) = (r, r) =>
                  iter (k+1) (bisect_step f) (r, r) = (r, r).
    + move=> k ge0k hk; rewrite iterS //.
      rewrite /bisect_step hk /=.
      by rewrite (: (r + r) / 2%r = r) -1:/#; 1: field.
    suff : iter (n + 1) (bisect_step f) (r, r) = (r, r) by smt().
    rewrite /ba /bb /bisect in ih.
    have : iter n (bisect_step f) (r, r) = (r, r) by smt().
    by smt().
qed.

lemma ba_in_interval (f : real -> real) (l r : real) (n : int) :
  0 <= n => l <= r => l <= ba f l r n <= r.
proof. by move=> ge0n le_lr; have [] := ba_bb_in_interval f l r n ge0n le_lr. qed.

lemma bb_in_interval (f : real -> real) (l r : real) (n : int) :
  0 <= n => l <= r => l <= bb f l r n <= r.
proof. by move=> ge0n le_lr; have [] := ba_bb_in_interval f l r n ge0n le_lr. qed.

(* The invariant: if f is unbounded on [l,r], then it's unbounded on each bisect *)
lemma bisect_unbounded (f : real -> real) (l r : real) (n : int) :
  0 <= n => l < r =>
  (forall B, exists x, l <= x <= r /\ f x > B) =>
  forall B, exists x, ba f l r n <= x <= bb f l r n /\ f x > B.
proof.
move=> ge0n lt_lr hunbdd; elim: n ge0n => [|n ge0n ih].
- by rewrite ba0 bb0.
- pose m := (ba f l r n + bb f l r n) / 2%r.
  have [hcond|hncond] : (forall B, exists x, m <= x <= bb f l r n /\ f x > B) \/
    !(forall B, exists x, m <= x <= bb f l r n /\ f x > B) by smt().
  + have [h1 h2] := ba_bb_step_right f l r n ge0n hcond.
    by rewrite h1 h2.
  + have [h1 h2] := ba_bb_step_left f l r n ge0n hncond.
    rewrite h1 h2 => B'.
    (* hncond says f is bounded on [m, bb n] by some Bstar *)
    have [Bstar hBstar]: exists Bstar, forall x0, m <= x0 <= bb f l r n => f x0 <= Bstar by smt().
    have [x [hx hfx]] := ih (maxr Bstar B').
    (* x must be in [ba n, m) since f x > Bstar and hBstar bounds f on [m, bb n] *)
    have hfxBstar : m <= x => f x <= Bstar by move=> hmx; apply hBstar; smt().
    have hxlt : x < m by smt().
    exists x; smt().
qed.

(* The ba sequence (as an int->real function) is non-decreasing *)
lemma ba_monotone (f : real -> real) (l r : real) :
  l < r =>
  forall m n, (0 <= m <= n)%Int => ba f l r m <= ba f l r n.
proof.
move=> lt_lr; apply/monotoneP => n ge0n; apply/ba_mono => //.
qed.

(* The ba sequence converges (non-decreasing, bounded above) *)
lemma ba_converge (f : real -> real) (l r : real) :
  l < r =>
  convergeto (ba f l r) (lub (fun x => exists n, 0 <= n /\ ba f l r n = x)).
proof.
move=> lt_lr.
apply/(@cnvto_lub_bmono_from _ r 0).
- move=> n p [ge0n lep]; apply/ba_monotone => //.
- by move=> n ge0n; smt(ba_in_interval).
qed.

(* The width goes to 0 *)
lemma bisect_width_to_zero (f : real -> real) (l r : real) :
  l < r =>
  convergeto (fun n => bb f l r n - ba f l r n) 0%r.
proof.
move=> lt_lr e gt0_e.
have gt0_rl: 0%r < r - l by smt().
have gt0_rle: 0%r < (r - l) / e by smt(divr_gt0).
(* Find N0 >= 0 such that 2^N0 > (r-l)/e *)
pose N0 := max 0 (ceil (log 2%r ((r - l) / e)) + 1).
have hN0_ge0 : 0 <= N0 by rewrite /N0; smt(IntOrder.maxrl).
have hN0_ceil : ceil (log 2%r ((r - l) / e)) + 1 <= N0 by rewrite /N0; smt(IntOrder.maxrr).
(* Key: N0%r > log 2 ((r-l)/e) *)
have hlog_lt_N0 : log 2%r ((r - l) / e) < N0%r.
  have hceil := ceil_ge (log 2%r ((r - l) / e)).
  have hN0_ceil_r : (ceil (log 2%r ((r - l) / e)) + 1)%r <= N0%r.
  - by apply/le_fromint; exact hN0_ceil.
  rewrite fromintD in hN0_ceil_r; smt().
(* Therefore 2^N0 (as real power) > (r-l)/e *)
have h2N0_rpow : (r - l) / e < 2%r ^ N0%r.
  have hK : 2%r ^ (log 2%r ((r - l) / e)) = (r - l) / e by
    apply/rpowK; smt().
  have hN0_rpow_pos : 0%r < 2%r ^ N0%r by apply/rpow_gt0; smt().
  rewrite -(log_mono_ltr 2%r ((r - l) / e) (2%r ^ N0%r)) //.
  have hlogN0 : log 2%r (2%r ^ N0%r) = N0%r by apply/logK; smt().
  rewrite hlogN0; exact hlog_lt_N0.
(* 2^N0 (real power) equals 2^N0 (integer power) *)
have h2N0_int : 2%r ^ N0%r = 2%r ^ N0.
  apply/rpow_int; smt().
(* So (r-l)/2^N0 < e *)
have hN0_ineq : (r - l) / 2%r ^ N0 < e.
+ move : h2N0_rpow => h2N0_rpow.
  rewrite h2N0_int in h2N0_rpow; smt(expr_gt0 divr_gt0).
(* N0 is already non-negative, so use it as the witness directly *)
exists N0 => n hn.
have ge0_n: 0 <= n by smt().
have hwidth := bisect_width f l r n ge0_n lt_lr.
have ge0_width : 0%r <= bb f l r n - ba f l r n.
  rewrite hwidth; apply/divr_ge0.
  + rewrite subr_ge0; apply/ltrW; exact lt_lr.
  + by apply/ltrW/expr_gt0.
(* Step-by-step: first simplify and swap distance *)
rewrite /= distrC.
(* Now we have |ba f l r n - bb f l r n| <= e (after distrC swaps) *)
(* Since ba - bb <= 0, |ba - bb| = -(ba - bb) = bb - ba *)
have le0_neg_width : ba f l r n - bb f l r n <= 0%r by smt().
rewrite ler0_norm 1:le0_neg_width.
(* Now we have -(ba f l r n - bb f l r n) <= e, i.e., bb - ba <= e *)
rewrite opprB.
(* Now we have bb f l r n - ba f l r n <= e *)
rewrite hwidth.
have h2n_ge : 2%r ^ N0 <= 2%r ^ n.
  apply/ler_weexpn2l; first smt().
  split; smt().
have gt0_2n : 0%r < 2%r ^ n by apply/expr_gt0; smt().
have gt0_2N0 : 0%r < 2%r ^ N0 by apply/expr_gt0; smt().
have ge0_rl : 0%r <= r - l by smt().
have le_div : (r - l) / 2%r ^ n <= (r - l) / 2%r ^ N0.
  by apply/ler_wpmul2l => //; apply/lef_pinv.
smt().
qed.

(* Both ba and bb converge to the same limit *)
lemma ba_bb_same_limit (f : real -> real) (l r : real) :
  l < r =>
  let c = lub (fun x => exists n, 0 <= n /\ ba f l r n = x) in
  convergeto (ba f l r) c /\ convergeto (bb f l r) c.
proof.
move=> lt_lr /=.
pose c := lub (fun x => exists n, 0 <= n /\ ba f l r n = x).
have hba := ba_converge f l r lt_lr.
have hwidth := bisect_width_to_zero f l r lt_lr.
split => [//|].
(* bb n = ba n + (width n), so bb n -> c + 0 = c *)
apply/(@eq_cnvto (fun n => ba f l r n + (bb f l r n - ba f l r n))).
- move=> n /=; ring.
- apply/(@cnvtoDr0 _ (ba f l r) c hwidth hba).
qed.

(* Helper: if x is in [a,b], |a-c| < d/2, and b-a < d/2, then |x-c| < d *)
lemma interval_norm_bound (a b c d x : real) :
     a <= x <= b
  => `|a - c| < d / 2%r
  => b - a < d / 2%r
  => 0%r < d
  => `|x - c| < d.
proof.
move=> [hxa hxb] hac hba gt0_d.
(* From |a - c| < d/2, we get: -(d/2) < a - c < d/2 *)
have [hac_lo hac_hi] : -(d/2%r) < a - c /\ a - c < d/2%r by move: hac; rewrite ltr_norml.
(* x - c = (x - a) + (a - c) *)
(* Upper bound: x - c <= (b - a) + (a - c) < d/2 + d/2 = d *)
have hxc_hi: x - c < d.
  have h1: x - c = (x - a) + (a - c) by ring.
  have h2: x - a <= b - a by apply/ler_sub => //.
  have h3: (x - a) + (a - c) <= (b - a) + (a - c) by apply/ler_add => //.
  have h4: (b - a) + (a - c) < d/2%r + d/2%r by apply/ltr_add => //.
  have h5: d/2%r + d/2%r = d by field.
  rewrite h1; apply/(ler_lt_trans ((b - a) + (a - c))) => //.
  by rewrite -h5.
(* Lower bound: x - c >= a - c > -(d/2) > -d *)
have hxc_lo: -(d) < x - c.
  have h1: a - c <= x - c by apply/ler_sub => //.
  have h2: -(d/2%r) < a - c by exact/hac_lo.
  have h3: -(d) < -(d/2%r) by smt().
  by apply/(ltr_le_trans (a - c)) => //; apply/(ltr_trans (-(d/2%r))).
by rewrite ltr_norml.
qed.

(* Helper lemma: a continuous function on [l,r] is bounded above *)
lemma continuous_bounded_above (f : real -> real) (l r : real) :
     l < r
  => (forall x, l <= x <= r => continuous f x)
  => exists B, forall x, l <= x <= r => f x <= B.
proof.
move=> lt_lr hcont.
apply contraT => hnobdd.
(* hnobdd : !(exists B, forall x, l <= x <= r => f x <= B) *)
have hunbdd': forall B, exists x, l <= x <= r /\ f x > B.
  move=> B; apply/negbNE/negP => hbdd.
  apply/hnobdd; exists B => x hx.
  by apply/lerNgt/negP => hfx; apply/hbdd; exists x.
(* The bisection sequence converges to some c in [l, r] *)
pose c := lub (fun x => exists n, 0 <= n /\ ba f l r n = x).
have [hba hbb] := ba_bb_same_limit f l r lt_lr.
have le_lr: l <= r by apply/ltrW.
have hcl: l <= c.
  apply/(le_cnvto_from (fun _ => l) (ba f l r) l c).
  - exists 0 => n ge0n.
    have := ba_in_interval f l r n ge0n le_lr.
    by case.
  - by apply/cnvtoC.
  - exact/hba.
have hcr: c <= r.
  apply/(le_cnvto_from (ba f l r) (fun _ => r) c r).
  - exists 0 => n ge0n.
    have := ba_in_interval f l r n ge0n le_lr.
    by case.
  - exact/hba.
  - by apply/cnvtoC.
(* By continuity at c: f is bounded in a delta-neighborhood of c *)
have hclr: l <= c <= r by split.
have hcont_c := hcont c hclr 1%r _; first by done.
case: hcont_c => [d [gt0_d hd]].
(* For large n, [ba n, bb n] is inside (c - d, c + d) *)
have gt0_d2: 0%r < d / 2%r by apply/divr_gt0 => //; apply/ltr0Sn.
have [Nba hNba] := hba (d / 2%r) gt0_d2.
have hbwtz := bisect_width_to_zero f l r lt_lr (d / 2%r) gt0_d2.
case: hbwtz => [Nwidth hNwidth].
pose N := max 0 (max Nba Nwidth).
have ge0N: 0 <= N by smt(IntOrder.ler_maxl).
have hN_ge_Nba: Nba <= N by smt(IntOrder.ler_maxl IntOrder.ler_maxr).
have hN_ge_Nwidth: Nwidth <= N by smt(IntOrder.ler_maxl IntOrder.ler_maxr).
have hba_close: `|ba f l r N - c| < d / 2%r by apply/hNba/hN_ge_Nba.
have hNw := hNwidth N hN_ge_Nwidth.
rewrite subr0 in hNw.
have ge0_width: 0%r <= bb f l r N - ba f l r N.
  rewrite (bisect_width f l r N ge0N lt_lr); apply/divr_ge0.
  + by apply/subr_ge0/ltrW.
  + by apply/ltrW/expr_gt0.
have hwidth_small: bb f l r N - ba f l r N < d / 2%r.
  move: hNw; rewrite (ger0_norm _ ge0_width) => //.
(* Contradiction using bisect_unbounded with bound f(c) + 1 *)
have hunbdd_N := bisect_unbounded f l r N ge0N lt_lr hunbdd'.
have [x [[hxba hxbb] hfx]] := hunbdd_N (f c + 1%r).
(* Use helper lemma to show |x - c| < d *)
have hxc: `|x - c| < d.
  apply/(interval_norm_bound (ba f l r N) (bb f l r N) c d x).
  + by split.
  + exact/hba_close.
  + exact/hwidth_small.
  + exact/gt0_d.
(* Apply continuity at c to bound f(x) *)
case: (x = c) => [heq|hxnec].
+ move: hfx; rewrite heq => hfx.
  have hcontra: f c < f c + 1%r by apply/ltr_addl/ltr01.
  by have := ltr_trans _ _ _ hcontra hfx; rewrite ltrr.
+ have hxc_pos: 0%r < `|x - c| by rewrite normr_gt0 subr_eq0 hxnec.
  have hfxc: `|f x - f c| < 1%r by apply/hd; split.
  have hfx_ub: f x - f c < 1%r.
    apply/(ler_lt_trans `|f x - f c|); [apply/ler_norm | exact/hfxc].
  have hfx_bound: f x < f c + 1%r.
    by rewrite addrC -ltr_subl_addr.
  by have := ltr_trans _ _ _ hfx_bound hfx; rewrite ltrr.
qed.

(* Main EVT proof for maximum *)
lemma extreme_value_max (f : real -> real) (l r : real) :
     l < r
  => (forall x, l <= x <= r => continuous f x)
  => (exists c, l <= c <= r /\ forall x, l <= x <= r => f x <= f c).
proof.
move=> lt_lr hcont.
(* Step 1: f is bounded above on [l, r] *)
have [B hB] := continuous_bounded_above f l r lt_lr hcont.
(* Step 2: Let M = supremum of f on [l, r] *)
pose E := (fun y => exists x, l <= x <= r /\ f x = y).
have hE_nonempty: nonempty E by exists (f l); exists l; smt().
have hE_bdd: has_ub E by exists B => y [x [hx <-]]; apply/hB.
have hE_lub: has_lub E by split.
pose M := lub E.
have hM_ub: forall x, l <= x <= r => f x <= M.
  move=> x hx; apply/(lub_upper_bound E hE_lub); by exists x.
have hM_adh: forall eps, 0%r < eps => exists e, E e /\ M - eps < e.
+ exact (lub_adherent E hE_lub).
(* Step 3: Show M is attained. *)
(* Proof by contradiction: suppose M is NOT attained. *)
apply: contraT => hnomax.
(* hnomax : ~(exists c, l <= c <= r /\ forall x, l <= x <= r => f x <= f c) *)
(* Then for all x in [l,r], x is NOT a maximum, i.e., there exists y > f(x). *)
(* In particular, M is not attained. M - f(x) > 0 for all x in [l,r]. *)
have hgap: forall x, l <= x <= r => 0%r < M - f x.
  move=> x hx.
  have := hM_ub x hx.
  have hnotmax: !(l <= x <= r /\ forall y, l <= y <= r => f y <= f x) by smt().
  smt().
(* Define g(x) = 1/(M - f(x)), continuous and unbounded above on [l,r] *)
pose g := fun x => inv (M - f x).
(* g is continuous on [l,r] *)
have hgcont: forall x, l <= x <= r => continuous g x.
  move=> x0 hx0.
  (* g(x) = inv(M - f(x)). Since M - f(x0) > 0 and f is continuous at x0,
     M - f is continuous and nonzero at x0, so inv(M-f) is continuous. *)
  rewrite /g /continuous /cvgto => e gt0_e.
  have hgap0 := hgap x0 hx0.
  have hfcont := hcont x0 hx0.
  (* We need: |inv(M - f x) - inv(M - f x0)| < e for |x - x0| small *)
  (* Use: |inv u - inv v| = |u - v| / (|u| * |v|) when u,v ≠ 0 *)
  (* Choose delta1 so |f x - f x0| < (M - f x0)/2 when |x - x0| < delta1 *)
  (* This ensures M - f x > (M - f x0)/2 *)
  have hfcont' := hfcont ((M - f x0) / 2%r) _; 1: by smt().
  case: hfcont' => [delta1 [gt0_d1 hd1]].
  (* Choose delta2 so |f x - f x0| < e * (M - f x0)^2 / 2 when |x - x0| < delta2 *)
  have gt0_e2: 0%r < e * (M - f x0) ^ 2 / 2%r by smt(expr_gt0).
  have hfcont2 := hfcont (e * (M - f x0) ^ 2 / 2%r) gt0_e2.
  case: hfcont2 => [delta2 [gt0_d2 hd2]].
  exists (minr delta1 delta2); split; first smt().
  move=> x rg_x.
  have rg1: 0%r < `|x - x0| < delta1 by smt().
  have rg2: 0%r < `|x - x0| < delta2 by smt().
  have hdf1 := hd1 x rg1.
  have hdf2 := hd2 x rg2.
  (* M - f x > (M - f x0) / 2 *)
  have hgap_x: (M - f x0) / 2%r < M - f x by smt(ler_norml).
  have hgap_x_pos: 0%r < M - f x by smt().
  (* |g x - g x0| = |f x - f x0| / ((M - f x) * (M - f x0)) *)
  have neq_x: M - f x <> 0%r by apply/gtr_eqF; exact hgap_x_pos.
  have neq_x0: M - f x0 <> 0%r by apply/gtr_eqF; exact hgap0.
  have hneq_prod: (M - f x) * (M - f x0) <> 0%r by apply mulf_neq0.
  have heq: g x - g x0 = (f x - f x0) / ((M - f x) * (M - f x0)).
    smt(mulfV mulVf invfM).
  have hprod_pos: 0%r < (M - f x) * (M - f x0) by apply mulr_gt0.
  have hprod_lb: (M - f x0) ^ 2 / 2%r <= (M - f x) * (M - f x0).
    have : (M - f x0) / 2%r * (M - f x0) <= (M - f x) * (M - f x0).
    + apply/ler_wpmul2r; smt().
    rewrite expr2; smt().
  have hbound: `|g x - g x0| < e.
    rewrite heq normrM normrV ?(gtr0_norm _ hprod_pos) //.
    (* Goal: |f x - f x0| * inv ((M - f x) * (M - f x0)) < e *)
    have gt0_invP: 0%r < inv ((M - f x) * (M - f x0)) by apply/invr_gt0.
    apply/(ltr_le_trans (e * ((M - f x0) ^ 2 / 2%r) * inv ((M - f x) * (M - f x0)))).
    + by apply/ltr_pmul2r => //; exact hdf2.
    apply/(ler_trans (e * ((M - f x) * (M - f x0)) * inv ((M - f x) * (M - f x0)))).
    + apply/ler_wpmul2r; first by smt().
      by apply/ler_wpmul2l; [smt() | exact hprod_lb].
    by rewrite -mulrA mulfV; [smt() | rewrite mulr1].
  exact/hbound.
(* g is unbounded above on [l,r] *)
have hg_unbdd: forall B, exists x, l <= x <= r /\ B < g x.
  move=> B0.
  case: (0%r < B0) => [gt0_B | le0_B].
  + (* B0 > 0: find x with f(x) close to M, so M - f(x) < 1/B0, hence g(x) > B0 *)
    have gt0_invB: 0%r < inv B0 by apply/invr_gt0.
    have [eb [heb1 heb2]] := hM_adh (inv B0) gt0_invB.
    case: heb1 => xb [hxb hfxb].
    exists xb; split; first by exact hxb.
    have hgxb_pos := hgap xb hxb.
    have hMfxb_lt: M - f xb < inv B0 by smt().
    smt(ltf_pinv invrK).
  + have [ec [hec1 _]] := hM_adh 1%r _; first by done.
    case: hec1 => xc [hxc _].
    have hgxc_pos := hgap xc hxc.
    exists xc; split; first done.
    smt(invr_gt0 lerNgt).
(* g is continuous on [l,r] and unbounded above — contradicts continuous_bounded_above *)
have [B' hB'] := continuous_bounded_above g l r lt_lr hgcont.
have [xf [hxf hgxf]] := hg_unbdd (B' + 1%r).
have hBxf := hB' xf hxf.
have hlt := ltr_le_trans _ _ _ hgxf hBxf.
move: hlt => {hgxf hBxf hB' hg_unbdd hgcont hgap hM_adh hM_ub hE_lub hE_bdd hE_nonempty hB hcont hnomax g} hlt.
by have := ltr_addl B' 1%r; smt(ltr01).
qed.

lemma extreme_value_min (f : real -> real) (l r : real) :
     l < r
  => (forall x, l <= x <= r => continuous f x)
  => (exists c, l <= c <= r /\ forall x, l <= x <= r => f c <= f x).
proof.
move=> lt_lr hcont.
have [c [hc hmax]] := extreme_value_max (fun x => -(f x)) l r lt_lr _.
- move=> x hx; rewrite /continuous /cvgto => e gt0_e.
  have [a [gt0_a ha]] := hcont x hx e gt0_e.
  exists a; split => // y rgy.
  by have := ha y rgy; smt(normrN opprB).
exists c; split => // x hx.
have := hmax x hx; smt().
qed.

(* -------------------------------------------------------------------- *)
(* Derivative at interior extremum is zero *)
lemma derivative_at_extremum (f : real -> real) (c l r : real) :
     l < c < r
  => hasdrvt f c
  => (forall x, l <= x <= r => f x <= f c)
  => derivative f c = 0%r.
proof.
move=> [hlc hcr] @/hasdrvt [d hcvg] hmax.
(* d = derivative f c *)
have hd: derivative f c = d by rewrite /derivative; apply/cvgto_lim.
rewrite hd.
(* Show d <= 0: use small positive h *)
have hd_le: d <= 0%r.
+ apply/lerNgt/negP => hd_pos.
  (* Use e = d/2 > 0, get a1 from cvgto *)
  have gt0_e: 0%r < d / 2%r by smt().
  have [a1 [gt0_a1 hclose]] := hcvg (d / 2%r) gt0_e.
  (* Choose h positive, small enough that c+h <= r and 0 < h < a1 *)
  pose h := minr (a1 / 2%r) ((r - c) / 2%r).
  have gt0_h: 0%r < h by rewrite /h; smt().
  have h_lt_a1: h < a1 by rewrite /h; smt().
  have ch_le_r: c + h <= r by rewrite /h; smt().
  (* slope f c h <= 0 since f(c+h) <= f(c) and h > 0 *)
  have hslope_le: slope f c h <= 0%r.
  + rewrite /slope.
    have hfch: f (c + h) <= f c by apply/hmax; smt().
    smt().
  (* but |slope f c h - d| < d/2 means slope f c h > d/2 > 0, contradiction *)
  have hclose_h: `|slope f c h - d| < d / 2%r.
  + apply/hclose; smt(ger0_norm ltrW).
  smt().
(* Show d >= 0: use small negative h *)
have hd_ge: 0%r <= d.
+ apply/lerNgt/negP => hd_neg.
  have gt0_e: 0%r < (-d) / 2%r by smt().
  have [a1 [gt0_a1 hclose]] := hcvg ((-d) / 2%r) gt0_e.
  pose h := -(minr (a1 / 2%r) ((c - l) / 2%r)).
  have h_neg: h < 0%r by rewrite /h; smt().
  have neg_h_lt_a1: -h < a1 by rewrite /h; smt().
  have ch_ge_l: l <= c + h by rewrite /h; smt().
  have hslope_ge: 0%r <= slope f c h.
  + rewrite /slope.
    have hfch: f (c + h) <= f c by apply/hmax; smt().
    smt().
  have hclose_h: `|slope f c h - d| < (-d) / 2%r.
  + apply/hclose; smt(ler0_norm ltrW).
  smt().
smt().
qed.

(* -------------------------------------------------------------------- *)
(* Rolle's Theorem: If f(l) = f(r) and f is continuous on [l,r] and
   differentiable on (l,r), then there exists c in (l,r) with f'(c) = 0. *)
lemma rolle (f : real -> real) (l r : real) :
     l < r
  => (forall x, l <= x <= r => continuous f x)
  => (forall x, l < x < r => hasdrvt f x)
  => f l = f r
  => (exists c, l < c < r /\ derivative f c = 0%r).
proof.
move=> hlr hcont hdrvt heq.
have [cmax [hcmax_in hcmax_prop]] := extreme_value_max f l r hlr hcont.
have [cmin [hcmin_in hcmin_prop]] := extreme_value_min f l r hlr hcont.
(* Case: constant function (max = min) *)
case: (f cmax = f cmin) => [hconst|hnotconst].
- (* f is constant on [l,r], so derivative is 0 everywhere in (l,r) *)
  exists ((l + r) / 2%r); split; first by smt().
  have hf_const: forall x, l <= x <= r => f x = f l.
  + move=> x hx.
    have h1: f x <= f cmax by apply/hcmax_prop.
    have h2: f cmin <= f x by apply/hcmin_prop.
    smt().
  have hder_eq: derivative f ((l + r) / 2%r) = derivative (fun _ => f l) ((l + r) / 2%r).
  + apply/eq_derivative_r.
    exists ((r - l) / 2%r); split; first by smt().
    move=> x hx hxe.
    rewrite /slope /=.
    have hx1: l <= (l + r) / 2%r + x <= r by smt().
    have hx2: l <= (l + r) / 2%r <= r by smt().
    rewrite (hf_const _ hx1) (hf_const _ hx2); ring.
  by rewrite hder_eq derivativeC.
- (* Not constant: max > min, one extremum must be interior *)
  case: (f cmax <> f l) => [hmax_ne | hmax_eq].
  + (* cmax must be in (l,r) since f(cmax) != f(l) = f(r) *)
    have hcmax_ne_l: cmax <> l by smt().
    have hcmax_ne_r: cmax <> r by smt().
    have hcmax_int: l < cmax < r by smt().
    exists cmax; split => //.
    apply/(derivative_at_extremum f cmax l r hcmax_int (hdrvt cmax hcmax_int) hcmax_prop).
  + (* max = f(l) = f(r); since not constant, min != f(l), so min is interior *)
    have hfmax_eq_fl: f cmax = f l by smt().
    have hmin_ne: f cmin <> f l by smt().
    have hcmin_ne_l: cmin <> l by smt().
    have hcmin_ne_r: cmin <> r by smt().
    have hcmin_int: l < cmin < r by smt().
    have hdrvt_cmin: hasdrvt f cmin by apply/hdrvt.
    exists cmin; split => //.
    have hdrvt_neg: hasdrvt (fun x => - f x) cmin by apply/hasdrvtN.
    have hmax_neg: forall x, l <= x <= r => (fun x => - f x) x <= (- f cmin).
    + by move=> x hx /=; rewrite ler_opp2; apply/hcmin_prop.
    have hderiv_neg_zero: derivative (fun x => - f x) cmin = 0%r.
    + exact/(derivative_at_extremum (fun x => - f x) cmin l r hcmin_int hdrvt_neg hmax_neg).
    have hderiv_N: derivative (fun x => - f x) cmin = - derivative f cmin.
    + by apply/derivativeN.
    smt().
qed.

(* -------------------------------------------------------------------- *)
(* A linear function is differentiable everywhere *)
lemma hasdrvt_affine (m b : real) (x0 : real) :
  hasdrvt (fun x => m * x + b) x0.
proof.
apply/hasdrvtD.
+ have ->: (fun x => m * x) = (fun x => m * idfun x) by apply/fun_ext.
  by apply/hasdrvtZ/hasdrvt_idfun.
+ by apply/hasdrvtC.
qed.

(* -------------------------------------------------------------------- *)
(* Derivative of a linear function *)
lemma derivative_affine (m b : real) (x0 : real) :
  derivative (fun x => m * x + b) x0 = m.
proof.
rewrite derivativeD 1:hasdrvtZ 1:hasdrvt_idfun 1:hasdrvtC //.
rewrite derivativeC.
have ->: (fun x => m * x) = (fun x => m * idfun x) by apply/fun_ext.
rewrite derivativeZ 1:hasdrvt_idfun derivative_idfun.
ring.
qed.

(* -------------------------------------------------------------------- *)
(* Mean Value Theorem *)
lemma mean_value (f : real -> real) (l r : real) :
     l < r
  => (forall x, l <= x <= r => continuous f x)
  => (forall x, l < x < r => hasdrvt f x)
  => (exists c, l < c < r /\ derivative f c = ((f r - f l) / (r - l))).
proof.
move=> hlr hcont hdrvt.
pose m := (f r - f l) / (r - l).
pose b := f l - m * l.
(* h(x) = f(x) - (m*x + b) is the deviation from the secant line *)
pose h := fun x => f x - (m * x + b).
have hh_l: h l = 0%r by rewrite /h /b; ring.
have hh_r: h r = 0%r.
+ rewrite /h /b /m; field; smt().
have hh_cont: forall x, l <= x <= r => continuous h x.
+ move=> x hx.
  have hfcont: continuous f x by apply/hcont.
  have ->: h = (fun x => f x + (- (m * x + b))) by apply/fun_ext => y; rewrite /h; ring.
  (* h = f + (-(m*x+b)); both are continuous, so h is continuous *)
  have hgcont: continuous (fun x => - (m * x + b)) x.
  + apply/hasdrvt_continuous/hasdrvtN/hasdrvt_affine.
  (* Now show continuous (fun x => f x + (-(m*x+b))) x *)
  (* continuous means cvgto (fun y => f y + -(m*y+b)) x (f x + -(m*x+b)) *)
  move: hfcont hgcont; rewrite /continuous => hf hg.
  by apply/cvgtoD.
have hh_drvt: forall x, l < x < r => hasdrvt h x.
+ move=> x hx.
  have ->: h = (fun x => f x + (- (m * x + b))) by apply/fun_ext => y; rewrite /h; ring.
  apply/hasdrvtD.
  * by apply/hdrvt.
  * by apply/hasdrvtN/hasdrvt_affine.
have [c [hc_range hc_zero]] := rolle h l r hlr hh_cont hh_drvt _.
+ by rewrite hh_l hh_r.
exists c; split => //.
have hfc_drvt: hasdrvt f c by apply/hdrvt.
(* Compute derivative of h at c *)
have hderiv_h: derivative h c = derivative f c - m.
+ have ->: h = (fun x => f x + (- (m * x + b))) by apply/fun_ext => y; rewrite /h; ring.
  rewrite derivativeD //.
  * by apply/hasdrvtN/hasdrvt_affine.
  rewrite derivativeN 1:hasdrvt_affine derivative_affine.
  ring.
smt().
qed.

(* -------------------------------------------------------------------- *)
(* Consequence of MVT: If derivative is non-positive, function is decreasing *)
lemma derivative_nonpos_implies_decrease (f : real -> real) (l r : real) :
     l < r
  => (forall x, l <= x <= r => continuous f x)
  => (forall x, l < x < r => hasdrvt f x)
  => (forall x, l < x < r => derivative f x <= 0%r)
  => (f r <= f l).
proof.
move=> lt_lr hcont hdrvt hnonpos.
have [c [hc_range hc_eq]] := mean_value f l r lt_lr hcont hdrvt.
have hnonpos_c := hnonpos c hc_range.
have h: (f r - f l) / (r - l) <= 0%r by smt().
(* Since r - l > 0, we have f r - f l <= 0 *)
rewrite mulrC ler_pdivr_mull 1:/# mulr0 in h.
by smt().
qed.
