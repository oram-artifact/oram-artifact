require import AllCore List FMap SmtMap IntDiv IntMin FSet.

require import Aux.
(*---*) import ListUtils FMapUtils.

require import ORAM.
(*---*) import UniPath.

(* ==================================================================== *)
(* Variable info                                                        *)

(* -------------------------------------------------------------------- *)
(* For a variable, we store the leaf we the variable should be (i.e.    *)
(* its path in the position map) and the actual depth where the         *)
(* is actually stored. We also store the value associated to the        *)
(* variable in the ORAM tree.                                           *)
type varinfo = { path: path; depth: depth; value: value; }.

(* -------------------------------------------------------------------- *)
op idepth (vi : varinfo) : int =
  of_depth vi.`depth.

(* -------------------------------------------------------------------- *)
(* Returns a node from of varinfo: path truncated at depth              *)
op node_of_varinfo (vi : varinfo) : node =
  node_at_depth vi.`path vi.`depth.

(* -------------------------------------------------------------------- *)
op varinfo2block (vi : varinfo) : block =
  {| bpath = vi.`path; bvalue = vi.`value |}.

(* -------------------------------------------------------------------- *)
op block2varinfo (b : block) (d : depth) : varinfo =
  {| path = b.`bpath; value = b.`bvalue; depth = d |}.

(* -------------------------------------------------------------------- *)
lemma size_node_of_varinfo (vi : varinfo) :
  size (node_of_varinfo vi) = idepth vi.
proof.
rewrite /size /node_of_varinfo of_node_at_depth.
by rewrite size_take_condle -1:ifT // #smt:(of_depthP of_pathP).
qed.

(* -------------------------------------------------------------------- *)
lemma node_is_on_path_self (vi : varinfo) :
  node_is_on_path (node_of_varinfo vi) vi.`path.
proof.
rewrite /node_is_on_path /node_of_varinfo /node_at_depth.
rewrite to_nodedK -1:&(isprefix_take).
by rewrite size_take #smt:(of_depthP of_pathP).
qed.

(* -------------------------------------------------------------------- *)
lemma depth_of_node_self (vi : varinfo) :
  depth_of_node (node_of_varinfo vi) = vi.`depth.
proof. by rewrite /depth_of_node size_node_of_varinfo of_depthKd. qed.

(* -------------------------------------------------------------------- *)
lemma child_is_on_path (vi : varinfo) (b : bool) :
     let d = idepth vi in
     d < h
  => b = (of_path vi.`path).[d]
  => node_is_on_path (oget (child (node_of_varinfo vi) b)) vi.`path.
proof.
move => /= ? -> @/child @/node_of_varinfo.
rewrite of_node_at_depth cats1 /node_is_on_path to_nodedK.
- by rewrite size_rcons size_take_condle -1:ifT /= #smt:(of_depthP of_pathP).
rewrite /idepth -take_nth 1:#smt:(of_depthP of_pathP).
apply/isprefixP; exists (drop (idepth vi + 1) (of_path vi.`path)).
by rewrite cat_take_drop.
qed.

(* ==================================================================== *)
(* ORAM as a partial map from variables to varinfos                     *)

(* An oram is simply a partial map from variables to varinfos           *)
type oram = (vars, varinfo) fmap.

(* -------------------------------------------------------------------- *)
(* Returns all the variables the are stored in the target node          *)
op bucket (o : oram) (n : node) : vars fset =
  let vars =
    filter
      (fun v : vars => omap node_of_varinfo o.[v] = Some n)
      FinVars.enum
  in FSet.oflist vars.

(* -------------------------------------------------------------------- *)
(* Size of the bucket of the target node                                *)
op bsize (o : oram) (n : node) =
  card (bucket o n).

(* -------------------------------------------------------------------- *)
(* Returns the blocks associated to the node [n]                        *)
op blocks (o : oram) (n : node) : (vars, block) fmap =
  map (fun _ vi => varinfo2block vi)
      (filter (fun _ vi => node_of_varinfo vi = n) o).

(* -------------------------------------------------------------------- *)
(* All blocks at a node satisfy the validity guard *)
lemma blocks_valid (o : oram) (n : node) :
  all (fun (_ : vars) (b : block) => node_is_on_path n b.`bpath) (blocks o n).
proof.
by rewrite allP => v b; rewrite /blocks mapE filterE /=;
   case (o.[v]) => //= vi; case (node_of_varinfo vi = n) => //=;
   smt(node_is_on_path_self).
qed.

(* -------------------------------------------------------------------- *)
(* Sets the blocks associated to the node [n].                          *)
(* The original blocks on node [n] are silently pruned.                 *)
op [opaque] setblocks (o : oram) (n : node) (bs : (vars, block) fmap) : oram =
  if all (fun (_ : vars) (b : block) => node_is_on_path n b.`bpath) bs then
    filter (fun _ vi => node_of_varinfo vi <> n) o
    + map (fun v b => block2varinfo b (depth_of_node n)) bs
  else witness.

lemma setblocks_valid (o : oram) (n : node) (bs : (vars, block) fmap) :
  all (fun (_ : vars) (b : block) => node_is_on_path n b.`bpath) bs =>
  setblocks o n bs = filter (fun (_ : vars) vi => node_of_varinfo vi <> n) o
                   + map (fun (_ : vars) b => block2varinfo b (depth_of_node n)) bs.
proof. by rewrite /setblocks => ->. qed.

(* -------------------------------------------------------------------- *)
(* Compute the position map of an ORAM tree                             *)
op position (o : oram) (v : vars) : path option =
  omap (fun vi => vi.`path) o.[v].

(* -------------------------------------------------------------------- *)
(* Count how many blocks belong to the target path                      *)
op path_count (o : oram) (p : path) : int =
  count
    (fun v : vars =>
      let varinfo = oget o.[v] in
        varinfo.`path = p)
    FinVars.enum.

(* -------------------------------------------------------------------- *)
(* Count how many blocks belong to some child at the target prefix      *)
op sub_prefix_count (o : oram) (n : node) (b : bool) : int =
  count
    (fun v : vars =>
      v \in o /\
      let varinfo = oget o.[v] in
           node_is_on_path (oget (child n b)) varinfo.`path
        /\ idepth varinfo <= size n)
    FinVars.enum.

(* -------------------------------------------------------------------- *)
(* putback a variable [v] at a path [p] with value [vl]                 *)
(*  - [v] is moved to the root of the ORAM                              *)
(*  - [v] is binded to the tarfget path [p]                             *)
(*  - [v] is associated to the value [v.2]                              *)
op putback (o : oram) (v : vars) (p : path) (vl : value) : oram =
  o.[v <- {| path = p; depth = to_depthd 0; value = vl |}].

(* -------------------------------------------------------------------- *)
(* Flush the ORAM tree along the path [p]                               *)
op flush (o : oram) (p : path) : oram =
  map (fun _ vi =>
        let node = cprefix p vi.`path in
          if of_depth vi.`depth <= size node then
            {| vi with depth = depth_of_node node |}
          else vi)
      o.

(* ==================================================================== *)
(* -------------------------------------------------------------------- *)
(* Check whether there is an overflow at the target node                *)
op overflowat (o : oram) (n : node) : bool =
  K < bsize o n.

(* -------------------------------------------------------------------- *)
(* Check whether there is an overflow anywhere in the ORAM tree         *)
op overflow (o : oram) : bool =
  exists (n : node), overflowat o n.

(* -------------------------------------------------------------------- *)
op toverflow (os : oram list) : bool =
  exists o, o \in os /\ overflow o.

(* -------------------------------------------------------------------- *)
op toverflowat (os : oram list) (n : node) : bool =
  exists o, o \in os /\ overflowat o n.

(* -------------------------------------------------------------------- *)
op coverflowat (os : oram list) (n : node) (b : bool) : bool =
  exists o, o \in os /\ K %/ 2 <= sub_prefix_count o n b.

(* ==================================================================== *)
(* An "imperative" formalization                                        *)

module SimpleORAM = {
  var leakages : (leakage * leakage * leakage) list
  var os : oram list

  proc get_leakages() = { return leakages; }

  proc fetch(oram : oram, v : vars) : oram * value * leakage = {
    var i, j : int;
    var aout : value option;
    var bs   : (vars, block) fmap;
    var n    : node;
    var p, rp: path;
    var opleak : leakage;

    aout <- None;

    rp   <$ dunipath;
    p    <- odflt rp (position oram v);

    opleak <- [];
    i    <- 0;
    while (i <= h) {
      n        <- node_at_depth p (to_depthd i);
      bs       <- blocks oram n;

      aout     <- if is_none aout then omap bvalue bs.[v] else aout;
      bs       <- rem bs v;
      oram     <- setblocks oram n bs;

      opleak <- (Read, n) :: (Write, n) :: opleak;

      i <- i + 1;
    }

    return (oram, oget aout, opleak);
  }

  proc putback(oram : oram, v : vars, value : value) : oram * leakage = {
    var path : path;
    var opleak : leakage;

    path <$ dunipath;

    opleak <- (Read, to_noded []) :: (Write, to_noded []) :: [];

    return (putback oram v path value, opleak);
  }

  proc flush(oram : oram) : oram * leakage = {
    var i      : int;
    var path   : path;
    var n      : node;
    var pushed : (vars, block) fmap;
    var pback  : (vars, block) fmap;
    var opleak : leakage;

    path   <$ dunipath;
    pushed <- FMap.empty;

    opleak <- [];
    i <- 0;
    while (i <= h) {
      n      <- node_at_depth path (to_depthd i);
      pushed <- FMap.(+) pushed (blocks oram n);
      pback  <- filter (fun _ b => i = size (cprefix path b.`bpath)) pushed;
      pushed <- filter (fun _ b => i < size (cprefix path b.`bpath)) pushed;
      oram   <- setblocks oram n pback;

      opleak <- (Read, n) :: (Write, n) :: opleak;

      i <- i + 1;
    }

    return (oram, opleak);
  }

  proc readwrite(oram : oram, inst : inst) : oram * value = {
    var val : value;
    var lf, lpb, lfl : leakage;

    (oram, val,lf) <@ fetch(oram, varV inst);
    os <- oram :: os;
    val <- if isRd inst then val else oget (valV inst);
    (oram, lpb) <@ putback(oram, varV inst, val);
    os <- oram :: os;
    (oram, lfl) <@ flush(oram);
    os <- oram :: os;

    leakages <- (lf,lpb,lfl) :: leakages;

    return (oram, val);
  }

  proc compile(p : prog) : value list = {
    var i : int;
    var path : path;
    var o : oram;
    var val : value;
    var vs : value list;

    os <- [];
    leakages <- [];

    o <- FMap.empty;
    vs <- [];

    i <- 0;
    while (i < size p) {
      (o, val) <@ readwrite(o, p.[i]);
      vs <- val :: vs;
      i <- i + 1;
    }
    return vs;
  }
}.

(* -------------------------------------------------------------------- *)
module DeterministicSimpleORAM = {
  include var SimpleORAM [-putback,flush,readwrite,compile]

  proc putback(oram : oram, v : vars, value : value, path : path) : oram * leakage = {
    var opleak;

    opleak <- (Read, to_noded []) :: (Write, to_noded []) :: [];

    return (putback oram v path value, opleak);
  }

  proc flush(oram : oram, path : path) : oram * leakage = {
    var i      : int;
    var n      : node;
    var pushed : (vars, block) fmap;
    var pback  : (vars, block) fmap;
    var opleak : leakage;

    pushed <- FMap.empty;

    opleak <- [];
    i <- 0;
    while (i <= h) {
      n      <- node_at_depth path (to_depthd i);
      pushed <- FMap.(+) pushed (blocks oram n);
      pback  <- filter (fun _ b => i = size (cprefix path b.`bpath)) pushed;
      pushed <- filter (fun _ b => i < size (cprefix path b.`bpath)) pushed;
      oram   <- setblocks oram n pback;

      opleak <- (Read, n) :: (Write, n) :: opleak;

      i <- i + 1;
    }

    return (oram, opleak);
  }

  proc readwrite(oram : oram, inst : inst) : oram * value = {
    var val : value;
    var path : path;
    var lf, lpb, lfl : leakage;

    (oram, val, lf) <@ fetch(oram, varV inst);
    os   <- oram :: os;
    val  <- if isRd inst then val else oget (valV inst);

    path <$ dunipath;
    (oram, lpb) <@ putback(oram, varV inst, val, path);
    os   <- oram :: os;

    path <$ dunipath;
    (oram, lfl) <@ flush(oram, path);
    os   <- oram :: os;

    leakages <- (lf,lpb,lfl) :: leakages;

    return (oram, val);
  }

  proc compile(p : prog) : value list = {
    var i : int;
    var path : path;
    var o : oram;
    var val : value;
    var vs : value list;

    os <- [];
    leakages <- [];

    o <- FMap.empty;
    vs <- [];

    i <- 0;
    while (i < size p) {
      (o, val) <@ readwrite(o, p.[i]);
      vs <- val :: vs;
      i <- i + 1;
    }
    return vs;
  }
}.

(* -------------------------------------------------------------------- *)
lemma simpleoram_eq_dsimpleoram_step (o : oram) (inst : inst) :
  equiv [
    SimpleORAM.readwrite ~ DeterministicSimpleORAM.readwrite:
         arg{1} = (o, inst) /\ arg{2} = (o, inst)
      /\ ={SimpleORAM.leakages,SimpleORAM.os}
        ==>
      ={res,SimpleORAM.leakages,SimpleORAM.os}
  ].
proof.
proc.
inline.
seq 11 11 : (={inst,p,oram,SimpleORAM.os,SimpleORAM.leakages,val,lf}).
+ by sim.
seq 12 14 : (={i0,inst,p,oram2,pushed,SimpleORAM.os,SimpleORAM.leakages,val,lpb,lf,opleak0,opleak1} /\ path0{1} = path1{2}).
+ by wp; sp; rnd; auto.
by sim.
qed.

(* -------------------------------------------------------------------- *)
lemma simpleoram_eq_dsimpleoram (p : prog) :
  equiv [
    SimpleORAM.compile ~ DeterministicSimpleORAM.compile:
      arg{1} = p /\ arg{2} = p
        ==>
      ={res,SimpleORAM.leakages,SimpleORAM.os}
  ].
proof.
proc.
while (={i,p,vs,o,SimpleORAM.os,SimpleORAM.leakages}).
+ seq 1 1: (={i,p,vs,o,SimpleORAM.os,SimpleORAM.leakages,val}).
  + by ecall (simpleoram_eq_dsimpleoram_step o{1} p{!1}.[i{1}]).
  by auto.
by auto.
qed.

(* -------------------------------------------------------------------- *)
lemma varinfo2blockK (vi : varinfo) :
  block2varinfo (varinfo2block vi) vi.`depth = vi.
proof. by smt(). qed.

(* -------------------------------------------------------------------- *)
lemma block2varinfoK (b : block) (d : depth) :
  varinfo2block (block2varinfo b d) = b.
proof. by smt(). qed.

(* -------------------------------------------------------------------- *)
lemma filter_map (f : (vars, varinfo) fmap) (p : block -> bool) :
    filter (fun _ b => p b)
           (map (fun _ vi => varinfo2block vi) f)
  = map (fun _ vi => varinfo2block vi)
        (filter (fun _ vi => p (varinfo2block vi)) f).
proof.
apply fmap_eqP => v.
case (v \in f) => H_mem_v.
+ case (p (varinfo2block (oget f.[v]))) => //= ?.
  + apply oget_ext.
    + by rewrite -domNE mem_filter /= oget_map //= mem_map.
    + by rewrite -domNE mem_map mem_filter.
    rewrite get_filter.
    + by rewrite mem_filter /= oget_map //= mem_map.
    by rewrite !oget_map //= 1:mem_filter //= get_filter 1:mem_filter //=.
  + apply (eq_trans _ None).
    + by rewrite -domNE mem_filter /= oget_map //= /#.
    + by rewrite eq_sym -domNE mem_map mem_filter /= /#.
+ apply (eq_trans _ None).
  + by rewrite -domNE mem_filter /= mem_map /#.
  + by rewrite eq_sym -domNE mem_map mem_filter /#.
qed.

(* -------------------------------------------------------------------- *)
lemma mem_blocks (o : oram) (n : node) (v : vars) :
  v \in (blocks o n) <=> v \in o /\ node_of_varinfo (oget o.[v]) = n.
proof. by rewrite /blocks mem_map mem_filter. qed.

(* -------------------------------------------------------------------- *)
lemma blocks_get_some (o : oram) (n : node) (v : vars) :
  v \in (blocks o n) => (blocks o n).[v] = Some (varinfo2block (oget o.[v])).
proof.
move => Hb.
apply oget_ext.
+ by rewrite -domNE /#.
+ done.
+ rewrite mem_blocks in Hb.
  rewrite oget_some oget_map /= 1:#smt:(mem_filter) /=.
  by rewrite get_filter 1:#smt:(mem_filter).
qed.

(* -------------------------------------------------------------------- *)
lemma rem_blocks_same (o : oram) (n : node) (v0 : vars) :
  v0 \notin (blocks o n) => rem (blocks o n) v0 = blocks o n.
proof.
rewrite -fmap_eqP mem_blocks => ? v.
rewrite FMap.remE.
case (v = v0) => // ->.
by smt(domNE mem_blocks).
qed.

(* -------------------------------------------------------------------- *)
lemma set_rem_blocks_untouched (o : oram) (n : node) (v0 : vars) :
  v0 \notin (blocks o n) => (setblocks o n (rem (blocks o n) v0)) = o.
proof.
move => Hb.
have Hguard_blk := blocks_valid o n.
rewrite rem_id // -fmap_eqP => v.
have -> : setblocks o n (blocks o n) =
  filter (fun (_ : vars) vi => node_of_varinfo vi <> n) o
  + map (fun (_ : vars) b => block2varinfo b (depth_of_node n)) (blocks o n)
  by rewrite /setblocks Hguard_blk.
case (v \in blocks o n) => Hv.
+ (* v is at node n *)
  rewrite joinE mem_map Hv /= mapE omap_some /= 1:#smt:(domE).
  rewrite blocks_get_some // oget_some.
  by smt(oget_some varinfo2blockK depth_of_node_self mem_blocks).
+ (* v is not at node n *)
  by smt(joinE mem_map filterE mem_filter mem_blocks domE oget_some get_filter).
qed.

(* -------------------------------------------------------------------- *)
lemma set_rem_blocks_removed (o : oram) (n : node) (v0 : vars) :
  v0 \in (blocks o n) => setblocks o n (rem (blocks o n) v0) = rem o v0.
proof.
move => Hv0.
have Hguard : all (fun (_ : vars) (b : block) => node_is_on_path n b.`bpath) (rem (blocks o n) v0).
+ have /allP Hbv := blocks_valid o n.
  by rewrite allP => x y; rewrite remE; case (x = v0) => //= _; apply Hbv.
have Hsetblocks : setblocks o n (rem (blocks o n) v0) =
    filter (fun (_ : vars) vi => node_of_varinfo vi <> n) o
    + map (fun (_ : vars) b => block2varinfo b (depth_of_node n)) (rem (blocks o n) v0)
    by rewrite /setblocks Hguard.
rewrite -fmap_eqP => v.
case (v \in blocks o n) => Hv; rewrite Hsetblocks.
+ (* v is at node n *)
  case (v = v0) => [-> /= | v_neq_v0].
  - (* v = v0 *)
    rewrite joinE remE /= mem_map mem_rem /= -domNE mem_filter /=.
    by smt(mem_blocks).
  - (* v <> v0 *)
    rewrite joinE !remE v_neq_v0 //= mem_map mem_rem Hv v_neq_v0 /=.
    apply oget_ext.
    + by rewrite -domNE mem_map mem_rem /#.
    + by rewrite -domNE #smt:(mem_blocks).
    + rewrite oget_map 1:#smt:(mem_rem) /= remE v_neq_v0 /= blocks_get_some //.
      by rewrite oget_some #smt:(varinfo2blockK depth_of_node_self mem_blocks).
+ (* v is not at node n *)
  have v_ineq_v0 : v <> v0 by smt().
  rewrite joinE !remE (: ! v = v0) //= mem_map mem_rem /= Hv v_ineq_v0 /=.
  case (v \in o) => Hvo.
  + by rewrite get_filter // mem_filter /= #smt:(mem_blocks).
  + by smt(domNE mem_filter).
qed.

(* -------------------------------------------------------------------- *)
lemma fetch_fetch (_o : oram) (_v : vars) :
  phoare [ SimpleORAM.fetch : arg = (_o, _v)
       ==> res.`1 = rem _o _v
        /\ (_v \in _o => res.`2 = (oget _o.[_v]).`value) ] = 1%r.
proof.
conseq (: _ ==> true) (: _ ==> _) => //.
+ proc;wp.
  case (_o.[v] = None).
  + seq 3 : (oram = _o /\ v = _v /\ _o.[v] = None).
    + by auto.
    while (0 <= i <= h + 1 /\ _o.[v] = None /\ oram = _o).
    + auto => /> &hr *; do split.
      + by smt().
      + by smt().
      + by rewrite &(set_rem_blocks_untouched) mem_blocks /#.
    auto => /> *; split.
    + by smt(gt0_h).
    + by move => i *; rewrite rem_id 1:/# #smt:(domNE).
  + seq 3 : (oram = _o
          /\ v = _v
          /\ _o.[v] <> None
          /\ p = (oget _o.[v]).`path
          /\ aout = None).
    + by auto => /> /#.
    while (0 <= i <= h + 1
        /\ v \in _o
        /\ v = _v
        /\ p = (oget _o.[v]).`path
        /\ (i <= idepth (oget (_o.[v])) => oram = _o /\ aout = None)
        /\ (idepth (oget (_o.[v])) < i => oram = rem _o v /\ aout = Some (oget _o.[v]).`value)
    ).
    + auto => /> &hr 2? Ho H1 H2 *; do split.
      + by smt().
      + by smt().
      + move => ?; rewrite set_rem_blocks_untouched.
        + rewrite mem_blocks negb_and; right.
          by rewrite &(contra_congr Node.size) !size_node_at_depth to_depthdK /#.
        have -> /=: aout{hr} = None by smt().
        rewrite none_omap /blocks -domNE mem_map mem_filter /=; split; first by smt().
        rewrite negb_and; right.
        rewrite /node_of_varinfo &(contra_congr Node.size).
        by rewrite !size_node_at_depth to_depthdK /#.
      + move => ?; case (idepth (oget _o.[_v]) = i{hr}) => Hi.
        + have Hblock : _v \in (blocks oram{hr}
                                       (node_at_depth (oget _o.[_v]).`path (to_depthd i{hr}))).
          + by rewrite mem_blocks /= -Hi of_depthKd /#.
          split.
          + rewrite -fmap_eqP => v @/blocks.
            by rewrite set_rem_blocks_removed -1:/# H1 /#.
          + rewrite H1 1:/# (: is_none aout{hr}) 1:/# /=.
            have := Hblock.
            rewrite H1 1:/# -Hi of_depthKd.
            rewrite domE => /some_oget -> /= @/blocks.
            rewrite oget_map /= 1:#smt:(mem_filter of_depthKd).
            rewrite /varinfo2block /= get_filter //= #smt:(mem_filter of_depthKd).
        + have [-> ->] := H2 _; first by smt().
          split.
          + by rewrite set_rem_blocks_untouched // mem_blocks mem_rem.
          + by smt().
    auto => /> *; do split.
    + by smt(gt0_h).
    + by smt(of_depthP).
    + by move => i oram *; smt(of_depthP).
+ proc;wp.
  while (0 <= i <= h + 1) (h - i + 1).
  + by move => z; auto => /> /#.
  auto => />; split.
  + exact dunipath_ll.
  + by move => *; smt(gt0_h).
qed.

(* -------------------------------------------------------------------- *)
lemma putback_putback (_o : oram) (_var : vars) (_val : value) (_p : path) :
  phoare [ DeterministicSimpleORAM.putback : arg = (_o, _var, _val, _p) ==> res.`1 = putback _o _var _p _val ] = 1%r.
proof.
conseq (: _ ==> true) (: _ ==> _) => //.
+ by proc; auto.
+ by proc; auto.
qed.

(* -------------------------------------------------------------------- *)
lemma flush_flush (_o : oram) (_p : path) :
  phoare [ DeterministicSimpleORAM.flush : arg = (_o, _p) ==> res.`1 = flush _o _p ] = 1%r.
proof.
conseq (: _ ==> true) (: _ ==> _) => //.
+ proc; auto.
  while (0 <= i <= h + 1
    /\ _p = path

       (* nodes that will be potentially flushed but not reach cprefix yet *)
    /\ pushed = map (fun _ vi => varinfo2block vi)
                    (filter (fun _ vi => of_depth vi.`depth
                                       < i
                                      <= size (cprefix path vi.`path)) _o)
       (* four cases for the blocks on the target path:
            not touched (will be flushed, will never be flushed), flushed, being flushed *)
    /\ oram = map (fun _ vi => {| vi with depth = to_depthd (size (cprefix path vi.`path)) |})
                  (filter (fun _ vi => of_depth vi.`depth
                                     < size (cprefix path vi.`path)
                                     < i) _o)
            + filter (fun _ vi => size (cprefix path vi.`path) <= of_depth vi.`depth
                               \/ i <= of_depth vi.`depth) _o
  ).
  + auto => |> &hr *.

    pose curr_pushed := map (fun _ vi => varinfo2block vi)
                            (filter (fun _ vi => of_depth vi.`depth
                                               < i{hr}
                                               <= size (cprefix _p vi.`path)) _o).
    pose curr_oram := map (fun _ vi => {| vi with depth = to_depthd (size (cprefix _p vi.`path)) |})
                          (filter (fun _ vi => of_depth vi.`depth
                                             < size (cprefix _p vi.`path)
                                             < i{hr}) _o)
                        + filter (fun _ vi => size (cprefix _p vi.`path) <= of_depth vi.`depth
                                           \/ i{hr} <= of_depth vi.`depth) _o.
    pose n := node_at_depth _p (to_depthd i{hr}).
    pose pback := filter (fun _ b => i{hr} = size (cprefix _p b.`bpath))
                         (curr_pushed + blocks curr_oram n).

    have Hn : forall vi, (node_of_varinfo vi = n)
                     <=> (of_depth vi.`depth = i{hr} /\ i{hr} <= size (cprefix _p vi.`path)).
    + move => vi; split.
      + move => @/n Hvi.
        have ^H_depth_i -> /= : of_depth vi.`depth = i{hr}.
        + rewrite -depth_of_node_self Hvi /depth_of_node /node_at_depth.
          rewrite !to_depthdK 1,3:/#.
          + by rewrite /Node.size to_nodedK #smt:(size_take of_pathP).
          rewrite /Node.size to_nodedK 1:#smt:(size_take of_pathP).
          by rewrite size_takel 1:#smt:(of_pathP).
        rewrite -H_depth_i -depth_of_node_self /depth_of_node.
        rewrite to_depthdK /node_of_varinfo /node_at_depth.
        + by smt(to_nodedK size_take of_pathP).
        rewrite &(isprefix_size) -common_prefix; split.
        + rewrite -/(node_at_depth vi.`path vi.`depth).
          rewrite -/(node_of_varinfo vi) Hvi /node_at_depth.
          by smt(size_takel of_pathP to_depthdK to_nodedK).
        + by rewrite -/(node_at_depth vi.`path vi.`depth) &(isprefix_node_path).
      + rewrite /n /node_of_varinfo /node_at_depth.
        move => [#] ^H_depth_i ->.
        rewrite to_depthdK 1:/#.
        rewrite /cprefix /= /Node.size to_nodedK size_take 1,3:&(ge0_argmax).
        + by smt(of_pathP).
        rewrite -minrE_lt ler_min => [#].
        case (i{hr} = 0) => [ /# | ? ].
        rewrite -ge_argmax 1:/# => [#] _.
        elim => j /= [#] ?????; congr.
        apply (eq_trans _ (take i{hr} (take j (of_path vi.`path)))).
        + by rewrite take_take /#.
        rewrite &(eq_trans _ (take i{hr} (take j (of_path _p)))) 1:/#.
        by rewrite take_take /#.

    do split.
    + by smt().
    + by smt().
    + rewrite /curr_pushed /curr_oram /blocks.
      rewrite (filter_join_fset _ (FMap.filter _ _o) _).
      + by move => v; rewrite mem_map !mem_filter /#.
      rewrite (: filter _ (map _ (filter _ _o)) = FMap.empty).
      + rewrite -fmap_eqP => v /=.
        rewrite emptyE -domNE mem_filter /= negb_and -implybE mem_map => Hv.
        rewrite oget_map 1:// get_filter 1://.
        rewrite mem_filter /= in Hv.
        rewrite (contra_congr Node.size) -1:// !size_node_at_depth /=.
        by rewrite !to_depthdK 1:&(rng_size_cprefix) /#.
      rewrite empty_join filter_filter /=.
      rewrite -map_join filter_join_pred /=.
      rewrite filter_map filter_filter /=.
      rewrite &(eq_map) 1:/# &(eq_filter) 2:// &(fun_ext) => _.
      apply fun_ext => vi.
      by rewrite Hn /#.
    + (* show that the guard holds *)
      rewrite /setblocks (: all _ pback) /=.
      + rewrite /pback &(all_filter_imp) /= => b Hcpx @/n.
        by apply node_is_on_path_cprefix => /#.

      (* summarize the blocks from the current node *)
      rewrite /pback /blocks /curr_pushed /curr_oram.
      rewrite !(filter_join_fset (FMap.map _ _) (filter _ _o)).
      + by move => v; rewrite mem_map !mem_filter /#.
      + by move => v; rewrite mem_map !mem_filter /#.
      rewrite (: filter (fun _ vi => node_of_varinfo vi = n)
                        (map _ (filter _ _o))
               = FMap.empty).
      + rewrite -fmap_eqP => v /=.
        rewrite emptyE -domNE.
        pose p1 := fun _ vi => node_of_varinfo vi = n.
        pose p2 := fun _ vi => of_depth vi.`depth < size (cprefix _p vi.`path) < i{hr}.
        rewrite mem_filter mem_map negb_and -implybE => Hv.
        rewrite oget_map //= get_filter //= /p1 &(contra_congr Node.size).
        rewrite /n !size_node_of_varinfo size_node_at_depth /idepth /=.
        rewrite to_depthdK 1:#smt:(rng_size_cprefix) to_depthdK 1:/#.
        by smt(mem_filter).
      rewrite empty_join filter_filter /= /curr_pushed.
      rewrite filter_join_fset.
      + by move => v; rewrite !mem_map !mem_filter /#.
      rewrite !filter_map !filter_filter /=.

      (* summarize the blocks from the upside *)
      rewrite map_join !map_map /=.
      rewrite (filter_predT_in (FMap.map _ _)).
      + move => v /=.
        rewrite mem_map mem_filter /= => [#] *.
        rewrite oget_map 1:#smt:(mem_filter) get_filter 1:#smt:(mem_filter).
        rewrite &(contra_congr Node.size).
        rewrite /n size_node_of_varinfo size_node_at_depth /idepth /=.
        by rewrite to_depthdK 1:#smt:(rng_size_cprefix) to_depthdK /#.

      (* blocks from the current node are not changed *)
      rewrite (map_idfun_in (filter
                              (fun _ vi =>
                                   (i{hr} = size (cprefix _p (varinfo2block vi).`bpath)
                                /\ node_of_varinfo vi = n)
                                /\ (size (cprefix _p vi.`path) <= of_depth vi.`depth
                                     \/ i{hr} <= of_depth vi.`depth)) _o)).
      + move => v /= Hvn.
        rewrite get_filter 1://.
        rewrite mem_filter /= in Hvn.
        elim Hvn => |> ? <- *.
        by rewrite depth_of_node_self varinfo2blockK.

      (* reorder to match the goal *)
      pose A := FMap.map _ _.
      pose B := FMap.filter _ _.
      pose C := FMap.map _ _.
      pose D := FMap.filter _ _.
      have ? : forall v, !(v \in B /\ v \in C).
      + by move => v @/B @/C; rewrite mem_filter mem_map /= mem_filter /#.
      rewrite (: A + B + (C + D) = (A + C) + (B + D)) 1:#smt:(joinA joinC).
      rewrite /A /B /C /D &(eq_join).

      (* flushed = pushed from the upside and stoped at the current node + already flushed *)
      + rewrite (eq_map_in (filter _ _o)
                           (fun _ vi => block2varinfo (varinfo2block vi) (depth_of_node n))
                           (fun _ vi =>
                             {| vi with depth = to_depthd (size (cprefix _p vi.`path)) |})).
        + move => v H_mem_filter.
          rewrite get_filter 1://.
          move : H_mem_filter.
          rewrite mem_filter => [#] ???? y @/block2varinfo @/varinfo2block @/n /=.
          by rewrite depth_of_node_at_depth; congr; smt().
        rewrite -map_join filter_join_pred /=.
        rewrite &(eq_map) 1:// &(eq_filter) //=.
        apply fun_ext => _.
        apply fun_ext => vi.
        by rewrite /varinfo2block /= /#.
      (* untouched = remained at the current node + untouched before *)
      + rewrite filter_join_pred /= &(eq_filter)  //=.
        apply fun_ext => _.
        apply fun_ext => vi.
        by smt().

  auto => />; do split.
  + by smt(gt0_h).
  + rewrite -fmap_eqP => v.
    by rewrite emptyE eq_sym -domNE mem_map mem_filter #smt:(of_depthP).
  + rewrite (: map _ _ = empty).
    + rewrite -fmap_eqP => v.
      by rewrite emptyE -domNE mem_map mem_filter #smt:(List.size_ge0).
    by rewrite empty_join filter_predT_in /= #smt:(of_depthP).
  + move => i * @/flush.
    rewrite -fmap_eqP => v.
    case (v \in _o).
    + rewrite joinE mem_filter /= => ^Hvo -> /=.
      case _: (Node.size _ <= of_depth _) => ? /=.
      + rewrite get_filter 1:#smt:(mem_filter).
        apply oget_ext.
        + by rewrite -domE.
        + by rewrite -domE mem_map.
        + rewrite oget_map //=.
          case _ : (of_depth _ <= Node.size _) => /= [ ? | ].
          + by smt(of_depthK rng_size_cprefix).
          + done.
      + rewrite (: ! i <= _) 1:#smt:(of_depthP) /=.
        apply oget_ext.
        + by rewrite -domE mem_map mem_filter /= #smt:(rng_size_cprefix).
        + by rewrite -domE mem_map.
        + rewrite !oget_map 1:#smt:(mem_filter rng_size_cprefix) //.
          rewrite get_filter 1:#smt:(mem_filter rng_size_cprefix) /=.
          by rewrite (: of_depth _ <= Node.size _) 1:/#.
    + move => Hvo.
      apply (eq_trans _ None).
      + by rewrite -domNE mem_join mem_map !mem_filter /#.
      + by rewrite eq_sym -domNE mem_map.
+ proc; auto.
  while (0 <= i <= h + 1) (h - i + 1).
  + by move => z; auto => /> &hr * /#.
  auto => />; do split.
  + by smt(gt0_h).
  + by smt().
qed.
