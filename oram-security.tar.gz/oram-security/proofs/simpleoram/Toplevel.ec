require import AllCore List FSet FMap Distr DList RealSeries IntDiv Real RealExp.

require import StdBigop.
(*---*) import Bigreal Bigreal.BRA.

require import ORAM.
require import SimpleORAM.

require import StdOrder.
(*---*) import RealOrder.

require import RAM Obliviousness Abstracting Bound.

require import Aux.
(*---*) import ListUtils FMapUtils.

(*******************************************************************************)
(*******************************************************************************)
(************                     Bounded ORAM                     *************)
(*******************************************************************************)
(*******************************************************************************)

module ORAMBounded = {
  include var SimpleORAM [-readwrite,compile]

  proc readwrite(oram : oram, inst : inst) : oram * value = {
    var val : value;
    var lf,lpb,lfl;
    
    val <- witness;
    lf <- [];
    lpb <- [];
    lfl <- [];

    if (!toverflow SimpleORAM.os) {
      (oram, val,lf) <@ SimpleORAM.fetch(oram, varV inst);
      os <- oram :: SimpleORAM.os;
      val <- if isRd inst then val else oget (valV inst);
    }

    if (!toverflow SimpleORAM.os) {
      (oram,lpb) <@ SimpleORAM.putback(oram, varV inst, val);
      os <- oram :: SimpleORAM.os;
    }
    
    if (!toverflow SimpleORAM.os) {
      (oram,lfl) <@ SimpleORAM.flush(oram);
      os <- oram :: SimpleORAM.os;
      leakages <- (lf,lpb,lfl) :: leakages;
    }

    return (oram, val);
  }

  proc compile(p : prog) : value list = {
    var i : int;
    var path : path;
    var o : oram;
    var val : value;
    var vs : value list;
    
    os <- [];
    leakages <- [];

    o <- FMap.empty;
    vs <- [];

    i <- 0;
    while (i < size p) {
      (o, val) <@ readwrite(o, p.[i]);
      vs <- val :: vs;
      i <- i + 1;
    } 
    return vs;
  }
}.

(*******************************************************************************)
(*******************************************************************************)
(************              Security statement and proof            *************)
(*******************************************************************************)
(*******************************************************************************)

module type Dist_t = {
   proc find() : prog * prog
   proc dist(l : (leakage * leakage * leakage) list) : bool
}.

module type ORAM_t = {
  proc compile(p : prog) : value list
  proc get_leakages() : (leakage * leakage * leakage) list
}.

module ORAM_IND(O : ORAM_t,  D : Dist_t) = {
   proc main(b : bool, max_size : int) : bool = {
      var ps,l,b';
      b' <- false;
      SimpleORAM.os <- []; (* so that bad event is well defined
                        for invalid programs *)
      ps <@ D.find();
      if (size ps.`1 = size ps.`2 /\ size ps.`1 <= max_size) {
         O.compile(if b then ps.`1 else ps.`2);
         l <@ O.get_leakages();
         b' <@ D.dist(l);
      }
      return b';
   }
}.
        
op expandl(al : sleakage * sleakage) : leakage * leakage * leakage =
      let (pf,pfl) = al in
      let lf = flatten (map
       (fun i => (Read, node_at_depth pf (to_depthd i)) ::
                (Write, node_at_depth pf (to_depthd i)) :: []) 
                (rev (iota_ 0 (h+1)))) in
      let lpb =  (Read, to_noded []) :: (Write, to_noded []) :: [] in
      let lpu =  flatten (map
       (fun i => (Read, node_at_depth pfl (to_depthd i)) ::
                 (Write, node_at_depth pfl (to_depthd i)) :: [])
                (rev (iota_ 0 (h+1)))) in
           (lf,lpb,lpu).
           
op lsim(al : (sleakage * sleakage) list) : (leakage * leakage * leakage) list =
        (map expandl al).

module LSim(A : Dist_t) : ADist_t = {
   proc find() : prog * prog = {
       var ps;
       ps <@ A.find();
       return ps;
   }

   proc dist(al : (sleakage * sleakage) list) : bool = {
       var b;
       b <@ A.dist(lsim al);
       return b;

   }
}.

section.

declare module A <: Dist_t {-SecureORAM, -SimpleORAM}.
declare axiom A_ll : islossless A.dist.

op posmap_rel(o : oram, pm : vars -> path option) =
     forall (v : vars),
        (v \in o <=> pm v <> None) /\
        (v \in o => (oget o.[v]).`path = oget (pm v)).

op posmap_rel_fetch(o : oram, pm : vars -> path option, vv : vars) =
     forall (v : vars),
       v <> vv =>
        ((v \in o <=> pm v <> None) /\
         (v \in o => (oget o.[v]).`path = oget (pm v))).

op posmap_rel_flush(o : oram, pm : vars -> path option, pp : (vars, block) fmap) =
     forall (v : vars),
        (!(v \in o /\ v \in pp)) /\
        (((v \in o \/ v \in pp) <=> pm v <> None) /\
         (v \in o => (oget o.[v]).`path = oget (pm v)) /\
         (v \in pp => (oget pp.[v]).`bpath = oget (pm v))).
       
lemma security_abstraction &m _b max_size :
   Pr [ ORAM_IND(SimpleORAM,A).main(_b, max_size) @ &m : res ] =
     Pr [ AORAM_IND(SecureORAM,LSim(A)).main(_b, max_size) @ &m : res].
byequiv => //.
proc => /=.
seq 3 2 : (={b, glob A,ps,b', max_size}); 1: by inline *;wp;call(:true);auto.
if; 1,3: by auto.
seq 2 2 : (#pre /\ l{1} = lsim l{2}); last  by inline *; wp; call (:true); auto => />.
inline {1} 2; inline {2} 2;wp.
inline {1} 1; inline {2} 1.
inline SimpleORAM.readwrite SecureORAM.step.
sp 5 3;conseq />.
while(#post /\ 0 <= i{1} <= size p{1} /\ posmap_rel o{1} posmap{2} /\
      ={p,i}); last by auto => />;smt(size_ge0 mem_empty). 
wp;sp;conseq />.
seq 1 2 : (SimpleORAM.leakages{1} = lsim SecureORAM.leakages{2}
        /\ 0 <= i{1} < size p{1}
        /\ ={p,i} 
        /\ v{2} = varV p{2}.[i{2}]
        /\ varV inst{1} = v{2}
        /\ posmap_rel_fetch oram{1} posmap0{2} v{2}
        /\ lf{1} = flatten (map
              (fun ii => (Read, node_at_depth pf{2} (to_depthd ii)) ::
                  (Write, node_at_depth pf{2} (to_depthd ii)) :: []) 
                  (rev (iota_ 0 (h+1))))).
+ inline {1} 1.
  sp; seq 1 1 : (#pre /\ rp{1} = p0{2}); 1: by auto.
  sp 2 1;wp; conseq />.
  while {1} (   0 <= i0{1} <= h+1 
             /\ 0 <= i{1} < size p{1}
             /\ ={p,i,v} 
             /\ v{2} = varV p{2}.[i{2}]
             /\ varV inst{1} = v{2}
             /\ posmap_rel_fetch oram0{1} posmap0{2} v{2}  
             /\ p0{1} = (odflt p0{2} (posmap0{2} (varV p{2}.[i{2}]))) 
             /\ pf{2} = odflt p0{2} (posmap0{2} v{2}) 
             /\ v{2} = varV p{2}.[i{2}] /\ inst{1} = p{1}.[i{1}] 
             /\ opleak{1} = flatten
               (map (fun ii => (Read, node_at_depth pf{2} (to_depthd ii)) ::
                               (Write, node_at_depth pf{2} (to_depthd ii)) :: []) 
                                   (rev (iota_ 0 i0{1})))) (h+1 - i0{1}); last
           by auto => /> &1 &2 *;do split;smt(gt0_h iota0).
  move => &2 _z; auto => /> &1 *;do split; 1,2,5:smt().
  + move => _v ?; do split;
     1,2: by smt(set_rem_blocks_untouched set_rem_blocks_removed
                  mem_rem remE mem_blocks gt0_h iota0).
    by smt(set_rem_blocks_untouched set_rem_blocks_removed
           mem_rem remE mem_blocks joinE mem_join mem_filter mem_map gt0_h iota0).
  by rewrite iotaSr 1:/# /= rev_rcons /= flatten_cons cat_cons cat_cons.
  
seq 3 2 : (SimpleORAM.leakages{1} = lsim SecureORAM.leakages{2}
        /\ 0 <= i{1} < size p{1}
        /\ ={p,i} 
        /\ v{2} = varV p{2}.[i{2}]
        /\ varV inst{1} = v{2}
        /\ posmap_rel oram{1} posmap0{2} 
        /\ lf{1} = flatten (map
          (fun i => (Read, node_at_depth pf{2} (to_depthd i)) ::
                 (Write, node_at_depth pf{2} (to_depthd i)) :: []) 
                (rev (iota_ 0 (h+1)))) /\
    lpb{1} = (Read, to_noded []) :: (Write, to_noded []) :: []).
+ inline {1} 3.
  seq 2 0 : #pre; 1: by auto.
  sp;seq 1 1 : (#pre /\ path0{1} = ppb{2}); 1: by auto.  
  by auto => /> &1 &2 ?? _v;smt(get_setE).

inline *.
seq 1 0 : #pre; 1: by auto.
sp; seq 1 1 : (#pre /\ path0{1} = pfl{2}); 1: by auto. 
sp 2 0;wp;conseq />.
while {1} (0 <= i0{1} <= h+1
        /\ path0{1} = pfl{2}
        /\  posmap_rel_flush oram0{1} posmap0{2} pushed{1}
        /\ (i0{1} = h+1 => pushed{1} = empty)
        /\ (forall v, v \in pushed{1} =>
             i0{1} <= size (cprefix pfl{2} (oget pushed{1}.[v]).`bpath))
        /\  opleak{1} =
         flatten
          (map
            (fun ii => (Read, node_at_depth pfl{2} (to_depthd ii)) ::
                    (Write, node_at_depth pfl{2} (to_depthd ii)) :: []) 
                       (rev (iota_ 0 i0{1})))) (h + 1 - i0{1}); last first.
+ auto => /> &1 &2 *; do split;1..4: by smt(gt0_h iota0 mem_empty).
  move => i01 *; do split;1: smt().
  move => *;do split;2..:smt(size_ge0 mem_empty). 
  by rewrite /lsim /= /expandl /=;smt().

move => &2 _z;auto => /> &1 *; do split; 1,2,7:smt().
+ rewrite /posmap_rel_flush => v.
   have Hpb_guard : all (fun (_ : vars) (b : block) => node_is_on_path (node_at_depth pfl{2} (to_depthd i0{1})) b.`bpath)
     (filter (fun (_ : vars) (b : block) => i0{1} = size (cprefix pfl{2} b.`bpath))
             (pushed{1} + blocks oram0{1} (node_at_depth pfl{2} (to_depthd i0{1})))).
   + apply all_filter_imp => v0 b0 Hcpx.
     by apply node_is_on_path_cprefix; smt(rng_size_cprefix).
   have Hsetv := setblocks_valid oram0{1} _ _ Hpb_guard.
   do split;1,2:
    smt(gt0_h iota0 mem_join mem_rem mem_filter mem_map joinE remE).
   + move => ?.
     case (v \in pushed{1});1: by
     smt(gt0_h iota0 mem_join mem_rem mem_filter mem_map joinE remE).
     move => ?;have ? : (v \in oram0{1}) by smt().
     case (node_of_varinfo (oget oram0{1}.[v]) = node_at_depth pfl{2} (to_depthd i0{1})).
     + move => Hnode.
       have /isprefix_size : isprefix (node_at_depth pfl{2} (to_depthd i0{1}))
         (cprefix pfl{2} (oget oram0{1}.[v]).`path) by
         smt(common_prefix isprefix_node_path node_is_on_path_self).
       smt(mem_blocks mem_join mem_filter mem_map joinE blocks_get_some
           size_node_at_depth to_depthdK).
     + smt(mem_join mem_filter).
  + rewrite !Hsetv mem_join mem_filter /= mem_map mem_filter /= mem_join /==> H.
    rewrite joinE mem_map mem_filter /= mem_join.
    case H => [[Hin Hneq]|[Hmem Hcp]].
    + have ? : !(v \in pushed{1}) by smt().
      have ? : !(v \in blocks oram0{1} (node_at_depth pfl{2} (to_depthd i0{1}))) by smt(mem_blocks).
      smt(get_filter mem_filter).
    smt(joinE mapE filterE get_filter mem_join mem_map mem_filter mem_blocks blocks_get_some).
  + move => Hv; smt(get_filter joinE mem_join mem_filter mem_blocks blocks_get_some).
  + move => Heq.
    have ? : forall v0, !(v0 \in (filter (fun (_ : vars) (b0 : block) => i0{1} < size (cprefix pfl{2} b0.`bpath))
      (pushed{1} + blocks oram0{1} (node_at_depth pfl{2} (to_depthd i0{1}))))).
    + move => v0; rewrite mem_filter mem_join /=.
      by smt(rng_size_cprefix mem_blocks blocks_get_some).
    by apply fmap_eqP => v0; smt(emptyE domNE).
  + move => v0 Hv0; smt(get_filter mem_filter).
by rewrite iotaSr 1:/# /= rev_rcons /= flatten_cons cat_cons cat_cons.
qed.

end section.

(* Extracted equiv: ORAMBounded and SimpleORAM agree up to overflow *)
lemma compile_upto_bad :
  equiv [SimpleORAM.compile ~ ORAMBounded.compile :
    ={arg} ==>
    (toverflow SimpleORAM.os{1} <=> toverflow SimpleORAM.os{2}) /\
    (!toverflow SimpleORAM.os{2} => ={res, glob SimpleORAM})].
proof.
proc.
conseq (: (toverflow SimpleORAM.os{1} <=> toverflow SimpleORAM.os{2}) /\
          ((!toverflow SimpleORAM.os{2}) => ={glob SimpleORAM, o, vs})); 1: by smt().
while(#post /\ ={i,p} /\
     (! toverflow SimpleORAM.os{2} => ={o, vs})); last by auto.
wp; inline {1} 1; inline {2} 1.
swap {2} 3 -2; seq 0 1 : #pre; 1: by auto.
sp; if{2}; last first.
+ rcondf {2} ^if;1: by auto.
  rcondf {2} ^if;1: by auto.
  wp => /=.
  call {1} (: true ==> true).
  + by proc; while (0 <= i <= h+1) (h - i + 1);auto => />;smt(UniPath.dunipath_ll gt0_h).
  wp; call {1} (: true ==> true).
  + by islossless.
  wp; call {1} (: true ==> true).
  + by proc; while (0 <= i <= h+1) (h - i + 1);auto => />;smt(UniPath.dunipath_ll gt0_h).
  by auto => /> /#.
seq 3 3 :
 (={p,i,inst,val0,oram,glob SimpleORAM,lf} /\
i{1} < size p{1} /\ i{2} < size p{2} /\
(! toverflow SimpleORAM.os{2} => vs{1} = vs{2})).
+ conseq (:_ ==>  ={glob SimpleORAM,val0,oram,lf}); 1:by  move => &1 &2 [#] *;do split; smt().
  by sim => /#.
sp; if{2}; last first.
+ rcondf {2} ^if;1: by auto.
  wp => /=.
  call {1} (: true ==> true).
  + by proc; while (0 <= i <= h+1) (h - i + 1);auto => />;smt(UniPath.dunipath_ll gt0_h).
  wp; call {1} (: true ==> true).
  + by islossless.
  by auto => /> /#.
seq 2 2 :
 (={p,i,inst,oram,val0,glob SimpleORAM,lf,lpb} /\
i{1} < size p{1} /\ i{2} < size p{2} /\
(! toverflow SimpleORAM.os{2} => vs{1} = vs{2})).
+ conseq (:_ ==>  ={glob SimpleORAM,oram,lf,lpb}); 1:by  move => &1 &2 [#] *;do split; smt().
  by sim.
sp; if{2}; last first.
+ wp => /=.
  call {1} (: true ==> true).
  + by proc; while (0 <= i <= h+1) (h - i + 1);auto => />;smt(UniPath.dunipath_ll gt0_h).
  by auto => /> /#.
seq 2 2 :
 (={p,i,inst,oram,val0,glob SimpleORAM,lf,lpb,lfl} /\
i{1} < size p{1} /\ i{2} < size p{2} /\
(! toverflow SimpleORAM.os{2} => vs{1} = vs{2})).
+ conseq (:_ ==>  ={glob SimpleORAM,oram,lf,lpb,lfl}); 1:by  move => &1 &2 [#] *;do split; smt().
  by sim.
auto => /> &1 &2 *.
qed.

section.

declare module A <: Dist_t {-ORAMBounded, -SimpleORAM, -SecureORAM, -TapeSecureORAM, -TapeORAM, -RO, -LRO}.
declare axiom A_dist_ll : islossless A.dist.
declare axiom A_find_ll : islossless A.find.

lemma security_up_to_bad &m max_size :
   `| Pr [ ORAM_IND(ORAMBounded,A).main(true,max_size) @ &m : res ] -
        Pr [ ORAM_IND(ORAMBounded,A).main(false,max_size) @ &m : res  ] | <=
             Pr [ ORAM_IND(SimpleORAM,A).main(true,max_size) @ &m : toverflow SimpleORAM.os  ] + 
             Pr [ ORAM_IND(SimpleORAM,A).main(false,max_size) @ &m : toverflow SimpleORAM.os  ].
proof.
have Hbad : forall b,
  `| Pr [ ORAM_IND(ORAMBounded,A).main(b,max_size) @ &m : res ] -
              Pr [ ORAM_IND(SimpleORAM,A).main(b,max_size) @ &m : res ] | <=
       Pr [ ORAM_IND(SimpleORAM,A).main(b,max_size) @ &m : toverflow SimpleORAM.os  ].
+ move => _b;byequiv : (toverflow (SimpleORAM.os)) => //;last by smt().
  proc => //.
  seq 3 3 : (={glob A, b,b',ps,SimpleORAM.os,max_size}); 1: by sim.
  if;1,3: by auto.
  call(: toverflow SimpleORAM.os, ={glob SimpleORAM}, true); 1: by apply A_dist_ll.
  inline {1} 2; inline {2} 2; wp.
  symmetry; call compile_upto_bad; auto; smt().
have := Hbad false.
have := Hbad true.
rewrite (security_abstraction A); 1: by apply A_dist_ll.
rewrite (security_abstraction A); 1: by apply A_dist_ll.
have := abstract_security (LSim(A)) _ &m; 1: by proc;call A_dist_ll; auto. 
by smt().
qed.

lemma main_security &m _max_size :
   0 < _max_size =>
   `| Pr [ ORAM_IND(ORAMBounded,A).main(true,_max_size) @ &m : res ] -
        Pr [ ORAM_IND(ORAMBounded,A).main(false,_max_size) @ &m : res  ] |
         <= 2%r * 2%r ^ ((- K %/ 2) + 1)%r * (2%r ^ (h + 1)%r - 1%r) * (_max_size)%r.
proof.
move => ms_gt0.
have := security_up_to_bad &m _max_size.
pose pr := 2%r ^ ((- K %/ 2) + 1)%r * (2%r ^ (h + 1)%r - 1%r) * _max_size%r.
have ? : 0%r < pr.
+ suff : 0 %r < 2%r ^ ((- K %/ 2) + 1)%r; last by  smt(gt0_K rpow_gt0).
  suff : 0%r < (2%r ^ (h + 1)%r - 1%r) by smt().
  by have /= :=  rexpr_hmono 2%r 1%r (h+1)%r; rewrite rpow1 //=; smt(gt0_h).
have ? : forall b, Pr [ ORAM_IND(SimpleORAM,A).main(b,_max_size) @ &m : toverflow SimpleORAM.os  ] <= pr; last by smt().
move => _b; byphoare (: arg = (_b,_max_size) ==> _) =>/=.
proc.
 seq 3 : (SimpleORAM.os = [] /\ b = _b /\ max_size = _max_size) (pr) => /=. 
 + by auto. 
 + conseq (: _ ==> _ : =1%r) => /=; 1: by smt(RField.mulVf).
   by call (A_find_ll); auto => />.
 + if; last first.
   + hoare; 1: by smt(). 
     by auto.
   seq 1 : (toverflow SimpleORAM.os) (pr) (1%r) (1%r)  (0%r) .
   + by auto.
   + exlim ps => _ps.
     call(: arg =  (if _b then _ps.`1 else _ps.`2) /\ SimpleORAM.os = [] /\ size _ps.`1 = size _ps.`2 /\ size _ps.`1 <= _max_size ==> toverflow SimpleORAM.os).
     + bypr => &hr [->] ?; rewrite /pr.
       have :=  (final_bound &hr (if _b then _ps.`1 else _ps.`2)).
       suff :  (2%r ^ (h + 1)%r - 1%r) * (size (if _b then _ps.`1 else _ps.`2))%r <=  (2%r ^ (h + 1)%r - 1%r) * _max_size%r by smt(ler_pmul gt0_K rpow_gt0).
       apply ler_pmul.
       + by have /= :=  rexpr_hmono 2%r 1%r (h+1)%r; rewrite rpow1 //=; smt(gt0_h).
       + by smt(size_ge0).
       + by smt().
       + by smt().
     by auto.
   + by trivial.
   + by conseq |>;trivial.
   + by done.
   + by conseq />;hoare; call (:true);auto.
 + by smt().
 + by done.
 + by done.
qed.
   
end section.



(*******************************************************************************)
(*******************************************************************************)
(************            Correctness statement and proof           *************)
(*******************************************************************************)
(*******************************************************************************)

section Correctness.

declare module D <: CDist_t {-SimpleORAM, -ORAMBounded, -RAM}.
declare axiom D_ll : islossless D.dist.

lemma main_correctness &m _p :
  well_formed_prog _p =>
  `| Pr [ CORRECT_IND(ORAMBounded, D).main(_p) @ &m : res ] -
     Pr [ CORRECT_IND(RAM, D).main(_p) @ &m : res ] | <=
        2%r ^ ((- K %/ 2) + 1)%r * (2%r ^ (h + 1)%r - 1%r) * (size _p)%r.
proof.
move => Hwf.
(* Step 1: SimpleORAM = RAM exactly, so D can't distinguish them *)
have Heq : Pr[CORRECT_IND(SimpleORAM, D).main(_p) @ &m : res]
         = Pr[CORRECT_IND(RAM, D).main(_p) @ &m : res].
+ byequiv => //; proc.
  seq 1 1 : (={vs, glob D}); last by call (: true).
  by call (equiv_correct_compile _p Hwf); auto.
(* Step 2: ORAMBounded vs SimpleORAM up to bad, then apply D *)
have Hbad :
  `| Pr [ CORRECT_IND(ORAMBounded, D).main(_p) @ &m : res ] -
     Pr [ CORRECT_IND(SimpleORAM, D).main(_p) @ &m : res ] | <=
  Pr [ CORRECT_IND(SimpleORAM, D).main(_p) @ &m : toverflow SimpleORAM.os ].
+ byequiv : (toverflow (SimpleORAM.os)) => //.
  + symmetry; proc.
    call(: toverflow SimpleORAM.os, ={glob SimpleORAM}, true); 1: by apply D_ll.
    call compile_upto_bad; auto.
  + by smt().
  by smt().
(* Step 3: bound Pr[toverflow] in CORRECT_IND *)
rewrite -Heq.
suff Hoverflow : Pr[CORRECT_IND(SimpleORAM, D).main(_p) @ &m : toverflow SimpleORAM.os]
  <= 2%r ^ ((- K %/ 2) + 1)%r * (2%r ^ (h + 1)%r - 1%r) * (size _p)%r by smt().
byphoare (: arg = _p ==> _) => //.
proc.
seq 1 : (toverflow SimpleORAM.os)
  (2%r ^ ((- K %/ 2) + 1)%r * (2%r ^ (h + 1)%r - 1%r) * (size _p)%r)
  (1%r) (1%r) (0%r).
+ by auto.
+ call (: arg = _p ==> toverflow SimpleORAM.os).
  + bypr => &hr ->; apply (final_bound &hr _p).
  by auto.
+ by trivial.
+ by hoare; call (_: true); auto.
+ by smt().
qed.

end section Correctness.
