require import AllCore Bool Int List IntDiv RealExp Xreal.
(*---*) import RField.

require import Distr DBool DList.
(*---*) import Biased.

require import ORAM.
require import SimpleORAM.
(*---*) import UniPath FinPath.

require import StdBigop.
(*---*) import Bigreal Bigreal.BRA.

require import Aux.
(*---*) import ListUtils BoolTuple.

require import StdOrder.
(*---*) import IntOrder.

require import DartGame.

(* === modules : InternalORAM, SamplingLogger, DartGame === *)

module InternalORAM = {
  var logb, logw : int list
  var c : int
  
  proc step(base : node) = {
    var p : path;
    var b : bool;

    p <$ dunipath;
    b <- isprefix base (node_of_path p);
    c <- c + b2i b;
    logb <- logb ++ [c];

    p <$ dunipath;
    b <- isprefix base (node_of_path p);
    c <- b ? 0 : c;
    logw <- logw ++ [c];
  }

  proc compile(T : int, base : node) = {
    var i : int <- 0;
    logb <- [];
    logw <- [];
    c <- 0;
    while (i < T) {
      step(base);
      i <- i + 1;
    }
  }
}.

op ioverflow (logb logw : int list) =
  exists l, (l \in logb \/ l \in logw) /\ K %/ 2 + 1 = l.

(* === proof: the error bound probability over the internal oram abstraction === *)

lemma distr_path_then_prefixE (base : node) :
     0 < size base
  =>   dmap dunipath (fun (p : path) => isprefix base (node_of_path p))
     = dbiased (ipow2 (size base)).
proof.
move=> gtsz; apply/eq_distr => b; rewrite dmap1E /(\o).
rewrite dunipathE_sub dmapE /= /(\o).
rewrite -(mu_eq_support _ (fun bs => pred1 b (isprefix (of_node base) bs))) /=.
- move=> bs /supp_duniform hbs @/isprefix @/node_of_path.
  rewrite to_pathdK; first by move/in_wordn_size: hbs; smt(gt0_h).
  by rewrite to_nodedK; first by move/in_wordn_size: hbs; smt(gt0_h).
have hmu: mu (duniform (wordn h)) (isprefix (of_node base)) = ipow2 (size base).
- rewrite duniformE undup_id 1:uniq_wordn.
  rewrite size_wordn FinBool.cardE lez_maxr 1:#smt:(gt0_h) -size_filter.
  rewrite (perm_eq_size _ _ (filter_prefix_wordn h (of_node base) (of_nodeP _))).
  rewrite size_map size_wordn FinBool.cardE lez_maxr 1:#smt:(of_nodeP).
  rewrite -!fromintXn -1:-!rpow_nat // ~-1:#smt:(of_nodeP).
  by rewrite -rpowN // -rpowD // -fromintB addrAC /= fromintN.
rewrite dbiased1E !clamp_id ~-1:#smt:(rg_ipow2); case: b => _.
- by rewrite -(mu_eq _ (isprefix (of_node base))) 1:/# hmu.
- rewrite -(mu_eq _ (predC (isprefix (of_node base)))) 1:/#.
  by rewrite mu_not duniform_ll 1:&(neq0_wordn) hmu.
qed.

lemma Pr_Internal &m (T : int) (base : node) :
     0 <= T
  => 0 < size base
  => Pr [ InternalORAM.compile(T, base) @ &m :
            exists i, 0 <= i < T /\
                 (K %/ 2 + 1 = nth 0 InternalORAM.logb i
               \/ K %/ 2 + 1 = nth 0 InternalORAM.logw i) ]
  <= 2%r ^ (- (K %/ 2))%r * T%r.
proof.
move => *.
apply (RealOrder.ler_trans
         (Pr [SamplingLogger.play(T, 2%r ^ (-(size base))%r) @ &m :
                exists i1 i2, 0 <= i1 < i2 <= T /\
                  count idfun (interval res.`1 i1 i2) = K %/ 2 + 1 /\
                  count idfun (interval res.`2 i1 (i2 - 1)) = 0 ])); last first.
+ rewrite mulrC (: - K %/ 2 = - (K %/ 2 + 1) + 1) 1:/# &(Pr_Sampler) //.
  + rewrite (: (- size base)%r = - (size base)%r) 1:/#.
    - by smt(rg_ipow2).
    - by smt(gt0_K).
byequiv (_: arg{1} = (T, base)
         /\ arg{2} = (T, 2%r ^ (-(size base))%r) ==> _) => //.
proc; sp; inline.
while (={i}
    /\ T{!1} = T /\ T{!2} = T
    /\ base{!1} = base
    /\ 0 <= i{1} <= T
    /\ (p{2} = 2%r ^ (-(size base))%r)
    /\ size lb{2} = i{1}
    /\ size lw{2} = i{1}
    /\ size InternalORAM.logb{1} = i{1}
    /\ size InternalORAM.logw{1} = i{1}

       (* inv1: exists, count [i1..] = counter *)
    /\ (exists i1, 0 <= i1 <= i{1}
               /\ !has idfun (drop i1 lw{2})
               /\ count idfun (drop i1 lb{2}) = InternalORAM.c{1})
       (* inv2: overflow => count = K %/ 2 + 1 *)
    /\ ((exists (i0 : int),
             0 <= i0 < i{1} /\
            (K %/ 2 + 1 = nth 0 InternalORAM.logb{1} i0 \/
             K %/ 2 + 1 = nth 0 InternalORAM.logw{1} i0))
          => exists (i1 i2 : int),
                 0 <= i1 < i2 <= i{1}
              /\ count idfun (interval lb{2} i1 i2) = K %/ 2 + 1
              /\ count idfun (interval lw{2} i1 (i2 - 1)) = 0)
).
+ seq 3 1 : (#pre /\ base0{1} = base /\ ={b}).
  + sp; rndsem*{1} 0; auto => /> &1 &2 *.
    rewrite (: dmap _ _ = dbiased (ipow2 (size base))) 1:distr_path_then_prefixE //.
    by rewrite (: (- size base)%r = - (size base)%r) /#.
  sp; wp 2 1; rndsem*{1} 0.

  (* we can also use new coupling rules as follows. *)
  (* wp; coupling{1} (fun (path : path) => (isprefix base (node_of_path path))). *)
  (* wp; coupling{1} (fun (path : path) => (isprefix base (node_of_path path))). *)

  auto => /> &1 &2 lb_R logb_L 7? i1 ??? Hinv2 ?.
  rewrite (: dmap _ _ = dbiased (ipow2 (size base))) 1:distr_path_then_prefixE 1,2:/#.
  rewrite (:(- size base{!1})%r = -(size base)%r) 1:/# /=.
  move => w ?; split => // _; do! split.
  + by smt().
  + by smt().
  + by rewrite size_cat size1 /#.
  + by rewrite size_cat size1 /#.
  + by rewrite size_cat size1 /#.
  + by rewrite size_cat size1 /#.
  + case w => ?.
    + exists (size lw{2} + 1).
      by rewrite !drop_oversize 1,2:#smt:(size_cat size1) /#.
    + exists i1.
      by rewrite !drop_catl 1,2:/# has_cat count_cat {2 4}/idfun /= /#.
  + move => i0' ??.
    case (i0' < size lb_R) => ?.
    + rewrite !nth_cat 2!(: i0' < _) 1,2:/# /= => ?.
      have /Hinv2 /> : (exists (i0 : int),
                           0 <= i0 < size lb_R /\
                          (K %/ 2 + 1 = nth 0 logb_L i0 \/
                           K %/ 2 + 1 = nth 0 InternalORAM.logw{1} i0)).
      + by exists i0' => /#.
      by move => i1' i2' *; exists i1' i2'; rewrite !interval_catR /#.
    + have Hi0': i0' = size lb_R by smt().
      rewrite !nth_cat 2!(: ! i0' < _) 1,2,3:/# /= 2!(: i0' - _ = 0) 1,2,3:/# /=.
      move => ?.
      have ?: K %/ 2 + 1 = count idfun (drop i1 lb_R) + b2i b{2} by smt(gt0_K).
      exists i1 (size lb_R + 1).
      rewrite count_interval_with1 1,2:/# interval_catR 1:/#.
      by rewrite interval_oversize 1:/# -count_eq0 /#.
+ auto => />; do! split.
  (* pre => inv *)
  + by exists 0.
  + by smt(gt0_K).
  (* inv => post *)
  + move => logb logw lb lw 7? i1 3? H i0 ???.
    rewrite (: T = size lb) 1:/# &H.
    by exists i0 => /#.
qed.

