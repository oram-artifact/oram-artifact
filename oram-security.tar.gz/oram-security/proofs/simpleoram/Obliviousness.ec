require import AllCore List FSet FMap IntDiv RealExp.
require import Distr DList DBool.

require import StdOrder.
(*---*) import RealOrder.

require import StdBigop.
(*---*) import Bigreal BRM.

require import ORAM.
require import SimpleORAM.
(*---*) import UniPath.

require import Aux.
(*---*) import ListUtils DistrUtils FMapUtils.

module SecureORAM = {
  var leakages : (sleakage * sleakage) list

  proc get_leakages() : (sleakage * sleakage) list = { return leakages; }

  proc step(posmap : vars -> path option, v : vars) = {
    var p,pf,ppb,pfl : path;

    (* fetch *)
    p <$ dunipath;
    pf <- odflt p (posmap v);
    
    (* putback *)
    ppb <$ dunipath;
    posmap <- posmap.[v <- Some ppb];

    (* flush *)
    pfl <$ dunipath;
    
    leakages <- (pf,pfl) :: leakages;

    return posmap; 
  }

  proc compile(p : prog) = {
    var posmap : vars -> path option;
    var i : int;

    SecureORAM.leakages <- [];
    posmap <- fun _ => None;
    
    i <- 0;
    while (i < size p) {
      posmap <@ step(posmap, varV p.[i]);
      i <- i + 1;
    }
  }
}.

module TapeSecureORAM (RO : RO) = {
  var leakages : (sleakage * sleakage) list

  proc get_leakages() : (sleakage * sleakage) list = { return leakages; }

  proc step(posmap : vars -> path option, v : vars) = {
    var p,pf,ppb,pfl : path;

    (* fetch *)
    p <@ TapeSampler(RO).sample();
    pf <- odflt p (posmap v);

    (* putback *)
    ppb <@ TapeSampler(RO).sample();
    posmap <- posmap.[v <- Some ppb];

    (* flush *)
    pfl <@ TapeSampler(RO).sample();

    leakages <- (pf,pfl) :: leakages;

    return posmap;
  }

  proc compile(p : prog) = {
    var posmap : vars -> path option;
    var i : int;

    leakages <- [];
    posmap <- fun _ => None;

    i <- 0;
    while (i < size p) {
      posmap <@ step(posmap, varV p.[i]);
      i <- i + 1;
    }
  }

  proc distinguish(p : prog) = {
    TapeSampler(RO).init((size p) * 3);

    compile(p);
  }
}.

equiv TapeSecureORAM_SecureORAM :
  TapeSecureORAM(LRO).distinguish ~ SecureORAM.compile:
    ={arg} ==> TapeSecureORAM.leakages{1} = SecureORAM.leakages{2}.
proof.
proc; inline.
while (={posmap}
    /\ i0{1} = i{2}
    /\ p0{1} = p{2}
    /\ TapeSecureORAM.leakages{1} = SecureORAM.leakages{2}
    /\ (forall j, TapeSampler.counter{1} <= j => j \notin RO.m{1})
    /\ 0 <= i{2} <= size p{2}
).
(* the three steps are almost the same, better to figure out a way to abstract them. *)
+ seq 9 4 : (={posmap0, pf, v}
          /\ i0{1} = i{2}
          /\ p0{1} = p{2}
          /\ TapeSecureORAM.leakages{1} = SecureORAM.leakages{2}
          /\ (forall j, TapeSampler.counter{1} <= j => j \notin RO.m{1})
          /\ 0 <= i{2} < size p{2}
  ).
  + wp; rnd; auto => /> &1 &2 4? path *; do split.
    + move => ?; do split.
      + by rewrite FMap.get_setE.
      + by move => j ?; rewrite FMap.mem_set /#.
    + by smt().
  seq 7 2 : (={posmap0, pf}
          /\ i0{1} = i{2}
          /\ p0{1} = p{2}
          /\ TapeSecureORAM.leakages{1} = SecureORAM.leakages{2}
          /\ (forall j, TapeSampler.counter{1} <= j => j \notin RO.m{1})
          /\ 0 <= i{2} < size p{2}
  ).
  + wp; rnd; auto => /> &1 &2 ??? path ?; do split.
    + move => *; do split.
      + by rewrite FMap.get_setE.
      + by move => j ?; rewrite FMap.mem_set /#.
    + by smt().
  seq 6 1 : (={posmap0, pf, pfl}
          /\ i0{1} = i{2}
          /\ p0{1} = p{2}
          /\ TapeSecureORAM.leakages{1} = SecureORAM.leakages{2}
          /\ (forall j, TapeSampler.counter{1} <= j => j \notin RO.m{1})
          /\ 0 <= i{2} < size p{2}
  ).
  + wp; rnd; auto => /> &1 &2 *; do split.
    + move => *; do split.
      + by rewrite get_setE.
      + by move => j ?; rewrite mem_set /#.
    + by smt().
  by auto => /> /#.
auto => />.
while{1} (0 <= i{1} <= n{1}
      /\ RO.m{1} = empty
) (n{1} - i{1}).
+ move => _ z.
  by auto => /> /#.
auto => /> &hr *; split.
+ by smt(List.size_ge0).
+ move => i; do split.
  + by move => * /#.
  + by move => *; smt(mem_empty List.size_ge0).
qed.

module TapeORAM = {
  var tape : path list
  var leakages : (sleakage * sleakage) list

  proc get_leakages() : (sleakage * sleakage) list = { return leakages; }

  proc step(posmap : vars -> path option, v : vars) = {
    var p,pf,ppb,pfl : path;

    (* fetch *)
    p <- head witness tape;
    tape <- behead tape;
    pf <- odflt p (posmap v);

    (* putback *)
    ppb <- head witness tape;
    tape <- behead tape;
    posmap <- posmap.[v <- Some ppb];

    (* flush *)
    pfl <- head witness tape;
    tape <- behead tape;

    leakages <- (pf,pfl) :: leakages;

    return posmap;
  }

  proc compile(p : prog) = {
    var posmap : vars -> path option;
    var i : int;

    leakages <- [];
    posmap <- fun _ => None;

    i <- 0;
    while (i < size p) {
      posmap <@ step(posmap, varV p.[i]);
      i <- i + 1;
    }
  }

  proc distinguish(p : prog) = {
    tape <$ dlist dunipath (size p * 3);
    compile(p);
  }
}.

equiv TapeORAM_TapeSecureORAM :
  TapeSecureORAM(RO).distinguish ~ TapeORAM.distinguish:
    ={arg}
      ==>
    TapeSecureORAM.leakages{1} = TapeORAM.leakages{2}.
proof.
proc.
seq 1 1 : (={p}
        /\ (forall j,
               (0 <= j < size TapeORAM.tape{2}
                  => RO.m{1}.[j] = Some TapeORAM.tape{2}.[j])
            /\ (size TapeORAM.tape{2} <= j
                  => RO.m{1}.[j] = None))
        /\ TapeSampler.counter{1} = 0
        /\ size TapeORAM.tape{2} = size p{2} * 3
).
+ inline.
  transitivity{1}
    {
      n <- size p * 3;
      i <- 0;
      TapeORAM.tape <$ dlist dunipath i;
      while (i < n) {
        r <$ dunipath;
        TapeORAM.tape <- TapeORAM.tape ++ [r];
        i <- i + 1;
      }
    }
    (={p} ==> ={p}
           /\ forall (j : int),
                 (0 <= j < size TapeORAM.tape{2}
                    => RO.m{1}.[j] = Some TapeORAM.tape{2}.[j])
              /\ (size TapeORAM.tape{2} <= j
                    => RO.m{1}.[j] = None)
           /\ TapeSampler.counter{1} = 0
           /\ size TapeORAM.tape{2} = size p{2} * 3
    )
    (={p} ==> ={p,TapeORAM.tape})
  .
  + by smt().
  + by smt().
  + while (={i,n,p}
        /\ (forall j,
               (0 <= j < i{1}
                  => RO.m{1}.[j] = Some TapeORAM.tape{2}.[j])
            /\ (size TapeORAM.tape{2} <= j
                  => RO.m{1}.[j] = None)
           )
        /\ 0 <= i{1} <= n{1}
        /\ i{2} = size TapeORAM.tape{2}
        /\ TapeSampler.counter{1} = 0
    ).
    + auto => /> &1 &2 ???? p ?; split; 2: by smt().
      move => ?; do split.
      + move => j *; split.
        + by rewrite nth_cat get_setE /#.
        + by rewrite size_cat get_setE /#.
      + by smt(List.size_ge0).
      + by smt().
      + by rewrite size_cat.
    auto => /> &2 tape.
    rewrite supp_dlist 1:// => [#] -> ?; do split.
    + by move => j; rewrite emptyE /#.
    + by smt(List.size_ge0).
    + by smt().

  sp 2 0.
  outline{2} 1 ~ PathSampler.Sample.sample.
  rewrite equiv [{2} 1 PathSampler.Sample_LoopSnoc_eq].
  inline{2}.

  wp; sp.
  while (={i,p,n}
      /\ TapeORAM.tape{1} = l{2}
      /\ 0 <= i{1} <= n{1}
  ).
  + by auto => /> /#.
  auto => /> &2 tape.
  by rewrite supp_dlist 1:// #smt:(List.size_ge0).

inline.
while (={i,p,p0,posmap}
    /\ TapeSecureORAM.leakages{1} = TapeORAM.leakages{2}
    /\ (forall (j : int),
           (0 <= j < size TapeORAM.tape{2} =>
                RO.m{1}.[TapeSampler.counter{1} + j]
              = Some TapeORAM.tape{2}.[j])
        /\ (size TapeORAM.tape{2} <= j =>
                RO.m{1}.[TapeSampler.counter{1} + j]
              = None))
    /\ TapeSampler.counter{1} = 3 * i{1}
    /\ size TapeORAM.tape{2} = (size p0{2} - i{1}) * 3
    /\ p{1} = p0{1}
).
+ seq 9 5: (={i,p,p0,posmap0,pf,v}
         /\ TapeSecureORAM.leakages{1} = TapeORAM.leakages{2}
         /\ (forall (j : int),
               (0 <= j < size TapeORAM.tape{2} =>
                    RO.m{1}.[TapeSampler.counter{1} + j]
                  = Some TapeORAM.tape{2}.[j])
            /\ (size TapeORAM.tape{2} <= j =>
                    RO.m{1}.[TapeSampler.counter{1} + j]
                  = None))
         /\ TapeSampler.counter{1} = 3 * i{1} + 1
         /\ size TapeORAM.tape{2} = (size p0{2} - i{1}) * 3 - 1
         /\ p{1} = p0{1}
         /\ i{1} < size p0{1}
  ).
  + auto => /> &1 &2 H_eq ?? path ?.
    have ^? -> /= : 3 * i{2} \in RO.m{1}.
    + by rewrite fmapP; exists (TapeORAM.tape{2}.[0]) => /#.
    do split.
    + by smt(oget_some nth0_head).
    + move => j.
      rewrite size_behead.
      have -> /= : TapeORAM.tape{2} <> [] by smt().
      split.
      + by move => ??; rewrite nth_behead 1:// /#.
      + by move => ?; have /# := H_eq (1 + j).
    + by rewrite size_behead /#.

  seq 7 3 : (={i,p,p0,posmap0,pf}
          /\ TapeSecureORAM.leakages{1} = TapeORAM.leakages{2}
          /\ (forall (j : int),
                (0 <= j < size TapeORAM.tape{2} =>
                      RO.m{1}.[TapeSampler.counter{1} + j]
                    = Some TapeORAM.tape{2}.[j])
              /\ (size TapeORAM.tape{2} <= j =>
                      RO.m{1}.[TapeSampler.counter{1} + j]
                    = None))
          /\ TapeSampler.counter{1} = 3 * i{1} + 2
          /\ size TapeORAM.tape{2} = (size p0{2} - i{1}) * 3 - 2
          /\ p{1} = p0{1}
          /\ i{1} < size p0{1}
  ).
  + auto => /> &1 &2 H_eq ?? path ?.
    have ^? -> /= : 3 * i{2} + 1 \in RO.m{1}.
    + by rewrite fmapP; exists (TapeORAM.tape{2}.[0]) => /#.
    do split.
    + by smt(nth0_head).
    + move => j.
      rewrite size_behead.
      have -> /= : TapeORAM.tape{2} <> [] by smt().
      split.
      + by move => ??; rewrite nth_behead 1:// /#.
      + by move => ?; have /# := H_eq (1 + j).
    + by rewrite size_behead /#.

  auto => /> &1 &2 H_eq ?? path ?.
  have ^? -> /= : 3 * i{2} + 2 \in RO.m{1}.
  + by rewrite fmapP; exists (TapeORAM.tape{2}.[0]) => /#.
  do split.
  + by smt(nth0_head).
  + move => j.
    rewrite size_behead.
    have -> /= : TapeORAM.tape{2} <> [] by smt().
    split.
    + by move => ??; rewrite nth_behead 1:// /#.
    + by move => ?; have /# := H_eq (1 + j).
  + by smt().
  + by rewrite size_behead /#.
by auto => />.
qed.

(*
We wanna show that
  "when the random tape is in a uniform distribution,
   the partial permutation of the random tape is also in a uniform distribution".

Let's try to write down a scaffold pen-and-paper proof first.
The partial permutation can be regarded of a composition of two functions,
  a filter and an injectivity.
Let's deal with this two parts.

First, as the random tape is an (3 * |p|)-product of uniform distributions,
          and the filter selects (2 * |p|) of the (3 * |p|) product,
       we know that after the filtering, we get an m-product of uniform distributions.
Second, we're going to show that for any two leakages l1 l2 of length 2 * |p|
        the mass probability of l1 is equal to the mass probability of l2.
  This is true because for any mass probability at leakage l,
    we can go back to the inverse of l.
  Note: I feel that a stronger claim (rather than uniformity) should be easier to prove for the second step:
    a list distribution as a distribution product, after a permutation, is the same list distribution.
*)

op index_partial_perm (p : prog) =
  fun (i : int) =>
    let j = size p - i - 1 in
      (if 0 <= last_index p j then
         (last_index p j) * 3 + 1
       else
         j * 3,
      j * 3 + 2).

op tape2leakages (p : prog) (tape : path list) : (sleakage * sleakage) list =
  map
    (fun i => (tape.[(index_partial_perm p i).`1],
               tape.[(index_partial_perm p i).`2]))
    (range 0 (size p)).

(* -------------------------------------------------------------------- *)
lemma ge0_index_partial_permL (p : prog) (i : int) :
  0 <= i < size p => 0 <= (index_partial_perm p i).`1.
proof. smt(size_ge0). qed.

(* -------------------------------------------------------------------- *)
lemma ge0_index_partial_permR (p : prog) (i : int) :
  0 <= i < size p => 0 <= (index_partial_perm p i).`2.
proof. smt(size_ge0). qed.

(* -------------------------------------------------------------------- *)
lemma lt_index_partial_permL (p : prog) (i : int) :
  0 <= i < size p => (index_partial_perm p i).`1 < 3 * size p.
proof.
move=> rgi; rewrite /index_partial_perm /=.
by case: (0 <= _) => /=; [smt(last_index_rng) | smt(size_ge0)].
qed.

(* -------------------------------------------------------------------- *)
lemma lt_index_partial_permR (p : prog) (i : int) :
  0 <= i < size p => (index_partial_perm p i).`2 < 3 * size p.
proof. smt(size_ge0). qed.

(* -------------------------------------------------------------------- *)
require import BitEncoding.
(*---*) import BitChunking.

(* -------------------------------------------------------------------- *)
op cp (x : path list) =
  map (fun xs => (nth witness xs 0, nth witness xs 1)) (chunk 2 x).

(* -------------------------------------------------------------------- *)
lemma chunk_nil ['a] (n : int) : chunk<:'a> n [] = [].
proof. by rewrite /chunk /= mkseq0. qed.

hint simplify chunk_nil.

(* -------------------------------------------------------------------- *)
lemma chunk_exact ['a] (xs : 'a list) : xs <> [] => chunk (size xs) xs = [xs].
proof.
rewrite /chunk divzz; case: (xs = []) => //.
rewrite size_eq0 => -> _; rewrite b2i1 /= mkseq1; congr=> /=.
by rewrite drop0 take_oversize.
qed.

(* -------------------------------------------------------------------- *)
lemma cp_nil : cp [] = [].
proof. done. qed.

hint simplify cp_nil.

(* -------------------------------------------------------------------- *)
lemma cp_seq2 (x y : path) : cp [x; y] = [(x, y)].
proof. by rewrite /cp; rewrite (chunk_exact [_; _]). qed.

hint simplify cp_seq2.

(* -------------------------------------------------------------------- *)
lemma cp_cat (xs1 xs2 : _ list) : 2 %| size xs1 =>
  cp (xs1 ++ xs2) = cp xs1 ++ cp xs2.
proof. by move=> hdvd; rewrite {1}/cp chunk_cat // map_cat. qed.

(* -------------------------------------------------------------------- *)
lemma mkseq2 ['a] (f : int -> 'a) : mkseq f 2 = [f 0; f 1].
proof. by rewrite (mkseq_add _ 1 1) // !mkseq1. qed.

(* -------------------------------------------------------------------- *)
op injective (f : int -> int * int) =
     (forall i, (f i).`1 <> (f i).`2)
  /\ (forall i1 i2, i1 <> i2 =>
          ((f i1).`1 <> (f i2).`1
        /\ (f i1).`2 <> (f i2).`2
        /\ (f i1).`1 <> (f i2).`2)
     ).

(* -------------------------------------------------------------------- *)
lemma index_partial_perm_injective (p : prog) :
  injective (index_partial_perm p).
proof.
move => @/index_partial_perm @/injective @/last_index /=.
split.
+ by move => i; case : (0 <= _) => /#.
+ move => i1 i2 ?; do split.
  + case _ : (0 <= _) => H1 /=.
    + case _ : (0 <= _) => H2 /=.
      + have ? : 0 < size p - i1 - 1 by smt(size_range rfind_rng).
        have ? : 0 < size p - i2 - 1 by smt(size_range rfind_rng).

        case (varV p.[size p - i1 - 1] = varV p.[size p - i2 - 1]) => Hv.
        + rewrite Hv.
          pose index1 := rfind _ _.
          pose index2 := rfind _ _.
          case (size p - i1 - 1 < size p - i2 - 1).
          + move => ?.
            have ? : index1 < size p - i1 - 1 by smt(size_range rfind_rng).
            have ? : size p - i1 - 1 <= index2.
            + by rewrite /index2 &(rfind_ge) 1:#smt:(size_range) /= nth_range /#.
            by smt().
          + move => ?.
            have ? : size p - i2 - 1 < size p - i1 - 1 by smt().
            have ? : index2 < size p - i2 - 1 by smt(size_range rfind_rng).
            have ? : size p - i2 - 1 <= index1.
            + by rewrite /index1 &(rfind_ge) 1:#smt:(size_range) /= nth_range /#.
            by smt().
        + pose index1 := rfind _ _.
          pose index2 := rfind _ _.
          suff : index1 <> index2 by smt().
          apply negP => Hcontra.
          have : 0 <= index1 by smt().
          move => /rfindP /=.
          rewrite -/index1 nth_range /index1.
          + split.
            + by smt().
            + by move => ?; smt(rfind_rng size_range).
          rewrite -/index1.
          have : 0 <= index2 by smt().
          move => /rfindP /=.
          rewrite -/index2 nth_range /index2.
          + split.
            + by smt().
            + by move => ?; smt(rfind_rng size_range).
          by rewrite -/index2 /#.
      + by smt().
    + by case _ : (0 <= _) => /= /#.
  + by smt().
  + by smt().
qed.

(* -------------------------------------------------------------------- *)
lemma dmap_list2leakages_eq_dlist (p : prog) :
    dmap (dlist dunipath (size p * 3)) (tape2leakages p)
  = dlist (dunipath `*` dunipath) (size p).
proof.
have ->:
    dlist (dunipath `*` dunipath) (size p)
  = dmap (dlist dunipath (2 * (size p))) cp.
- elim: p => //=; first by rewrite !dlist0 //= dmap_dunit.
  move=> x ih; rewrite mulrDr /= [1+_]addrC [2+_]addrC eq_sym.
  rewrite dlist_add ~-1:#smt:(size_ge0) dmap_comp /(\o) /=.
  pose F (xs : path list * path list) := cp xs.`1 ++ cp xs.`2.
  rewrite -(eq_dmap_in _ F) /F.
  - case=> xs1 xs2 /supp_dprod /= [#].
    rewrite supp_dlist ~-1:#smt:(size_ge0) => [#] ? _ _.
    by rewrite cp_cat 1:/#.
  rewrite (dmap_dprod_comp _ _ cp cp (++)) dmap_dprodE /= -ih.
  rewrite dlistSr //= dmap_dprodE /= &(in_eq_dlet) /=.
  move=> xs ?; rewrite dmap_comp /(\o) /=.
  rewrite (dlist_add _ 1 1) // dmap_comp /(\o) dlist1 /= /=.
  rewrite !dmap_dprodE /= dlet_dmap /= &(in_eq_dlet) /=.
  move=> p1 _; rewrite dmap_comp /(\o) /= &(eq_dmap_in).
  by move=> p2 _ /=; rewrite cats1.
pose F (i : int) := if i %% 2 = 0
  then (index_partial_perm p (i %/ 2)).`1
  else (index_partial_perm p (i %/ 2)).`2.
pose G (xs : path list) := mkseq (fun i => nth witness xs (F i)) (2 * (size p)).
have ->:
    dmap (dlist dunipath (size p * 3)) (tape2leakages p)
  = dmap (dmap (dlist dunipath (size p * 3)) G) cp.
- rewrite dmap_comp /(\o) /= &(eq_dmap_in) => xs _.
  rewrite /tape2leakages /G /F /= => {F G}.
  elim: {3 6}p => /= [|i ih]; first by rewrite range_geq //= mkseq0.
  rewrite addrC rangeSr // map_rcons /= ih.
  rewrite mulrDr /= mkseq_add 1:#smt:(size_ge0) //=.
  rewrite mkseq2 /= cp_cat ?size_mkseq 1:/# /=.
  rewrite modzMr /= [2*_]mulzC modzMDl /=.
  by rewrite mulzK // divzMDl //= cats1.
congr; apply: dmap_dlist_partial_perm; 1,2: by smt(size_ge0).
- by apply/dunipath_ll.
- smt(index_partial_perm_injective).
- move=> i rgi; split=> [|ge0_Fi] @/F.
  - smt(ge0_index_partial_permL ge0_index_partial_permR).
  - smt(lt_index_partial_permL lt_index_partial_permR).
qed.

op tape2posmap (p : prog) (i : int) (tape : path list) : vars -> path option =
  fun v =>
    let index =
      rfind
        (fun j => varV p.[j] = v)
        (range 0 i) in
    if 0 <= index then
      Some tape.[index * 3 + 1]
    else
      None.

lemma tapeoram_compile_ll :
  islossless TapeORAM.compile.
proof.
proc.
while (0 <= i <= size p)
      (size p - i).
+ move => z; inline.
  by auto => /> &hr /#.
auto => /> &hr; split.
+ exact List.size_ge0.
+ by smt().
qed.

(* lemma tape2leakages (tape : path list) (p : prog) : *)
(*      size tape = (size p) * 3 *)
(*   => hoare [ TapeORAM.compile : *)
(*                   arg = p /\ TapeORAM.tape = tape *)
(*               ==> TapeORAM.leakages = tape2leakages p tape ]. *)
(* lemma tape2leakages (p : prog) (l : (sleakage * sleakage) list) : *)
(*   hoare [ TapeORAM.compile : *)
(*                  p = arg /\ size TapeORAM.tape = size p * 3 *)
(*               /\ tape2leakages p TapeORAM.tape = l *)
(*           ==> TapeORAM.leakages = l ]. *)
lemma tape2leakages_h (p : prog) (l : (sleakage * sleakage) list) :
  hoare [ TapeORAM.compile :
                  p = arg /\ size TapeORAM.tape = size p * 3
               /\ tape2leakages p TapeORAM.tape = l
           ==> TapeORAM.leakages = l ].
proof.
proc.
inline.
exists* TapeORAM.tape.
elim* => tape.
while (0 <= i <= size p{!hr}
    /\ p{!hr} = p
    /\ posmap = tape2posmap p{!hr} i tape
    /\ TapeORAM.tape = drop (i * 3) tape
    /\ TapeORAM.leakages = tape2leakages (take i p{!hr}) tape
).
+ seq 5 : (0 <= i < size p{!hr}
       /\ p{!hr} = p
       /\ posmap0 = tape2posmap p i tape
       /\ TapeORAM.tape = drop (i * 3 + 1) tape
       /\ TapeORAM.leakages = tape2leakages (take i p) tape
       /\ v{!hr} = varV p.[i]

       /\ pf = let index =
                 rfind
                   (fun j => varV p.[j] = varV p.[i])
                   (range 0 i) in
               if 0 <= index then
                 tape.[index * 3 + 1]
               else
                 tape.[i * 3]
  ).
  + auto => /> &hr ???.
    rewrite /tape2posmap /=.
    pose index := rfind _ _.
    do split.
    + by rewrite behead_drop /#.
    + by rewrite -head_drop /#.

  seq 3 : (#{~TapeORAM.tape}{~posmap0}pre
        /\ TapeORAM.tape = drop (i * 3 + 2) tape
        /\ posmap0 = tape2posmap p (i + 1) tape
  ).
  + auto => /> &hr ??; do split.
    + by rewrite behead_drop /#.
    + rewrite /tape2posmap &(fun_ext) => v @/"_.[_<-_]" /=.
      pose index0 := rfind _ _.
      pose index1 := rfind _ _.
      case (varV p.[i{hr}] = v) => ?.
      + suff : index1 = i{hr} by smt(head_drop).
        rewrite /index1.
        apply (eq_trans _ (size (range 0 (i{hr} + 1)) - 1)).
        + rewrite -rfind_last 1:#smt:(size_range) /=.
          by rewrite last_range /#.
        by rewrite size_range /#.
      + suff : index0 = index1 by smt().
        rewrite /index0 /index1.
        rewrite (range_cat i{hr} 0 (i{hr} + 1)) 1,2:/#.
        by rewrite rfind_catl 1:#smt:(rangeS).

  auto => /> &hr *.
  do split; 1,2,3: by smt(behead_drop).
  rewrite /tape2leakages !size_takel 1,2:/#.
  rewrite (range_cat 1 0 (i{hr} + 1)) // 1:/#.
  rewrite map_cat rangeS map1 /=.
  do split.
  + move => @/index_partial_perm /=.
    pose index0 := rfind _ _.
    pose index1 := last_index _ _.
    suff : index0 = index1 by smt(size_take).
    rewrite /index0 /index1 size_takel 1:/# /=.
    apply rfind_in_eq => j.
    rewrite mem_range => ? /=.
    by rewrite !nth_take 1,2,3,4:/#.
  + rewrite -head_drop 1:/#.
    congr.
    rewrite /index_partial_perm /=.
    by rewrite size_takel /#.
  + apply (eq_from_nth witness).
    + by rewrite !size_map !size_range /#.
    + move => i.
      rewrite size_map size_range => ?.
      rewrite !(nth_map witness) 1,2:size_range //=.
      + rewrite /index_partial_perm /=.
        rewrite !size_takel 1,2:/#.
        rewrite !nth_range 1,2:/# /=.

        pose index0 := last_index _ _.
        pose index1 := last_index _ _.

        suff : index0 = index1 by smt().
        + rewrite /index0 /index1.
          rewrite (: i{!hr} + 1 - (1 + i) - 1 = i{!hr} - i - 1) 1:/#.
          apply rfind_in_eq => j.
          rewrite mem_range => ? /=.
          by rewrite !nth_take /#.

auto => /> &hr *; do split.
+ exact List.size_ge0.
+ by rewrite /tape2posmap range_geq.
+ by rewrite drop0.
+ by rewrite take0 /tape2leakages /= range_geq.
+ by move => m i *; rewrite take_oversize /#.
qed.

section.

lemma Pr_leakages_dist &m (p : prog)
                          (l : (sleakage * sleakage) list)
  :  Pr [ TapeORAM.distinguish(p) @ &m : TapeORAM.leakages = l ]
   = mu1 (dmap (dlist dunipath (size p * 3)) (tape2leakages p)) l.
proof.
byphoare (: p = p{!hr} ==> _) => //.
proc.
+ seq 1 : (tape2leakages p TapeORAM.tape = l)
            (mu1 (dlist (dunipath `*` dunipath) (size p)) l) 1%r
            (1%r - (mu1 (dlist (dunipath `*` dunipath) (size p)) l)) 0%r
          (p = p{!hr} /\ size TapeORAM.tape = size p * 3).
  + auto => /> tape.
    by rewrite supp_dlist 1:#smt:(List.size_ge0) /#.
  + rnd; skip => />.
    by rewrite -dmap_list2leakages_eq_dlist dmap1E /(\o) /pred1.
  + call (_: p = arg
          /\ size TapeORAM.tape = size p * 3
          /\ tape2leakages p TapeORAM.tape = l
         ==> TapeORAM.leakages = l).
    + by conseq tapeoram_compile_ll (tape2leakages_h p l) => />.
    by auto => />.
  + hoare.
    exists* (tape2leakages p TapeORAM.tape).
    elim* => l'.
    call (tape2leakages_h p l').
    by skip => /> /#.
  + (* lossless *)
    by move => &hr ?; rewrite dmap_list2leakages_eq_dlist.
qed.

lemma Pr_leakages_TapeORAM &m (p : prog) (l : (sleakage * sleakage) list) :
    Pr [ TapeORAM.distinguish(p) @ &m : TapeORAM.leakages = l ]
  = if size p = size l then 2%r ^ (- 2 * (size p) * h) else 0%r.
proof.
rewrite (Pr_leakages_dist &m p l) dmap_list2leakages_eq_dlist.
rewrite dlist1E 1:List.size_ge0.
rewrite (eq_bigr _ _ (fun _ => 2%r ^ - 2 * h)).
+ move => pp @/predT /=.
  rewrite (: pp = (pp.`1, pp.`2)) 1:/#.
  rewrite dprod1E !dunipath1E !FinPath.cardE.
  rewrite int2rpow 1,2:#smt:(gt0_h).
  rewrite (: 2 * h = h + h); 1: by ring.
  rewrite -rpowN //= -rpowD 1:// -rpow_int 1://.
  by congr; ring.
rewrite big_const count_predT iter_expr.
+ by smt(expr_gt0).
+ exact List.size_ge0.
rewrite -RField.exprM.
case : (size p = size l) => ? //=.
by congr => /#.
qed.

(* Lift dunipath_ll to the shape expected by FullEager.RO_LRO_D *)
local lemma dunipath_ll_fa : forall (_ : int), is_lossless dunipath.
proof. by move => _; exact dunipath_ll. qed.

(* Specialize RO_LRO_D for TapeSecureORAM as a named lemma so conseq can use it *)
local lemma TapeSecureORAM_RO_LRO :
  equiv [ TapeSecureORAM(RO).distinguish ~ TapeSecureORAM(LRO).distinguish :
    (glob TapeSecureORAM){1} = (glob TapeSecureORAM){2} /\ RO.m{1} = RO.m{2} /\ ={arg} ==>
    ={res} /\ (glob TapeSecureORAM){1} = (glob TapeSecureORAM){2} ].
proof.
have rlo_equiv := FullEager.RO_LRO_D TapeSecureORAM dunipath_ll_fa.
by conseq rlo_equiv => /#.
qed.

(* The leakage distribution of SecureORAM only depends on the program size. *)
lemma Pr_leakages &m (p : prog) (l : (sleakage * sleakage) list) :
    Pr [ SecureORAM.compile(p) @ &m : SecureORAM.leakages = l ]
  = if size p = size l then 2%r ^ (- 2 * (size p) * h) else 0%r.
proof.
(* Step 1: SecureORAM ~ TapeSecureORAM(LRO) *)
have step1 :
    Pr [ SecureORAM.compile(p) @ &m : SecureORAM.leakages = l ]
  = Pr [ TapeSecureORAM(LRO).distinguish(p) @ &m : TapeSecureORAM.leakages = l ].
+ byequiv => //.
  symmetry; by conseq TapeSecureORAM_SecureORAM => /#.
(* Step 2a: TapeSecureORAM(RO) ~ TapeSecureORAM(LRO) via eager/lazy equivalence *)
have step2a :
    Pr [ TapeSecureORAM(RO).distinguish(p) @ &m : TapeSecureORAM.leakages = l ]
  = Pr [ TapeSecureORAM(LRO).distinguish(p) @ &m : TapeSecureORAM.leakages = l ].
+ by byequiv TapeSecureORAM_RO_LRO => //.
(* Step 2b: TapeSecureORAM(RO) ~ TapeORAM *)
have step2b :
    Pr [ TapeSecureORAM(RO).distinguish(p) @ &m : TapeSecureORAM.leakages = l ]
  = Pr [ TapeORAM.distinguish(p) @ &m : TapeORAM.leakages = l ].
+ byequiv => //.
  by conseq TapeORAM_TapeSecureORAM => /#.
by rewrite step1 -step2a step2b Pr_leakages_TapeORAM.
qed.

module type ADist_t = {
   proc find() : prog * prog
   proc dist(l : (sleakage * sleakage) list) : bool
}.

module type AORAM_t = {
  proc compile(p : prog) : unit
  proc get_leakages() : (sleakage * sleakage) list
}.

module AORAM_IND(O : AORAM_t, D : ADist_t) = {
   proc main(b : bool, max_size : int) : bool = {
      var ps,l,b';
      b' <- false;
      ps <@ D.find();
      if (size ps.`1 = size ps.`2 /\ size ps.`1 <= max_size) {
         O.compile(if b then ps.`1 else ps.`2);
         l <@ O.get_leakages();
         b' <@ D.dist(l);
      }
      return b';
   }
}.

declare module A <: ADist_t
  { -SecureORAM, -TapeSecureORAM, -TapeORAM, -RO, -LRO }.

declare axiom A_ll : islossless A.dist.

(* The leakage distribution of SecureORAM depends only on program size,
   so no adversary can distinguish two programs of the same length. *)
lemma abstract_security &m max_size:
   `| Pr [ AORAM_IND(SecureORAM,A).main(true,max_size) @ &m : res  ] -
            Pr [ AORAM_IND(SecureORAM,A).main(false,max_size) @ &m : res  ] | = 0%r.
proof.
have -> : Pr [ AORAM_IND(SecureORAM,A).main(true,max_size) @ &m  : res ]
        = Pr [ AORAM_IND(SecureORAM,A).main(false,max_size) @ &m : res ]; last by auto.
byequiv => //.
proc.
seq 2 2 : (={b',glob A,ps,max_size}).
+ by call(:true); auto.
if; 1,3: by auto.
seq 2 2: (={b',glob A,l}).
+ inline{1} 2; inline{2} 2; wp.
  call (: size arg{1} = size arg{2} ==> ={SecureORAM.leakages}).
  + bypr (SecureORAM.leakages){1} (SecureORAM.leakages){2} => //.
    move => &1 &2 l *.
    rewrite !Pr_leakages /#.
  + by auto => /> /#.
by call(:true); auto.
qed.

end section.
