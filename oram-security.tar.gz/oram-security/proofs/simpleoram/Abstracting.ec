require import AllCore Bool List IntDiv FMap.
require import Distr DList.

require import ORAM.
require import SimpleORAM.
(*---*) import UniPath.

require import Internal Leaf RAM.

require import Aux.
(*---*) import ListUtils.

(* ====== correct abstracting ====== *)

op oram_eq_mem_at (o : oram) (mem : (vars, value) fmap) (v : vars) =
      v \in o /\ v \in mem
  /\ (oget (o.[v])).`value = oget (mem.[v]).

op oram_eq_mem_up_to_prog (o : oram) (mem : (vars, value) fmap) (p : prog) =
  forall inst, inst \in p => isWt inst =>
    let v = varV inst in
      oram_eq_mem_at o mem v.

op oram_eq_up_to_var (o1 o2 : oram) (v : vars) =
  forall v', v' <> v => omap value o1.[v'] = omap value o2.[v'].

op mem_eq_up_to_var (m1 m2 : (vars, value) fmap) (v : vars) =
  forall v', v' <> v => m1.[v'] = m2.[v'].

lemma equiv_correct_step (o : oram) (mem : (vars, value) fmap) (inst : inst) :
    equiv[ SimpleORAM.readwrite ~ RAM.step :
                 arg{1} = (o, inst)
              /\ arg{2} = inst
              /\ RAM.mem{2} = mem
              /\ (isRd inst => oram_eq_mem_at o mem (varV inst))
             ==>
                 oram_eq_mem_at res{1}.`1 RAM.mem{2} (varV inst)
              /\ res{1}.`2 = res{2}

                 (* cells are untouched except v on oram tree and memory *)
              /\ oram_eq_up_to_var o res{1}.`1 (varV inst)
              /\ mem_eq_up_to_var mem RAM.mem{2} (varV inst)
         ].
proof.
pose v := varV inst.

transitivity DeterministicSimpleORAM.readwrite
  (* oram = doram *)
  (    arg{1} = (o, inst) /\ arg{2} = (o, inst)
    /\ ={SimpleORAM.leakages, SimpleORAM.os}
     ==>
       ={res,SimpleORAM.leakages,SimpleORAM.os})

  (* same pre/post-conditions *)
  (    arg{1} = (o, inst)
    /\ arg{2} = inst
    /\ RAM.mem{2} = mem
    /\ (isRd inst => oram_eq_mem_at o mem v)
   ==>
       oram_eq_mem_at res{1}.`1 RAM.mem{2} v
    /\ res{1}.`2 = res{2}
    /\ oram_eq_up_to_var o res{1}.`1 v
    /\ mem_eq_up_to_var mem RAM.mem{2} v).
+ by auto => /> /#.
+ by auto.
+ exact (simpleoram_eq_dsimpleoram_step o inst).

proc.
wp 8 1.
seq 7 1 : (oram_eq_mem_at oram{1} RAM.mem{2} v
        /\ oram_eq_up_to_var oram{1} o v
        /\ mem_eq_up_to_var RAM.mem{2} mem v
        /\ val{1} = val{2}
).
+ match{2}.
  + wp; rnd{1}; wp.
    ecall{1} (putback_putback oram{1} (varV inst{!1}) val{1} path{1}).
    rnd{1}; wp.
    ecall{1} (fetch_fetch oram{1} (varV inst{!1})).
    auto => |> &2 ?? res_L 4? res_L' Hputback *.
    have ^? Hv : v = v{!2} by smt().
    do split.
    + by rewrite Hputback /putback mem_set /#.
    + by smt().
    + by rewrite Hputback /putback Hv get_set_sameE oget_some /= /#.
    + rewrite /oram_eq_up_to_var => v'.
      rewrite Hputback /putback get_setE Hv => ^? -> /=.
      by smt(remE).
    + by smt().
  + rnd{1}; wp.
    ecall{1} (putback_putback oram{1} (varV inst{!1}) val{1} path{1}).
    rnd{1}; wp.
    ecall{1} (fetch_fetch oram{1} (varV inst{!1})).
    auto => |> &2 ? res_L HL 3? res_L' @/putback Hputback *.
    have ^Hv <- : v = t{2}.`1 by smt().
    do split.
    + by rewrite Hputback mem_set /#.
    + by rewrite mem_set.
    + by rewrite Hputback /= Hv !get_set_sameE !oget_some.
    + rewrite /oram_eq_up_to_var => v'.
      rewrite Hputback Hv get_setE => ^? -> /=.
      by smt(remE).
    + rewrite /mem_eq_up_to_var => v'.
      by rewrite get_setE => ^? ->.
(* flush *)
ecall{1} (flush_flush oram{1} path{1}).
auto => |> &1 &2 *.

suff : forall v, omap value (flush oram{1} path{1}).[v] = omap value oram{1}.[v] by smt().
move => v' @/flush.
case (v' \in oram{1}) => Ho.
+ have := Ho.
  rewrite domE -some_not_none.
  elim => vi Hvi.
  rewrite Hvi /= omap_some.
  + by rewrite -domE mem_map.
  rewrite oget_map //= !Hvi /=.
  by case : (of_depth _ <= _).
+ have := Ho.
  rewrite domE /= => -> /=.
  by rewrite none_omap -domNE mem_map.
qed.

lemma equiv_correct_compile (p : prog) :
  well_formed_prog p =>
    equiv[ SimpleORAM.compile ~ RAM.compile :
                 arg{1} = p
              /\ arg{2} = p
             ==> res{1} = res{2}
         ].
proof.
move => @/well_formed_prog Hprog.
proc.
sp.
while (={i}
   /\ 0 <= i{1} <= size p
   /\ p{!1} = p
   /\ prog{2} = p
   /\ vs{1} = results{2}

      (* main invariant *)
   /\ oram_eq_mem_up_to_prog o{1} RAM.mem{2} (take i{1} p)
).
+ seq 1 1 : (#pre
          /\ oram_eq_mem_at o{1} RAM.mem{2} (varV prog{2}.[i{2}])
          /\ val{1} = result{2}
  ).
  ecall (equiv_correct_step o{1} RAM.mem{2} prog.[i]{2}).
  + auto => /> &1 &2 2? Heq *; do split.
    + move => ?.
      pose v := varV p.[i{2}].
      have := Hprog i{2} v.
      have -> /=: 0 <= i{2} < size p /\ isRd p.[i{2}] /\ varV p.[i{2}] = v by smt().
      elim => j [#] *.
      rewrite /oram_eq_mem_up_to_prog in Heq.
      have := Heq p.[j] _ _ => //=.
      + rewrite (nthP witness).
        exists j.
        by rewrite size_take 1:/# (nth_take witness) /#.
      by smt().
    + move => ? result_L mem_R 5? inst 2? v *.
      by case (v = varV p.[i{2}]) => /#.
  auto => &1 &2 |> *; do split.
  + by smt().
  + by smt().
  + rewrite /oram_eq_mem_up_to_prog => inst Hi1.
    case (inst \in take i{2} p{!1}) => Hi.
    + by smt().
    + suff: inst = p{!1}.[i{2}] by smt().
      rewrite (nthP witness) in Hi1.
      rewrite (nthPn witness) in Hi.
      elim Hi1 => j.
      rewrite size_take 1:/# => [#] ?? H.
      case (j < i{2}) => ?.
      + move : H.
        rewrite (: (take (i{2} + 1) p{!1}).[j] = (take i{2} p{!1}).[j]) 1:#smt:(nth_take).
        by smt(size_take).
      + by smt(nth_take).
auto => />; do split.
+ exact List.size_ge0.
+ by rewrite take0.
qed.

(* ====== internal abstracting ====== *)


abbrev spc (o : oram) (n : node) (b : bool) : int =
  sub_prefix_count o n b.

(* ----- auxiliary: node_is_on_path = isprefix for paths ----- *)
lemma nop_eq_isprefix (base : node) (p : path) :
  node_is_on_path base p = isprefix base (node_of_path p).
proof.
rewrite /node_is_on_path /ORAM.isprefix /node_of_path.
by rewrite to_nodedK 1:#smt:(of_pathP).
qed.

(* ----- auxiliary: spc after rem ----- *)
lemma spc_rem (o : oram) (v : vars) (n : node) (b : bool) :
  spc (rem o v) n b <= spc o n b.
proof.
apply (count_le _ _ FinVars.enum) => v' /=.
by rewrite mem_rem remE => />.
qed.

(* ----- auxiliary: spc after putback (v not in o) ----- *)
lemma spc_putback (o : oram) (v : vars) (p : path) (vl : value) (n : node) (b : bool) :
  size n < h =>
  v \notin o =>
  spc (o.[v <- {| path = p; depth = to_depthd 0; value = vl |}]) n b
    = spc o n b + b2i (node_is_on_path (oget (child n b)) p).
proof.
move => Hszn Hnotin @/sub_prefix_count.
pose P_new := (fun (v0 : vars) =>
     (v0 \in o.[v <- {| path = p; depth = to_depthd 0; value = vl |}]) /\
     let varinfo =
       oget o.[v <- {| path = p; depth = to_depthd 0; value = vl |}].[v0] in
     node_is_on_path (oget (child n b)) varinfo.`path /\
     idepth varinfo <= size n).
pose P_old := (fun (v0 : vars) =>
     (v0 \in o) /\
     let varinfo = oget o.[v0] in
     node_is_on_path (oget (child n b)) varinfo.`path /\
     idepth varinfo <= size n).
rewrite (countID P_new (pred1 v)).
have ->: count (predI P_new (pred1 v)) FinVars.enum
       = b2i (node_is_on_path (oget (child n b)) p).
+ have ->: count (predI P_new (pred1 v)) FinVars.enum = b2i (P_new v).
  - rewrite /predI /pred1.
    rewrite (eq_count _ (fun v0 => P_new v0 /\ v0 = v)) 1:/# .
    case (P_new v) => Hpnv.
    * rewrite (eq_count _ (pred1 v)) .
      + by move => v0 /=; case (v0 = v) => [->> | ] /#.
      by rewrite count_uniq_mem 1:FinVars.enum_uniq FinVars.enumP.
    * by rewrite (eq_count _ pred0) //= 1:/# count_pred0.
  rewrite /P_new /= mem_set /= get_set_sameE /=.
  suff ->: idepth {| path = p; depth = to_depthd 0; value = vl |} <= size n by done.
  have ->: idepth {| path = p; depth = to_depthd 0; value = vl |} = 0.
  + by rewrite /idepth /= to_depthdK #smt:(gt0_h).
  smt(List.size_ge0).
have ->: count (predI P_new (predC (pred1 v))) FinVars.enum
       = count P_old FinVars.enum.
+ apply eq_count => v0 /=.
  rewrite /P_new /P_old /predI /predC /pred1 /=.
  case (v0 = v) => [->> | Hneq] /=.
  - by rewrite (: v \notin o) 1:Hnotin.
  - by rewrite mem_set /= get_setE /= Hneq.
by ring.
qed.

(* ----- auxiliary: spc after flush (general) ----- *)
lemma spc_flush_le (o : oram) (p : path) (n : node) (b : bool) :
  spc (flush o p) n b <= spc o n b.
proof.
rewrite /sub_prefix_count &(count_le _ _ FinVars.enum) => v /=.
rewrite /flush mem_map => /> Hv.
rewrite oget_map 1:#smt:(domE) /=.
case (of_depth (oget o.[v]).`depth <= size (cprefix p (oget o.[v]).`path)) => Hcase /=.
+ move => Hnop Hd; do split => //.
  rewrite /idepth /depth_of_node in Hd.
  by rewrite /idepth; smt(to_depthdK rng_size_cprefix).
+ by move => /#.
qed.

(* ----- auxiliary: spc after flush through base = 0 ----- *)
lemma spc_flush_through (o : oram) (p : path) (n : node) (b : bool) :
  size n < h =>
  node_is_on_path (oget (child n b)) p =>
  spc (flush o p) n b = 0.
proof.
move => Hszn Hnop @/sub_prefix_count.
rewrite (eq_count _ pred0) 2:count_pred0 // => v /=.
rewrite /flush mem_map.
case (v \in o) => [Hv | Hv]; last by smt(domE).
rewrite oget_map 1:#smt:(domE) /=.
pose vi := oget o.[v].
pose base := oget (child n b).
(* In both cases: either depth increases beyond size n, or nop fails *)
case (node_is_on_path base vi.`path) => Hnop_v.
+ (* v's path also goes through base *)
  have Hcp: size base <= size (cprefix p vi.`path).
  - apply isprefix_size.
    have := common_prefix base p vi.`path.
    rewrite /node_is_on_path in Hnop.
    rewrite /node_is_on_path in Hnop_v.
    by smt().
  have Hbase_sz: size n + 1 <= size (cprefix p vi.`path).
  - have Hpfx : ORAM.isprefix base (cprefix p vi.`path).
    * have := common_prefix base p vi.`path.
      rewrite /ORAM.isprefix /node_is_on_path in Hnop.
      rewrite /ORAM.isprefix /node_is_on_path in Hnop_v.
      by smt().
    have := isprefix_size _ _ Hpfx.
    rewrite /base /child /Node.size /=.
    by rewrite to_nodedK 1:#smt:(size_cat of_nodeP) size_cat /= /#.
  case (of_depth vi.`depth <= size (cprefix p vi.`path)) => Hcase /=.
  - (* depth increases to cprefix size >= size n + 1 *)
    rewrite /idepth /depth_of_node /=.
    smt(to_depthdK rng_size_cprefix).
  - (* depth already > cprefix size >= size n + 1 *)
    rewrite /idepth; smt().
+ (* v's path doesn't go through base: nop fails *)
  case (of_depth vi.`depth <= size (cprefix p vi.`path)) => ? /=; smt().
qed.

(* ----- single-step coupling: SimpleORAM.readwrite ~ InternalORAM.step ----- *)
lemma readwrite_step (o : oram) (inst : inst) (n : node) (b : bool) (lb lw : int list) :
  equiv[ SimpleORAM.readwrite ~ InternalORAM.step :
      size n < h
   /\ arg{1} = (o, inst)
   /\ arg{2} = oget (child n b)
   /\ InternalORAM.logb{2} = lb
   /\ InternalORAM.logw{2} = lw
   /\ spc o n b <= InternalORAM.c{2}
   /\ ((K %/ 2 + 1 <= InternalORAM.c{2}
       \/ (exists j, 0 <= j < size SimpleORAM.os{1}
                   /\ K %/ 2 + 1 <= spc SimpleORAM.os{1}.[j] n b))
      => (exists l, (l \in InternalORAM.logw{2} \/ l \in InternalORAM.logb{2})
                 /\ K %/ 2 + 1 = l))
   ==>
      spc res{1}.`1 n b <= InternalORAM.c{2}
   /\ size InternalORAM.logb{2} = size lb + 1
   /\ size InternalORAM.logw{2} = size lw + 1
   /\ ((K %/ 2 + 1 <= InternalORAM.c{2}
       \/ (exists j, 0 <= j < size SimpleORAM.os{1}
                   /\ K %/ 2 + 1 <= spc SimpleORAM.os{1}.[j] n b))
      => (exists l, (l \in InternalORAM.logw{2} \/ l \in InternalORAM.logb{2})
                 /\ K %/ 2 + 1 = l))
  ].
proof.
pose base := oget (child n b).

transitivity DeterministicSimpleORAM.readwrite
  (   arg{1} = (o, inst) /\ arg{2} = (o, inst)
   /\ ={SimpleORAM.leakages, SimpleORAM.os}
    ==> ={res, SimpleORAM.leakages, SimpleORAM.os})
  (   size n < h
   /\ arg{1} = (o, inst) /\ arg{2} = base
   /\ InternalORAM.logb{2} = lb
   /\ InternalORAM.logw{2} = lw
   /\ spc o n b <= InternalORAM.c{2}
   /\ ((K %/ 2 + 1 <= InternalORAM.c{2}
       \/ (exists j, 0 <= j < size SimpleORAM.os{1}
                   /\ K %/ 2 + 1 <= spc SimpleORAM.os{1}.[j] n b))
      => (exists l, (l \in InternalORAM.logw{2} \/ l \in InternalORAM.logb{2})
                 /\ K %/ 2 + 1 = l))
   ==>
      spc res{1}.`1 n b <= InternalORAM.c{2}
   /\ size InternalORAM.logb{2} = size lb + 1
   /\ size InternalORAM.logw{2} = size lw + 1
   /\ ((K %/ 2 + 1 <= InternalORAM.c{2}
       \/ (exists j, 0 <= j < size SimpleORAM.os{1}
                   /\ K %/ 2 + 1 <= spc SimpleORAM.os{1}.[j] n b))
      => (exists l, (l \in InternalORAM.logw{2} \/ l \in InternalORAM.logb{2})
                 /\ K %/ 2 + 1 = l))).
+ by auto => /> /#.
+ by auto.
+ exact (simpleoram_eq_dsimpleoram_step o inst).

(* DeterministicSimpleORAM.readwrite ~ InternalORAM.step *)
proc.
wp.
ecall{1} (flush_flush oram{1} path{1}).
rnd.
wp.
ecall{1} (putback_putback oram{1} (varV inst{!1}) val{1} path{1}).
rnd.
wp.
ecall{1} (fetch_fetch oram{1} (varV inst{!1})).
auto => /> &1 &2 Hsz Hspc Hoverflow.
move => res_fetch Hfetch_oram Hfetch_val.
move => pathL HpathL.
move => res_putback Hputback.
move => pathL0 HpathL0.
move => res_flush Hflush.
rewrite Hflush Hputback Hfetch_oram.
pose o_fetch := rem o (varV inst).
pose o_pb := putback o_fetch (varV inst) pathL
               (if isRd inst then res_fetch.`2 else oget (valV inst)).
pose o_fl := flush o_pb pathL0.
pose b_pb := isprefix base (node_of_path pathL).
pose b_fl := isprefix base (node_of_path pathL0).
pose c1 := InternalORAM.c{2} + b2i b_pb.
pose c2 := if b_fl then 0 else c1.

have Hspc_fetch : spc o_fetch n b <= InternalORAM.c{2}.
+ by apply (lez_trans (spc o n b)) => //; apply spc_rem.

have Hrem : varV inst \notin o_fetch.
+ by rewrite /o_fetch mem_rem.

have Hspc_pb : spc o_pb n b <= c1.
+ rewrite /o_pb /c1.
  have := spc_putback o_fetch (varV inst) pathL
            (if isRd inst then res_fetch.`2 else oget (valV inst)) n b Hsz Hrem.
  rewrite -/b_pb nop_eq_isprefix; smt().

have Hspc_fl : spc o_fl n b <= c2.
+ rewrite /c2 /o_fl; case b_fl => Hbfl.
  - rewrite (spc_flush_through o_pb pathL0 n b) //.
    by rewrite nop_eq_isprefix -/b_fl.
  - by apply (lez_trans (spc o_pb n b)) => //; apply spc_flush_le.

do! split => //.
+ by rewrite size_cat size1.
+ by rewrite size_cat size1.

(* overflow tracking *)
move => Hdisjunct.
case Hdisjunct.
+ (* c2 >= K/2+1 *)
  move => Hc2.
  have Hc1 : K %/ 2 + 1 <= c1 by smt(count_ge0).
  case (K %/ 2 + 1 <= InternalORAM.c{2}) => Hc_old.
  - have := Hoverflow; smt(mem_cat).
  - exists c1; smt(mem_cat).
+ (* some snapshot has spc >= K/2+1 *)
  move => [j [Hj Hspc_j]].
  case (j < 3) => Hj3.
  - (* new snapshot *)
    have Hc_ub: K %/ 2 + 1 <= c1.
    * case (j = 0) => [->> | Hj0].
      + smt(count_ge0). (* o_fl: spc <= c2 <= c1 *)
      case (j = 1) => [->> | Hj1].
      + smt(). (* o_pb: spc <= c1 *)
      + have ?: j = 2 by smt().
        smt(). (* o_fetch: spc <= c_old <= c1 *)
    case (K %/ 2 + 1 <= InternalORAM.c{2}) => Hc_old.
    * have := Hoverflow; smt(mem_cat).
    * exists c1; smt(mem_cat).
  - (* old snapshot *)
    have Hold: (K %/ 2 + 1 <= InternalORAM.c{2}
         \/ (exists j0, 0 <= j0 < size SimpleORAM.os{1}
                      /\ K %/ 2 + 1 <= spc SimpleORAM.os{1}.[j0] n b)).
    * right; exists (j - 3); smt().
    have := Hoverflow Hold; smt(mem_cat).
qed.

(* ----- main compile coupling ----- *)
lemma equiv_internal_compile (p : prog) (n : node) (b : bool) :
  size n < h =>
    equiv[ SimpleORAM.compile ~ InternalORAM.compile :
                 arg{1} = p
              /\ arg{2} = (size p, oget (child n b))
             ==> size InternalORAM.logb{2} = size p
              /\ size InternalORAM.logw{2} = size p
              /\ ((exists j, 0 <= j < size SimpleORAM.os{1}
                          /\ K %/ 2 + 1 <= sub_prefix_count SimpleORAM.os{1}.[j] n b)
                  => (exists l, (l \in InternalORAM.logw{2} \/ l \in InternalORAM.logb{2})
                             /\ K %/ 2 + 1 = l))
         ].
proof.
move => Hsz.
pose base := oget (child n b).
proc; sp.
while (={i}
    /\ p{!1} = p /\ T{!2} = size p
    /\ base{!2} = base
    /\ 0 <= i{1} <= size p
    /\ size InternalORAM.logb{2} = i{1}
    /\ size InternalORAM.logw{2} = i{1}

       (* main invariant: counter >= sub_prefix_count *)
    /\ spc o{1} n b <= InternalORAM.c{2}

       (* overflow tracking (strengthened with c disjunct) *)
    /\ ((K %/ 2 + 1 <= InternalORAM.c{2}
        \/ (exists j, 0 <= j < size SimpleORAM.os{1}
                    /\ K %/ 2 + 1 <= spc SimpleORAM.os{1}.[j] n b))
       => (exists l, (l \in InternalORAM.logw{2} \/ l \in InternalORAM.logb{2})
                  /\ K %/ 2 + 1 = l))
).
+ (* loop body *)
  wp.
  ecall (readwrite_step o{1} p{!1}.[i{!1}] n b InternalORAM.logb{2} InternalORAM.logw{2}).
  auto => /> /#.
+ auto => />.
  do! split.
  + by smt(List.size_ge0).
  + suff: spc FMap.empty n b = 0 by smt().
    rewrite /spc /sub_prefix_count.
    have ->: (fun (v : vars) => v \in FMap.empty<:vars, varinfo> /\
                 let varinfo0 = oget FMap.empty<:vars, varinfo>.[v] in
                 node_is_on_path (oget (child n b)) varinfo0.`path
                 /\ idepth varinfo0 <= size n) = pred0.
    + by apply fun_ext => v /=; smt(mem_empty).
    by rewrite count_pred0.
  + by smt(gt0_K).
  + by smt().
qed.

(* ====== leaf abstracting ====== *)

(* Flush preserves paths *)
lemma flush_path (o : oram) (p : path) (v : vars) :
  v \in o => (oget (flush o p).[v]).`path = (oget o.[v]).`path.
proof.
move => Hv; rewrite /flush mapE.
have -> /= : o.[v] = Some (oget o.[v]) by smt(domE).
by case: (of_depth _ <= _).
qed.

(* node_of_path p = n with size n = h implies path identity *)
lemma node_of_path_leaf (p : path) (n : node) :
  size n = h => node_of_path p = n => Some p = to_path (of_node n).
proof.
move => Hn Hnop.
have Hof: of_path p = of_node n.
+ have := congr1 of_node _ _ Hnop.
  rewrite /node_of_path to_nodedK 1:#smt:(of_pathP) => //.
by smt(of_pathK).
qed.

(* node_of_varinfo vi = n at a leaf => node_of_path vi.path = n *)
lemma node_of_varinfo_leaf (vi : varinfo) (n : node) :
  size n = h => node_of_varinfo vi = n => node_of_path vi.`path = n.
proof.
move => Hn Hvi.
have Hidepth : idepth vi = h.
+ by smt(size_node_of_varinfo).
rewrite /node_of_path /node_of_varinfo /node_at_depth in Hvi.
rewrite /node_of_path.
suff ->: of_path vi.`path = take (of_depth vi.`depth) (of_path vi.`path) by exact Hvi.
rewrite take_oversize //.
by rewrite /idepth in Hidepth; smt(of_pathP).
qed.

(* bsize at a leaf is bounded by posmap count *)
lemma bsize_le_posmap_count (o : oram) (n : node) (posmap : vars -> path option) :
  size n = h =>
  (forall v, v \in o => posmap v = Some (oget o.[v]).`path) =>
  bsize o n <= count (fun v => posmap v = to_path (of_node n)) FinVars.enum.
proof.
move => Hn Hpath.
suff Hle: forall v, omap node_of_varinfo o.[v] = Some n
                  => posmap v = to_path (of_node n).
+ rewrite /bsize /bucket /=.
  have ->: FSet.card (FSet.oflist (filter (fun v => omap node_of_varinfo o.[v] = Some n) FinVars.enum))
         = count (fun v => omap node_of_varinfo o.[v] = Some n) FinVars.enum.
  - by rewrite FSet.uniq_card_oflist 1:filter_uniq 1:FinVars.enum_uniq size_filter.
  by apply count_le => v /= /Hle ->.
move => v Hbucket.
have Hdom : v \in o by smt(domE).
have Hnode : node_of_varinfo (oget o.[v]) = n by smt(omap_some oget_some).
have Hnop := node_of_varinfo_leaf (oget o.[v]) n Hn Hnode.
by rewrite (Hpath v Hdom) (node_of_path_leaf _ n Hn Hnop).
qed.

(* ----- hoare spec for readwrite's effect on os ----- *)
lemma readwrite_os_hoare (o0 : oram) (inst0 : inst) (os0 : oram list) :
  hoare[ SimpleORAM.readwrite :
      arg = (o0, inst0)
   /\ SimpleORAM.os = os0
  ==>
      exists a b c, SimpleORAM.os = a :: b :: c :: os0
  ].
proof.
proc.
inline SimpleORAM.fetch SimpleORAM.putback SimpleORAM.flush.
wp.
while (true); first by auto.
wp; rnd; wp; rnd; wp.
while (true); first by auto.
auto => /> rp0 ? aout0 i1 oram00 ? path1 ? path00 ? i00 oram20 ?.
exists oram20.
exists (putback oram00 (varV inst0) path1
         (if isRd inst0 then oget aout0 else oget (valV inst0))).
by exists oram00.
qed.

lemma fetch_ll : islossless SimpleORAM.fetch.
proof.
by proc; wp; while (0 <= i <= h + 1) (h + 1 - i) => *; auto => />; smt(dunipath_ll gt0_h).
qed.

lemma putback_ll : islossless SimpleORAM.putback.
proof. by proc; auto => />; exact dunipath_ll. qed.

lemma flush_ll : islossless SimpleORAM.flush.
proof.
by proc; wp; while (0 <= i <= h + 1) (h + 1 - i) => *; auto => />; smt(dunipath_ll gt0_h).
qed.

lemma readwrite_ll : islossless SimpleORAM.readwrite.
proof.
proc; wp; call flush_ll; wp; call putback_ll; wp; call fetch_ll; auto => /> /#.
qed.

lemma readwrite_os_phoare (o0 : oram) (inst0 : inst) (os0 : oram list) :
  phoare[ SimpleORAM.readwrite :
      arg = (o0, inst0)
   /\ SimpleORAM.os = os0
  ==>
      exists a b c, SimpleORAM.os = a :: b :: c :: os0
  ] = 1%r.
proof.
conseq readwrite_ll (readwrite_os_hoare o0 inst0 os0) => />.
qed.

(* ----- single-step coupling: SimpleORAM.readwrite ~ LeafORAM.step ----- *)
lemma readwrite_leaf_step (o : oram) (inst : inst) (n : node) (os0 : oram list) :
  size n = h =>
  equiv[ SimpleORAM.readwrite ~ LeafORAM.step :
      arg{1} = (o, inst)
   /\ arg{2} = (posmap{2}, varV inst)
   /\ SimpleORAM.os{1} = os0
   /\ (forall v, v \in o <=> posmap{2} v <> None)
   /\ (forall v, v \in o => posmap{2} v = Some (oget o.[v]).`path)
   ==>
      (forall v, v \in res{1}.`1 <=> res{2} v <> None)
   /\ (forall v, v \in res{1}.`1 => res{2} v = Some (oget res{1}.`1.[v]).`path)
   /\ size SimpleORAM.os{1} = size os0 + 3
   /\ (overflowat SimpleORAM.os{1}.[0] n \/ overflowat SimpleORAM.os{1}.[1] n \/ overflowat SimpleORAM.os{1}.[2] n
       => K < count (fun v => res{2} v = to_path (of_node n)) FinVars.enum)
  ].
proof.
move => Hn.
pose v := varV inst.

transitivity DeterministicSimpleORAM.readwrite
  (   arg{1} = (o, inst) /\ arg{2} = (o, inst)
   /\ ={SimpleORAM.leakages, SimpleORAM.os}
    ==> ={res, SimpleORAM.leakages, SimpleORAM.os})
  (   arg{1} = (o, inst)
   /\ arg{2} = (posmap{2}, v)
   /\ SimpleORAM.os{1} = os0
   /\ (forall v', v' \in o <=> posmap{2} v' <> None)
   /\ (forall v', v' \in o => posmap{2} v' = Some (oget o.[v']).`path)
    ==>
      (forall v', v' \in res{1}.`1 <=> res{2} v' <> None)
   /\ (forall v', v' \in res{1}.`1 => res{2} v' = Some (oget res{1}.`1.[v']).`path)
   /\ size SimpleORAM.os{1} = size os0 + 3
   /\ (overflowat SimpleORAM.os{1}.[0] n \/ overflowat SimpleORAM.os{1}.[1] n \/ overflowat SimpleORAM.os{1}.[2] n
       => K < count (fun v' => res{2} v' = to_path (of_node n)) FinVars.enum)).
+ by auto => /> /#.
+ by auto.
+ exact (simpleoram_eq_dsimpleoram_step o inst).

(* DeterministicSimpleORAM.readwrite ~ LeafORAM.step *)
proc.
wp.
ecall{1} (flush_flush oram{1} path{1}).
rnd{1}.
wp.
ecall{1} (putback_putback oram{1} (varV inst{!1}) val{1} path{1}).
rnd.
wp.
ecall{1} (fetch_fetch oram{1} (varV inst{!1})).
auto => /> &1 Hdom Hpath.
move => res_fetch Hfetch Hfetch_val.
move => pathL _ res_putback Hputback pathL0 _ res_flush Hflush.
rewrite Hflush Hputback Hfetch.

pose val' := if isRd inst then res_fetch.`2 else oget (valV inst).
pose o_fetch := rem o v.
pose o_pb := putback o_fetch v pathL val'.
pose o_fl := flush o_pb pathL0.
pose posmap' := fun v' => if v = v' then Some pathL else posmap{1} v'.

do! split.

+ (* domain: v' \in o_fl <=> posmap' v' <> None *)
  by move => v'; rewrite mem_map /putback mem_set mem_rem; smt().

+ (* paths: v' \in o_fl => posmap' v' = Some path *)
  move => v' Hv'.
  have Hv'_pb : v' \in o_pb by rewrite /o_fl mem_map in Hv'.
  rewrite /posmap' flush_path //.
  rewrite /o_pb /putback get_setE.
  case (v' = v) => [-> | Hneq] /=.
  - by rewrite /v.
  - rewrite (Hpath v') //.
    + by rewrite /o_pb /putback mem_set /o_fetch mem_rem in Hv'_pb; smt().
    by smt(remE).

+ (* os size *)
  by smt().

+ (* overflow => K < count *)
  move => Hoverflow.
  (* os.[0] = o_fl, os.[1] = o_pb, os.[2] = o_fetch *)
  (* For each snapshot, bsize <= count(posmap', path_n) *)
  (* Use bsize_le_posmap_count *)
  suff Hle: forall o', (o' = o_fl \/ o' = o_pb \/ o' = o_fetch) =>
    bsize o' n <= count (fun v' => posmap' v' = to_path (of_node n)) FinVars.enum.
  + rewrite /posmap' /= in Hle; smt().
  move => o' [-> | [-> | ->]].

  (* Case o_fl *)
  - apply (bsize_le_posmap_count _ n posmap' Hn) => v' Hv'.
    have Hv'_pb : v' \in o_pb by rewrite /o_fl mem_map in Hv'.
    rewrite /posmap' flush_path //.
    rewrite /o_pb /putback get_setE.
    case (v' = v) => [-> | Hneq] /=.
    * by rewrite /v.
    * rewrite (Hpath v') //.
      + by rewrite /o_pb /putback mem_set /o_fetch mem_rem in Hv'_pb; smt().
      by smt(remE).

  (* Case o_pb *)
  - apply (bsize_le_posmap_count _ n posmap' Hn) => v' Hv'.
    rewrite /posmap' /o_pb /putback get_setE.
    case (v' = v) => [-> | Hneq] /=.
    * by rewrite /v.
    * rewrite (Hpath v') //.
      + by rewrite /o_pb /putback mem_set /o_fetch mem_rem in Hv'; smt().
      by smt(remE).

  (* Case o_fetch *)
  - apply (bsize_le_posmap_count _ n posmap' Hn) => v' Hv'.
    rewrite /posmap'.
    have Hneq : v <> v' by rewrite /o_fetch mem_rem in Hv'; smt().
    rewrite (: ! v = v') 1:/# /=.
    rewrite (Hpath v') //.
    + by rewrite /o_fetch mem_rem in Hv'; smt().
    by smt(remE).
qed.

(* ----- main compile coupling ----- *)
lemma equiv_leaf_compile (p : prog) (n : node) (j : int):
  size n = h =>
  0 <= j < size p =>
    equiv[ SimpleORAM.compile ~ LeafORAM.compile :
                 arg{1} = p
              /\ arg{2} = take (size p - j) p
             ==> (overflowat SimpleORAM.os{1}.[j * 3] n
               \/ overflowat SimpleORAM.os{1}.[j * 3 + 1] n
               \/ overflowat SimpleORAM.os{1}.[j * 3 + 2] n)
              => K < count (fun v => res{2} v = to_path (of_node n)) FinVars.enum
         ].
proof.
move => Hn Hj.
proc; sp.

(* Split the ORAM while loop at i = size p - j *)
splitwhile{1} ^while : (i < size p - j).

(* Phase 1: coupled while loops *)
seq 1 1 : (
    i{1} = size p - j
 /\ p{!1} = p
 /\ size SimpleORAM.os{1} = 3 * (size p - j)
 /\ (forall v, v \in o{1} <=> posmap{2} v <> None)
 /\ (forall v, v \in o{1} => posmap{2} v = Some (oget o{1}.[v]).`path)
 /\ (overflowat SimpleORAM.os{1}.[0] n \/ overflowat SimpleORAM.os{1}.[1] n \/ overflowat SimpleORAM.os{1}.[2] n
     => K < count (fun v => posmap{2} v = to_path (of_node n)) FinVars.enum)
).

+ (* Phase 1 while *)
  while (
      i{1} = i{2}
   /\ 0 <= i{1} <= size p - j
   /\ p{!1} = p
   /\ p{!2} = take (size p - j) p
   /\ size SimpleORAM.os{1} = 3 * i{1}
   /\ (forall v, v \in o{1} <=> posmap{2} v <> None)
   /\ (forall v, v \in o{1} => posmap{2} v = Some (oget o{1}.[v]).`path)
   /\ (0 < i{1} =>
       (overflowat SimpleORAM.os{1}.[0] n \/ overflowat SimpleORAM.os{1}.[1] n \/ overflowat SimpleORAM.os{1}.[2] n
        => K < count (fun v => posmap{2} v = to_path (of_node n)) FinVars.enum))
  ).
  + (* while body *)
    wp.
    exlim o{1} => o0; exlim (p{!1}.[i{!1}]) => inst0; exlim SimpleORAM.os{1} => os0.
    call (readwrite_leaf_step o0 inst0 n os0).
    skip => /> &2 *.
    split; first by rewrite nth_take /#.
    by move => *; smt(size_take).
  + (* init *)
    auto => />.
    do! split.
    + by smt(List.size_ge0).
    + by move => v; rewrite mem_empty.
    + by move => v; rewrite mem_empty.
    + by smt(size_take).
    + by smt(size_take).
    + by smt(size_take).

+ (* Phase 2: ORAM-only while + return *)
  (* After seq: LHS has while{1}(i < size p){...}; return vs *)
  (*            RHS has return posmap *)
  while{1} (
      size p - j <= i{1} <= size p
   /\ p{!1} = p
   /\ size SimpleORAM.os{1} = 3 * i{1}
   /\ (overflowat (nth witness SimpleORAM.os{1} (3 * (i{1} - (size p - j)))) n
       \/ overflowat (nth witness SimpleORAM.os{1} (3 * (i{1} - (size p - j)) + 1)) n
       \/ overflowat (nth witness SimpleORAM.os{1} (3 * (i{1} - (size p - j)) + 2)) n
       => K < count (fun v => posmap{2} v = to_path (of_node n)) FinVars.enum)
  ) (size p - i{1}).

  + (* phase 2 body *)
    move => &m z; wp.
    exlim o{hr} => o0; exlim (p.[i{hr}]) => inst0; exlim SimpleORAM.os{hr} => os0.
    call (readwrite_os_phoare o0 inst0 os0).
    skip => /> &hr *; smt(nth_behead).

  + (* init + final *)
    by auto => /> /#.
qed.
