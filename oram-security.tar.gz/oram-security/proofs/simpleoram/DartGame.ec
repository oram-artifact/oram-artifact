require import AllCore Real Xreal RealExp List.

require import Distr DBool.
(*---*) import Biased.

require import StdOrder.
(*---*) import IntOrder.

require import StdBigop.
(*---*) import Bigreal Bigreal.BRA.

require import Aux.
(*---*) import ListUtils DistrUtils.

module SamplingLogger = {
  proc play (T : int, p : real) = {
    var i : int;
    var b, w : bool;
    var lb, lw : bool list;

    lb <- [];
    lw <- [];
    i <- 0;
    while (i < T) {
      b <$ dbiased p;
      lb <- lb ++ [b];
      w <$ dbiased p;
      lw <- lw ++ [w];
      i <- i + 1;
    }
    return (lb, lw);
  }
}.

module DartGame = {
  (* The dart game is slightly different from the dart game in the paper, *)
  (*   because the overflow can happen between putback and flush, i.e.,   *)
  (*                                   between black and white.           *)
  proc play (k : int, p : real) = {
    var i : int;
    var nb_hits : int;
    var all_black : bool;
    var white_dart : bool;
    var black_dart : bool;

    i <- 0;
    nb_hits <- 0;
    all_black <- true;
    white_dart <- false;
    while (nb_hits < k) {
      black_dart <$ dbiased p;
      nb_hits <- nb_hits + (b2i black_dart);

      (* IMPORTANT: we check all_black in the middle of the loop *)
      all_black <- all_black /\ !white_dart;

      white_dart <$ dbiased p;
      i <- i + 1;
    }
    
    return all_black;
  }
}.

(* We prove that DartGame win with probability 2 ^ (-k + 1) *)
lemma Pr_DartGame &m (_k : int):
     0 < _k
  => forall p', 0%r <= p' <= 1%r
  => Pr [DartGame.play(_k, p') @ &m: res] <= (2%r ^ (-_k + 1)%r).
proof.
move => ? p' *.
byehoare (_ : ((k = _k /\ p = p')
                 `|` (1%r / (2%r ^ (k - 1)%r))%xr) ==> _) => //=; last first.
+ rewrite !to_pos_pos 1,2:#smt:(rpow_gt0).
  by rewrite (_: ((-_k) + 1)%r = -(_k - 1)%r) 1:#ring rpowN.
proc.
seq 4: ((0 < k /\ nb_hits = 0 /\ all_black /\ p = p' /\ !white_dart) `|`
            (1%r / (2%r ^ (k - 1)%r))%xr).
+ by auto => /> &hr; exact xle_cxr.
while (((all_black => 0 <= nb_hits <= k) /\ p = p') `|`
          (if nb_hits < k then
             (if all_black /\ !white_dart then
                (1%r / (2%r ^ (k - nb_hits - 1)%r))%xr
              else 0%xr)
           else
             (if all_black then 1%xr else 0%xr))
      ); last first.
+ (* reachability *)
  skip => /> &hr.
  by apply xle_cxr => /> * /#.
+ (* inv => pos *)
  move => /> &hr.
  apply xle_cxr_r => /> *.
  by case (all_black{hr}) => * //.
+ (* inductiveness *)
  wp; skip => /> &hr.
  apply xle_cxr_r => /> *.
  case (all_black{hr} /\ !white_dart{hr}) => [#] * /=.
  + rewrite Ep_dbiased //= Ep_dbiased //= Ep_dbiased //= b2i0 b2i1 /=.
    have ^? -> /= : 0 <= nb_hits{hr} + 1 <= k{hr} by smt().
    have -> /=: 0 <= nb_hits{hr} <= k{hr} by smt().
    have -> /=: nb_hits{hr} < k{hr} by assumption.
    case: (nb_hits{hr} + 1 < k{hr}) => ^? ^-> _.
    + rewrite /= !to_pos_pos 1..4:#smt:(rpow_gt0).
      rewrite !clamp_id 1:/#.
      rewrite (_: p{hr} * (1%r - p{hr}) / 2%r ^ (k{hr} - (nb_hits{hr} + 1) - 1)%r
                + (1%r - p{hr}) * (1%r - p{hr}) / 2%r ^ (k{hr} - nb_hits{hr} - 1)%r
                = (1%r - p{hr} * p{hr}) / 2%r ^ (k{hr} - nb_hits{hr} - 1)%r).
      + rewrite (_: (k{hr} - (_ + 1) - 1)%r = (k{hr} - nb_hits{hr} - 1)%r - 1%r) 1:#ring.
        rewrite rpowD // rpowN // rpow1 //.
        by field => //; smt(rpow_gt0).
      by smt(rpow_gt0).
    + rewrite /= !to_pos_pos; 1..3: by smt(rpow_gt0).
      have->: k{hr} - nb_hits{hr} - 1 = 0 by smt().
      rewrite rpow0 RField.invr1.
      have /#: p{hr} * (p{hr} + (1%r - p{hr})) + (1%r - p{hr}) * (1%r - p{hr}) * 1%r
             = 1%r - p{hr} + p{hr} * p{hr}.
      + by ring.
  + by rewrite Ep_dbiased //= Ep_dbiased //.
qed.

lemma Pr_Sampler &m (T : int) (p : real) (k : int) :
     0 <= T
  => 0%r < p <= 1%r
  => 0 < k
  => Pr [ SamplingLogger.play(T, p) @ &m :
              exists i1 i2, 0 <= i1 < i2 <= T /\
                count idfun (interval res.`1 i1 i2) = k /\
                count idfun (interval res.`2 i1 (i2 - 1)) = 0 ]
 <= T%r * (2%r ^ (-k + 1)%r).
proof.
move => ???.
apply (RealOrder.ler_trans
        (bigi predT
          (fun i1 =>
              Pr [ SamplingLogger.play(T, p)
                    @ &m :
                      exists i2, i1 < i2 <= T
                        /\ count idfun (interval res.`1 i1 i2) = k
                        /\ count idfun (interval res.`2 i1 (i2 - 1)) = 0 ])
            0 T)).
+ rewrite (_:
    Pr [ SamplingLogger.play(T, p) @ &m :
           exists i1 i2, 0 <= i1 < i2 <= T
                      /\ count idfun (interval res.`1 i1 i2) = k
                      /\ count idfun (interval res.`2 i1 (i2 - 1)) = 0 ]
  = Pr [ SamplingLogger.play(T, p) @ &m :
           has (fun i1 => exists i2, i1 < i2 <= T
                                 /\ count idfun (interval res.`1 i1 i2) = k
                                 /\ count idfun (interval res.`2 i1 (i2 - 1)) = 0)
               (range 0 T) ]).
  + rewrite Pr [mu_eq] // => &hr *.
    by rewrite hasP /= #smt:(mem_range).
  by rewrite Pr [mu_has_le].
have H : (forall (i1 : int),
            0 <= i1 < T =>
               Pr[SamplingLogger.play(T, p) @ &m :
                  exists (i2 : int),
                    i1 < i2 <= T /\
                    count idfun (interval res.`1 i1 i2) = k /\
                    count idfun (interval res.`2 i1 (i2 - 1)) = 0]
            <= (2%r ^ (-k + 1)%r)).
+ move => i1 ?.
  apply (RealOrder.ler_trans (Pr [DartGame.play(k, p) @ &m: res])).
  + byequiv (_: arg{1} = (T, p) /\ arg{2} = (k, p) ==> _); 2,3: by smt().
    proc.
    sp.
    splitwhile{2} 1: (i < T - i1).
    splitwhile{1} 1: (i < i1).
    splitwhile{1} 2: (count idfun (interval lb i1 i) < k).
    (* jump over the first loop *)
    seq 1 0: (
           i{1} = i1
        /\ p{!1} = p
        /\ p{!2} = p
        /\ T{!1} = T
        /\ k{!2} = k
        /\ all_black{2}
        /\ !white_dart{2}
        /\ i{2} = 0
        /\ size lb{1} = i{1}
        /\ size lw{1} = i{1}
        /\ nb_hits{2} = 0
    ).
    + while{1} (
           (0 <= i{1} /\ i{1} <= T{!1} /\ i{1} <= i1)
        /\ p{!1} = p
        /\ p{!2} = p
        /\ T{!1} = T
        /\ k{!2} = k
        /\ all_black{2}
        /\ !white_dart{2}
        /\ i{2} = 0
        /\ size lb{1} = i{1}
        /\ size lw{1} = i{1}
        /\ nb_hits{2} = 0
      ) (i1 - i){1}.
      + move => &m' z.
        wp; rnd; wp; rnd.
        auto => /> &hr *.
        rewrite -(mu_eq _ predT) -1:dbiased_ll // => ?.
        by rewrite -(mu_eq _ predT) -1:dbiased_ll // #smt:(size_cat).
      + by auto => /> /#.
    seq 1 1: (p{!1} = p
          /\ p{!2} = p
          /\ T{!1} = T
          /\ k{!2} = k
          /\ size lb{1} = i{1}
          /\ size lw{1} = i{1}
          /\ i{1} = i1 + i{2}
          /\ 0 <= i1 < T
          /\ 0 < i{2}
          /\ i1 <= i{1} <= T
          /\ 0 <= nb_hits{2} <= k

          /\ !(nb_hits{2} < k /\ i{1} < T)
          /\ (nb_hits{2} < k => count idfun (drop i1 lb{1}) < k)
          /\ (nb_hits{2} = k =>
                  count idfun (interval lb{1} i1 i{1}) = k
               /\ lb{1}.[i{1} - 1]
               /\ (count idfun (interval lw{1} i1 (i{1} - 1)) = 0 => all_black{2})
             )
    ).
    + while (i{1} = i{2} + i1
          /\ i1 <= i{1} <= T
          /\ p{!1} = p
          /\ p{!2} = p
          /\ T{!1} = T
          /\ k{!2} = k
          /\ size lb{1} = i{1}
          /\ size lw{1} = i{1}
          /\ 0 <= i1 < T
          /\ 0 <= nb_hits{2} <= k

             (* nb_hits counts the number of all darts *)
          /\ count idfun (interval lb{1} i1 i{1}) = nb_hits{2}
             (* all_black checks whether a white dart hits                    *)
          /\ (count idfun (interval lw{1} i1 (i{1} - 1)) = 0 <=> all_black{2})
             (* the last white dart *)
          /\ (0 < i{2} => nth witness lw{1} (i{1} - 1) = white_dart{2})
          /\ (0 = i{2} => !white_dart{2})
             (* the black dart must hit right before success *)
          /\ (nb_hits{2} = k => last witness lb{1})
      ).
      + wp; rnd; wp; rnd.
        auto => |> &1 &2 14? bL ? wL ?.
        do! split.
        + by smt().
        + by smt().
        + by smt().
        + by rewrite size_cat /#.
        + by rewrite size_cat /#.
        + by smt(b2i_ge0 count_ge0).
        + by smt(b2i_le1).
        + rewrite count_interval_with1 1,2:/#.
          rewrite interval_drop; 1: by smt().
          by rewrite /b2i /idfun /#.
        + rewrite interval_catR; 1: by smt().
          move => H_no_white; split.
          + rewrite eqz_leq; split; [| exact count_ge0].
            case (0 < i{2}) => ?.
            + apply (IntOrder.ler_trans
                    (count idfun (interval lw{1} i1 (i{2} + i1)))).
              + by rewrite &(count_subseq) &(interval_subseq) /#.
              by smt().
            + have ?: 0 = i{2} by smt().
              by rewrite interval_empty /#.
          + rewrite -count_eq0 -(has_nthP _ _ witness) negb_exists /= in H_no_white.
            have := H_no_white (i{2} - 1).
            case (0 < i{2}) => ?.
            + have -> @/idfun /=: 0 <= i{2} - 1 < size (interval lw{1} i1 (i{2} + i1)).
              + by smt(interval_size).
              by rewrite interval_nth /#.
            + have ?: 0 = i{2} by smt().
              by smt().
        + move => Hcount ?.
          case (i{2} = 0) => ?.
          + by rewrite interval_empty /#.
          + rewrite (interval_split _ (i{2} + i1 - 1) _ _); 1: by smt(size_cat).
            rewrite {1} interval_catR 1:/#.
            rewrite count_cat interval_catR 1:/# Hcount /=.
            by smt(intervalS).
        + by rewrite nth_cat /#.
        + by smt().
        + move => ?.
          have : (b2i bL) = 1 by smt().
          by rewrite last_cat /#.
        + move => ?.
          rewrite count_interval_with1 1,2:/# interval_drop 1:/#.
          by rewrite /idfun /#.
        + rewrite count_interval_with1 1,2:/#.
          by rewrite interval_drop /idfun /b2i /= /#.
      + skip => |> &1 &2 *; do! split.
        + by smt().
        + by smt().
        + by rewrite interval_empty /#.
        + by rewrite interval_empty /#.
        + by rewrite interval_empty /#.
        + by rewrite interval_empty /#.
        + move => lb_L lw_L i_R white_dart_R H_neg_cond1 H_neg_cond2 *.
          do! split.
          + by smt().
          + case : (!(i_R < T - size lb{1})).
            + by smt().
            + by smt(count_size interval_size).
          + by smt().
          + by rewrite interval_drop /#.
          + by smt(nth_last).

    (* case split after the first loop pair:                                          *)
    (*   case 1 is that the left side will possibly continue, the right side stops;
         case 2 is that the left side stops, the right side will definitely continue. *)
    case (nb_hits{2} = k).
    + rcondf{2} 1.
      + move => &m0.
        auto => /> /#.
      while{1} (T{!1} = T
             /\ nb_hits{2} = k
             /\ size lb{1} = i{1}
             /\ size lw{1} = i{1}
             /\ i1 + i{2} <= i{1}
             /\ 0 <= i1 < T
             /\ 0 < i{2}

                (* main invariant *)
             /\ count idfun (interval lb{1} i1 (i1 + i{2})) = k
             /\ lb{1}.[i1 + i{2} - 1]
             /\ (count idfun (interval lw{1} i1 (i1 + i{2} - 1)) = 0 => all_black{2})
      ) (T{!1} - i{1} + 1).
      + move => &m0 z.
        wp; rnd; wp; rnd.
        auto => |> &hr *.
        rewrite -(mu_eq _ predT) -1:dbiased_ll // => ?.
        rewrite -(mu_eq _ predT) -1:dbiased_ll //.
        by smt(size_cat interval_catR nth_cat).
      + skip => |> &1 &2 8? H; do! split.
        + by smt().
        + by smt().
        + by smt().
        + by smt().
        + move => lb_L lw_L *; do! split.
          + by smt().
          + move => 6? i2 *.
            have ? : i1 + i{2} <= i2.
            + apply (count_interval_mono idfun lb_L i1 (i1 + i{2}) i2 k).
              + by smt().
              + by smt().
              + by smt().
              + by smt().
              + by rewrite /idfun //=.
              + by smt().
              + by rewrite /idfun //=.
            have : count idfun (interval lw_L i1 (i1 + i{2} - 1)) = 0.
            + rewrite eqz_leq; split; [| exact count_ge0].
              apply (IntOrder.ler_trans (count idfun (interval lw_L i1 (i2 - 1)))).
              + by rewrite &(count_subseq) &(interval_subseq) /#.
              by smt().
            by assumption.

    (* the left side stops, the right side will move on. *)
    + rcondf{1} 1.
      + move => &m0.
        by auto => /> /#.
      while{2} (k{!2} = k
             /\ size lb{1} = i{1}
             /\ size lw{1} = i{1}
             /\ p{!2} = p

             /\ i{1} = T
             /\ T{!1} = T

             /\ 0 <= nb_hits{2} <= k

                (* main invariant *)
             /\ (count idfun (drop i1 lb{1}) < k)
      ).
        (* inductiveness *)
      + move => &m0.
        wp; rnd; wp; rnd.
        auto => |> &hr *.
        rewrite (_: (fun (x : bool) => 0 <= nb_hits{hr} + b2i x <= k /\ weight (dbiased p) = 1%r)
                  = predT).
        + rewrite /predT fun_ext /(==) => x.
          rewrite dbiased_ll.
          by smt(b2i_le1 b2i_ge0).
        exact dbiased_ll.
        (* lossless *)
      + move => &1.
        while (p{!hr} = p /\ 0 <= nb_hits <= k{!hr}) (k{!hr} - nb_hits) k{!hr} p => //.
          (* inv => variant <= bound /\ variant <= 0 => !cond *)
        + by smt(b2i_ge0).
          (* Pr[w : pre => pos ] = 1%r => Pr [ c ; w : pre /\ !cond => pos ] = 1%r *)
        + move => IH.
          seq 5: (k{!hr} = k
               /\ size lb{1} = i{1}
               /\ size lw{1} = i{1}
               /\ p{!hr} = p
               /\ i{1} = T
               /\ T{!1} = T
               /\ 0 <= nb_hits <= k
               /\ count idfun (drop i1 lb{1}) < k) => //.
            (* lossless of the first part *)
          + auto => /> &hr *; split.
            + exact dbiased_ll.
            + by move => ? v @/predT @/b2i /> /#.
            (* the first part reaches the negation of the intemediate condition by probability 0 *)
          + wp; rnd; wp; rnd.
            skip => /> &hr *.
            rewrite (_: (fun (x : bool) =>
                          ! 0 <= nb_hits{hr} + b2i x <= k /\ weight (dbiased p) = 1%r)
                      = pred0).
            + by rewrite /pred0 fun_ext /(==) dbiased_ll /b2i /= /#.
            by rewrite /pred0 dbiasedE //.
          (* inv == c => inv by probability 1%r *)
        + wp; rnd; wp; rnd; skip => /> &hr *.
          rewrite (_: (fun (x : bool) =>
                         0 <= nb_hits{hr} + b2i x <= k{!hr} /\ weight (dbiased p) = 1%r)
                    = predT).
          + by rewrite {2} /predT fun_ext /(==) dbiased_ll /b2i /= /#.
          exact dbiased_ll.
          (* decreasing probability is lower bounded by p, and p is larger than 0. *)
        + split.
          + by smt().
          + move => z.
            wp; rnd; wp; rnd; auto => &hr [#] *.
            by rewrite dbiasedE /b2i /= dbiased_ll /= clamp_id /#.
    + skip => |> &1 &2 *; split.
      + by smt().
      + move => all_black_R nb_hits_R 5? i2 *.
        by smt(count_interval_le_count_drop).
  by apply Pr_DartGame => /#.
apply (RealOrder.ler_trans
          (bigi predT
                (fun i => 2%r ^ (-k + 1)%r)
                0 T)).
+ apply (ler_sum_seq predT _
           (fun (i : int) => 2%r ^ (-k + 1)%r)
           (range 0 T)).
  + move => /> a.
    by rewrite mem_range /predT //= & H.
by rewrite sumr_const count_predT size_range lez_maxr //= RField.intmulr //= /#.
qed.
