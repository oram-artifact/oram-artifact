require import AllCore List Distr IntDiv DList RealExp FSet FMap.

require import Ring.
(*---*) import RField IntID.

require export StdOrder.
(*---*) export RealOrder.

require import ORAM.
require import SimpleORAM.

require import StdBigop.
(*---*) import Bigreal Bigreal.BRA.

require import DBool.
(*---*) import Biased.

require import Internal Leaf Abstracting.

require import BitEncoding.
(*---*) import BS2Int.

require import RealSeries.

require import Aux.
(*---*) import ListUtils.

lemma mem_subwordn (n : node) :
  size n < h <=> n \in (map (oget \o to_node) (BoolTuple.subwordn (h - 1))).
proof.
rewrite mapP /(\o); split.
- move => ?; exists (of_node n).
  rewrite BoolTuple.mem_subwordn 1:#smt:(List.size_ge0).
  split.
  - by smt().
  - by smt(of_nodeK).
- move => /> x.
  rewrite BoolTuple.mem_subwordn 1:#smt:(gt0_h) => ? @/size.
  suff ->: of_node (oget (to_node x)) = x by smt().
  by rewrite -oget_omap_some 1:#smt:(to_nodeP) to_nodeT 1:/# oget_some.
qed.

lemma mem_wordn (n : node) :
  size n = h <=> n \in (map (oget \o to_node) (BoolTuple.wordn h)).
proof.
rewrite mapP /(\o); split.
- move => ?; exists (of_node n).
  rewrite BoolTuple.wordnP; split.
  - by smt(gt0_h).
  - by smt(of_nodeK).
- move => /> x.
  rewrite BoolTuple.wordnP lez_maxr 1:#smt:(gt0_h) => ? @/size.
  suff ->: of_node (oget (to_node x)) = x by smt().
  by rewrite -oget_omap_some 1:#smt:(to_nodeP) to_nodeT 1:/# oget_some.
qed.

lemma internal_abstraction &m (p : prog) (n : node) (b : bool) :
  size n < h =>
    Pr[SimpleORAM.compile(p) @ &m :
      exists (j : int),
        0 <= j < size SimpleORAM.os /\ K %/ 2 + 1 <= sub_prefix_count SimpleORAM.os.[j] n b]
  <=
    Pr[InternalORAM.compile(size p, oget (child n b)) @ &m :
      exists (i : int),
        0 <= i < size p /\
        (K %/ 2 + 1 = nth 0 InternalORAM.logb i \/
          K %/ 2 + 1 = nth 0 InternalORAM.logw i)].
proof.
move => Hsz.
byequiv => //.
conseq (equiv_internal_compile p n b _) => //.
move => &1 &2 _ os_L logb_R logw_R [Hsb [Hsw Himpl]] Horam.
have [l [Hl Hk]] := Himpl Horam.
case: Hl => Hmem.
+ rewrite (nthP 0) in Hmem; elim Hmem => i [Hi Hnth].
  by exists i; smt().
+ rewrite (nthP 0) in Hmem; elim Hmem => i [Hi Hnth].
  by exists i; smt().
qed.

lemma leaf_abstraction &m (p : prog) (n : node) (j : int) :
     size n = h
  => 0 <= j < size p
  => Pr[SimpleORAM.compile(p) @ &m :
          0 <= j < size p /\
          (overflowat SimpleORAM.os.[j * 3] n \/
           overflowat SimpleORAM.os.[j * 3 + 1] n \/
           overflowat SimpleORAM.os.[j * 3 + 2] n)]
  <= Pr[LeafORAM.compile(take (size p - j) p) @ &m :
          K < count (fun (v : vars) => res v = Some (oget (to_path (of_node n))))
                    FinVars.enum].
proof.
move => Hsz Hj.
byequiv => //.
conseq (equiv_leaf_compile p n j _ _) => //.
move => &1 &2 Himpl.
move => result_R os_L Hequiv [Hj' Hov].
suff: (fun (v : vars) => result_R v = Some (oget (to_path (of_node n))))
    = (fun (v : vars) => result_R v = to_path (of_node n)).
+ by move => ->; exact (Hequiv Hov).
apply fun_ext => v /=.
have [p' ->] : exists p', to_path (of_node n) = Some p'
  by smt(to_pathP of_nodeP).
by rewrite oget_some.
qed.

(* the final bound is 2 ^ {-(K / 2) + 1} x n x |p| = 2 ^ {-(K / 2) + 1} * (2 ^ {d + 1} - 1) * |p| *)
lemma final_bound &m (p : prog) :
  Pr [ SimpleORAM.compile(p) @ &m : toverflow SimpleORAM.os ]
         <= (2%r ^ (- (K %/ 2) + 1)%r) * (2%r ^ (h + 1)%r - 1%r) * (size p)%r.
proof.
(* start with re-ordering the two existential quantifiers *)
apply (ler_trans (Pr [ SimpleORAM.compile(p) @ &m :
                         exists (n : node) (j : int),
                              0 <= j < size SimpleORAM.os
                           /\ overflowat SimpleORAM.os.[j] n])).
+ apply (ler_trans (Pr [ SimpleORAM.compile(p) @ &m :
                           toverflow SimpleORAM.os ])).
  + apply lerr_eq.
    byequiv; 2,3: done.
    proc.
    while (={i,SimpleORAM.os,o}
        /\ p{!1} = p /\ p{!2} = p
        /\ 0 <= i{2} <= size p
        /\ size SimpleORAM.os{2} = i{2} * 3
    ).
    - inline; wp.
      while (={i,i1,SimpleORAM.os,oram2,path1,pushed}).
      - by auto.
      wp; rnd; wp; rnd; wp.
      while (={i,SimpleORAM.os,oram0,i0,v,aout,p0}
          /\ 0 <= i{2} <= size p
          /\ size SimpleORAM.os{2} = i{2} * 3
      ).
      - by auto.
      by auto => /> &hr /#.

    by auto => />; exact List.size_ge0.

  rewrite Pr [mu_sub] // /toverflow /overflow => &hr.
  + by move => /> o0; rewrite (nthP witness) /#.

apply (ler_trans
             (Pr [ SimpleORAM.compile(p) @ &m :
                     exists (n : node), size n < h /\ toverflowat SimpleORAM.os n ]
            + Pr [ SimpleORAM.compile(p) @ &m :
                     exists (n : node), size n = h /\ toverflowat SimpleORAM.os n ])).
+ apply (ler_trans (Pr [ SimpleORAM.compile(p) @ &m :
                              (exists (n : node), size n < h /\ toverflowat SimpleORAM.os n)
                           \/ (exists (n : node), size n = h /\ toverflowat SimpleORAM.os n) ])).
  (* Here, we need to show that "if size n > h, then overflow at n is not possible". *)
  + rewrite Pr [mu_sub] => /> &hr n j ?.
    case (size n < h) => ???.
    + left; exists n; split => // @/toverflowat.
      exists SimpleORAM.os{hr}.[j].
      by rewrite mem_nth /#.
    + case (size n = h) => ?.
      right; exists n; split => // @/toverflowat.
      exists SimpleORAM.os{hr}.[j].
      by rewrite mem_nth /#.
    + by smt(of_nodeP).
  by rewrite Pr [mu_or]; smt(mu_bounded).

apply (ler_trans
          ((2%r ^ (- (K %/ 2) + 1)%r * ((2 ^ h) - 1)%r * (size p)%r)
         + (2%r ^ (- (K %/ 2) + 1)%r * (2 ^ h)%r * (size p)%r))).
  (* ==== internal nodes begin === *)
+ have ?: Pr [ SimpleORAM.compile(p) @ &m :
                 exists (n : node), size n < h /\ toverflowat SimpleORAM.os n ]
             <= 2%r ^ (- (K %/ 2) + 1)%r * (2 ^ h - 1)%r * (size p)%r.
  + apply (ler_trans
            (Pr [ SimpleORAM.compile(p) @ &m :
                    exists (n : node), size n < h /\
                    exists (j : int), 0 <= j < size SimpleORAM.os /\ overflowat SimpleORAM.os.[j] n ])).
    + rewrite lerr_eq Pr [mu_eq] //= /toverflowat.
      (* FIXME: cannot move after the rewrite above. *)
      move => &hr; split.
      + elim => n [#] ?.
        elim => o0.
        rewrite (nthP witness) => [#].
        elim => i [#] ????.
        exists n; split => //.
        by exists i => /#.
      + elim => n [#] ?.
        elim => i [#] ???.
        exists n; split => //.
        exists SimpleORAM.os{hr}.[i].
        by rewrite mem_nth 1:/#.

    apply (ler_trans (big predT
                          (fun n =>
                            Pr [ SimpleORAM.compile(p) @ &m :
                                   exists (j : int), 0 <= j < size SimpleORAM.os /\ overflowat SimpleORAM.os.[j] n ])
                          (map (oget \o to_node) (BoolTuple.subwordn (h - 1))))).
    + apply (ler_trans Pr [SimpleORAM.compile(p) @ &m :
                             has (fun n => exists (j : int), 0 <= j < size SimpleORAM.os /\ overflowat SimpleORAM.os.[j] n)
                                 (map (oget \o to_node) (BoolTuple.subwordn (h - 1)))]).
      + rewrite lerr_eq Pr [mu_eq] //=.
        by move => &hr; rewrite hasP /= #smt:(mem_subwordn).
      by rewrite Pr [mu_has_le].

    have: (forall n, size n < h =>
                Pr [ SimpleORAM.compile(p) @ &m : exists (j : int), 0 <= j < size SimpleORAM.os /\ overflowat SimpleORAM.os.[j] n ]
             <= (2%r ^ (- (K %/ 2) + 1)%r * (size p)%r)).
    + move => n ?.
      (* This is the main step that's reasoning on the tree, we are going to show that: *)
      (*    K < bucket size                                                             *)
      (* => K < #(blocks belong to the left subtree)                                    *)
      (*      + #(blocks belong to the right subtree)                                   *)
      (* => K < #(blocks on the prefix that potentially go to left subtree)             *)
      (*      + #(blocks on the prefix that potentially go to right subtree).           *)
      (* => K / 2 < #(blocks on the prefix that potentially go to one subtree).         *)
      apply (ler_trans (Pr [ SimpleORAM.compile(p) @ &m :
                               exists (j : int), 0 <= j < size SimpleORAM.os /\
                                 (K %/ 2 + 1 <= sub_prefix_count SimpleORAM.os.[j] n false
                               \/ K %/ 2 + 1 <= sub_prefix_count SimpleORAM.os.[j] n true )])).
      + byequiv (: ={p} ==> ={SimpleORAM.os}) => //.
        - by proc; sim.
        - move => /> &hr j @/overflowat ???.

          have ?:
            bsize SimpleORAM.os{hr}.[j] n
              <= sub_prefix_count SimpleORAM.os{hr}.[j] n false
               + sub_prefix_count SimpleORAM.os{hr}.[j] n true.
          + rewrite /bsize /bucket /sub_prefix_count /= uniq_card_oflist.
            - by rewrite &(filter_uniq) &(FinVars.enum_uniq).
            rewrite size_filter &(count_union) => v /= ? Hn.
            have Hdom : v \in SimpleORAM.os{hr}.[j] by smt(domE).
            apply omap_some_oget in Hn.
            pose vi := oget SimpleORAM.os{hr}.[j].[v].
            pose b := (of_path vi.`path).[size n].
            suff: node_is_on_path (oget (child n b)) vi.`path by smt(size_node_of_varinfo).
            by rewrite -Hn -/vi &(child_is_on_path) -size_node_of_varinfo /#.

          have ? : forall b,
                        sub_prefix_count SimpleORAM.os{hr}.[j] n b
                     <= sub_prefix_count SimpleORAM.os{hr}.[j] n b.
          + by rewrite /sub_bucket_count /sub_prefix_count => b.

          by exists j; smt().

      apply (ler_trans (Pr [ SimpleORAM.compile(p) @ &m :
                               (exists (j : int), 0 <= j < size SimpleORAM.os /\
                                  K %/ 2 + 1 <= sub_prefix_count SimpleORAM.os.[j] n false)
                            \/ (exists (j : int), 0 <= j < size SimpleORAM.os /\
                                  K %/ 2 + 1 <= sub_prefix_count SimpleORAM.os.[j] n true) ])).
      + rewrite Pr [mu_sub] //.
        move => /> &hr j ??.
        case => ?.
        - by left; exists j.
        - by right; exists j.
      apply (ler_trans (Pr [ SimpleORAM.compile(p) @ &m :
                               exists (j : int), 0 <= j < size SimpleORAM.os /\
                                 K %/ 2 + 1 <= sub_prefix_count SimpleORAM.os.[j] n false ]
                      + Pr [ SimpleORAM.compile(p) @ &m :
                               exists (j : int), 0 <= j < size SimpleORAM.os /\
                                 K %/ 2 + 1 <= sub_prefix_count SimpleORAM.os.[j] n true  ])).
      + by rewrite Pr [mu_or] //; smt(mu_bounded).

      have Hb: (forall (b : bool),
                    Pr [ SimpleORAM.compile(p) @ &m :
                           exists (j : int), 0 <= j < size SimpleORAM.os /\
                             K %/ 2 + 1 <= sub_prefix_count SimpleORAM.os.[j] n b ]
                 <= 2%r ^ (- (K %/ 2))%r * (size p)%r).
      + move => b.
        pose prob := 2%r ^ (-(size n + 1))%r.
        pose T := size p.
        pose base := oget (child n b).
        apply (ler_trans (Pr [ InternalORAM.compile(T, base) @ &m :
                                 exists i, 0 <= i < T /\
                                   (K %/ 2 + 1 = nth 0 InternalORAM.logb i
                                 \/ K %/ 2 + 1 = nth 0 InternalORAM.logw i) ])).
        + exact internal_abstraction.
        apply Pr_Internal.
        + exact List.size_ge0.
        + have ?: 0 < size (of_node n ++ [b]) <= h.
          + by rewrite size_cat size1 #smt:(List.size_ge0).
          by smt(to_nodeP).
      have := Hb true.
      have := Hb false.
      rewrite (_: ((- K %/ 2) + 1)%r = (- K %/ 2)%r + 1%r); 1: by ring.
      by rewrite rpowD // rpow1 // /#.
    move => Hj.
    (* close union bound *)
    apply (ler_trans
             (big predT
                   (fun (n : node) => 2%r ^ ((-K %/ 2) + 1)%r * (size p)%r)
                   (map (oget \o to_node) (BoolTuple.subwordn (h - 1))))).
    + apply (ler_sum_seq predT _
                   (fun (n : node) => 2%r ^ ((-K %/ 2) + 1)%r * (size p)%r)
                   (map (oget \o to_node) (BoolTuple.subwordn (h - 1)))).
      + by move => n @/predT /= /mem_subwordn ?; exact Hj.
    rewrite sumr_const count_predT size_map.
    rewrite BoolTuple.size_subwordn 1:#smt:(gt0_h) /=.
    by rewrite intmulr &(lerr_eq); ring.
  (* === internal nodes end === *)

  (* === leaf nodes begin === *)
  have ?: Pr [ SimpleORAM.compile(p) @ &m :
                 exists (n : node), size n = h /\ toverflowat SimpleORAM.os n ]
             <= 2%r ^ (- (K %/ 2) + 1)%r * (2 ^ h)%r * (size p)%r.
  + apply (ler_trans
            (Pr [ SimpleORAM.compile(p) @ &m :
                    exists (n : node), size n = h /\
                    exists (j : int), 0 <= j < size SimpleORAM.os /\ overflowat SimpleORAM.os.[j] n ])).
    + rewrite lerr_eq Pr [mu_eq] //= /toverflowat.
      (* wierd, cannot move after the rewrite above. *)
      move => &hr; split.
      + elim => n [#] ?.
        elim => o0.
        rewrite (nthP witness) => [#].
        elim => i [#] ????.
        exists n; split => //.
        by exists i => /#.
      + elim => n [#] ?.
        elim => i [#] ???.
        exists n; split => //.
        exists SimpleORAM.os{hr}.[i].
        by rewrite mem_nth 1:/#.

  have ?: Pr [ SimpleORAM.compile(p) @ &m :
                 exists (n : node), size n = h /\
                   exists (j : int), 0 <= j < size SimpleORAM.os /\ overflowat SimpleORAM.os.[j] n ]
       <= 2%r ^ ((- K %/ 2) + 1)%r * (2 ^ h)%r * (size p)%r.
  + apply (ler_trans
            (big predT
                (fun (n : node) =>
                   Pr[ SimpleORAM.compile(p) @ &m :
                         exists (j : int), 0 <= j < size SimpleORAM.os /\ overflowat SimpleORAM.os.[j] n ])
                (map (oget \o to_node) (BoolTuple.wordn h)))).
    (* open an union bound *)
    + apply (ler_trans
               Pr[SimpleORAM.compile(p) @ &m :
                    has (fun n => exists (j : int), 0 <= j < size SimpleORAM.os /\ overflowat SimpleORAM.os.[j] n)
                        (map (oget \o to_node) (BoolTuple.wordn h))]).
      + rewrite Pr [mu_sub] => /> &hr n ? j ???.
        rewrite hasP; exists n.
        rewrite -mem_wordn /=; split => //.
        by exists j.
      by rewrite Pr [mu_has_le].
      have Hleaf':
        forall (n : node), size n = h =>
           Pr [ SimpleORAM.compile(p) @ &m : exists (j : int), 0 <= j < size SimpleORAM.os /\ overflowat SimpleORAM.os.[j] n ]
        <= 2%r ^ ((- K %/ 2) + 1)%r * (size p)%r.
      + move => n ?.
        apply (ler_trans
                Pr [ SimpleORAM.compile(p) @ &m : exists (j : int), 0 <= j < size p /\
                                                             (overflowat SimpleORAM.os.[j * 3] n
                                                              \/ overflowat SimpleORAM.os.[j * 3 + 1] n
                                                              \/ overflowat SimpleORAM.os.[j * 3 + 2] n) ]).
        + rewrite lerr_eq.
          byequiv; 2,3: by smt().
          conseq (_: _ ==> ={SimpleORAM.os} /\ size SimpleORAM.os{1} = size p * 3).
          + move => /> os *; split.
            + move => j *.
              exists (j %/ 3); split.
              + by smt().
              + by have ? /# : overflowat os.[j %/ 3 * 3 + (j %% 3)] n by smt().
            + move => j ??.
              case.
              + by move => ?; exists (j * 3) => /#.
              case.
              + by move => ?; exists (j * 3 + 1) => /#.
              + by move => ?; exists (j * 3 + 2) => /#.
          (* maybe better to split the post-condition here *)
          proc.
          while (0 <= i{1} <= size p
             /\ p{!1} = p /\ p{!2} = p
             /\ ={i,SimpleORAM.os,o}
             /\ size SimpleORAM.os{1} = i{1} * 3
          ).
          + inline.
            wp.
            while (0 <= i{1} < size p
                /\ 0 <= i1{1} <= h + 1
                /\ p{!1} = p /\ p{!2} = p
                /\ ={i,i1,SimpleORAM.os,oram2,path1,pushed}
                /\ size SimpleORAM.os{1} = i{1} * 3 + 2
            ).
            + by auto => /> /#.
            wp; rnd; wp; rnd; wp.
            while (0 <= i{1} < size p
                /\ 0 <= i0{1} <= h + 1
                /\ p{!1} = p /\ p{!2} = p
                /\ ={i,SimpleORAM.os,i0,v,aout,p0,oram0}
                /\ size SimpleORAM.os{1} = i{1} * 3
            ).
            + by auto => /> /#.
            auto => /> &1 &2 *; do split.
            + by smt(gt0_h).
            + move => *; do split.
              + by smt(gt0_h).
              + by smt().
              + by smt().
          auto => />; split.
          + exact List.size_ge0.
          + by smt().

        apply (ler_trans
                 (bigi predT
                   (fun j => Pr [ SimpleORAM.compile(p) @ &m :
                                    0 <= j < size p /\
                                   (overflowat SimpleORAM.os.[j * 3] n \/
                                    overflowat SimpleORAM.os.[j * 3 + 1] n \/
                                    overflowat SimpleORAM.os.[j * 3 + 2] n)])
                   0 (size p))).
        (* open an union bound *)
        + apply (ler_trans
                   Pr[SimpleORAM.compile(p) @ &m : has (fun j => 0 <= j < size p /\
                                                         (overflowat SimpleORAM.os.[j * 3] n \/
                                                          overflowat SimpleORAM.os.[j * 3 + 1] n \/
                                                          overflowat SimpleORAM.os.[j * 3 + 2] n))
                                                 (range 0 (size p))]).
          + rewrite Pr [mu_sub] => /> &hr j ???.
            rewrite hasP; exists j.
            by rewrite mem_range /#.
          by rewrite Pr [mu_has_le].
        have Hleaf:
          forall j, 0 <= j < size p =>
             Pr [ SimpleORAM.compile(p) @ &m : 0 <= j < size p /\
                                             (overflowat SimpleORAM.os.[j * 3] n \/
                                              overflowat SimpleORAM.os.[j * 3 + 1] n \/
                                              overflowat SimpleORAM.os.[j * 3 + 2] n) ]
          <= 2%r ^ ((- K %/ 2) + 1)%r.
        + move => j ?.
          pose pth := oget (to_path (of_node n)).
          apply (ler_trans (Pr [ LeafORAM.compile(take (size p - j) p) @ &m :
                                   K < count
                                         (fun v => res v = Some pth)
                                         FinVars.enum ])).
          + exact leaf_abstraction.
          apply (ler_trans (2%r ^ (- K %/ 2)%r)).
          + exact Pr_LeafORAM.
          by apply rpow_mono_base_ge1 => // /#.
        (* close an union bound *)
        apply (ler_trans
                 (bigi predT
                       (fun (i : int) => 2%r ^ ((-K %/ 2) + 1)%r)
                       0 (size p))).
        + apply (ler_sum_seq predT _
                     (fun (i : int) => 2%r ^ ((-K %/ 2) + 1)%r)
                     (range 0 (size p))).
          move => j' @/predT /=.
          by rewrite mem_range &(Hleaf).
        rewrite sumr_const count_predT.
        rewrite size_range lez_maxr /= 1:#smt:(List.size_ge0).
        by rewrite intmulr //.
    (* close an union bound *)
    apply (ler_trans
            (big predT
                 (fun (n : node) => 2%r ^ ((- K %/ 2) + 1)%r * (size p)%r)
                 (map (oget \o to_node) (BoolTuple.wordn h)))).
    + apply (ler_sum_seq predT _
                 (fun (n : node) => 2%r ^ ((- K %/ 2) + 1)%r * (size p)%r)
                 (map (oget \o to_node) (BoolTuple.wordn h))).
      move => j' @/predT /=.
      by rewrite -mem_wordn &(Hleaf').
    rewrite sumr_const count_predT.
    rewrite size_map BoolTuple.size_wordn lez_maxr 1:#smt:(gt0_h).
    by rewrite /FinBool.card /FinBool.enum /= intmulr lerr_eq; ring.
    done.
  (* === leaf nodes end === *)
  by smt().
rewrite lerr_eq (: (2%r ^ (h + 1)%r - 1%r) = ((2 ^ h)%r + (2 ^ h - 1)%r)).
+ rewrite (: (h + 1)%r = h%r + 1%r) 1:/#.
  rewrite rpowD // rpow1 //.
  rewrite {2} (_: 2%r = 1%r + 1%r) //.
  rewrite (: (2 ^ h - 1)%r = (2 ^ h)%r - 1%r) 1:/#.
  by rewrite int2rpow // 1:#smt:(gt0_h); ring.
by ring.
qed.
