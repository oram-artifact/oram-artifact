require import AllCore List Distr IntDiv DList RealExp.
require import FSet.

require import Aux.
(*---*) import ListUtils DistrUtils PosMapUtils.

require import StdBigop.
(*---*) import Bigint Bigreal.

require import ORAM.
require import SimpleORAM.
(*---*) import UniPath.

require import DBool.
(*---*) import Biased.

require import StdOrder.
(*---*) import RealOrder.

require import Chernoff.

(* ---------------------------------------------------------------- *)
abbrev "_.[_]" (posmap : vars -> path option) (v : vars) : path option =
  posmap v.

abbrev "_.[_<-_]" (posmap : vars -> path option) (v : vars) (p : path) : vars -> path option =
  fun v' => if v = v' then Some p else posmap.[v'].

(* ---------------------------------------------------------------- *)
op squeeze_posmap (p : prog) (posmap : vars -> path option) =
  map (oget \o posmap) (undup (map varV p)).

(* ---------------------------------------------------------------- *)
module LeafORAM = {
  (* We are considering a specific node and a specific time *)
  proc step (posmap : vars -> path option, v : vars) = {
    var path : path;
    path <$ dunipath;
    posmap <- posmap.[v <- path];
    return posmap;
  }

  proc compile (p : prog) = {
    var posmap : vars -> path option;
    var i : int;
    var path : path;
    i <- 0;
    posmap <- fun _ => None;
    while (i < size p) {
      posmap <@ step(posmap, varV p.[i]);
      i <- i + 1;
    }
    return posmap;
  }
}.

(* -------------------------------------------------------------------- *)
lemma eq_count_squeezed (posmap : vars -> path option) (pl : path list)
                        (_prog : prog) (_path : path) :
     (forall v, v \in undup (map varV _prog) <=> posmap v <> None)
  => pl = squeeze_posmap _prog posmap
  => count (fun v => posmap.[v] = Some _path) FinVars.enum
   = count (fun x => x = _path) pl.
proof.
move => Hsupp.
rewrite /squeeze_posmap => ->.
rewrite count_map /(\o) /pred1 /preim /=.

pose p1 := fun v => posmap v = Some _path.
pose p2 := fun v => oget posmap.[v] = _path.
pose s := undup (map varV _prog).

rewrite (eq_count _ (fun v => v \in s /\ p2 v)) 1:/#.
rewrite (_: count _ FinVars.enum = count p2 (filter (mem s) FinVars.enum)).
- by rewrite count_filter &(eq_count) /#.
rewrite &(perm_eqP) &(uniq_perm_eq).
+ by rewrite &(filter_uniq) &(FinVars.enum_uniq).
+ exact undup_uniq.
+ by move => v; rewrite mem_filter 1:#smt:(FinVars.enumP).
qed.

(* ---------------------------------------------------------------- *)
module PosMapConstr = {
  proc redundant_loop(p : prog) = {
    var paths : path list;
    paths <@ PathSampler.LoopSnoc.sample(size p);
    return update (fun _ => None) (zip (map varV p) paths);
  }

  proc redundant_onetime(p : prog) = {
    var paths : path list;
    paths <@ PathSampler.Sample.sample(size p);
    return update (fun _ => None) (zip (map varV p) paths);
  }
}.

lemma leaforam2posmapconstr_redundant_loop (_p : prog) :
  equiv [ LeafORAM.compile ~ PosMapConstr.redundant_loop :
              arg{1} = _p /\ arg{2} = _p ==> ={res} ].
proof.
proc; inline; wp; sp.
while (0 <= i{1} <= size p{1}
    /\ ={i}
    /\ n{2} = size _p
    /\ p{1} = _p /\ p{2} = _p
    /\ i{2} = size l{2}
    /\ posmap{1} = update (fun (_ : vars) => None) (zip (map varV (take i{1} p{2})) l{2})
).
+ wp; rnd; auto => /> &1 &2 ?? pathL ?; do! split.
  + by smt().
  + by smt().
  + by rewrite size_cat size1.
  + rewrite takeD // map_cat (take1 witness _ 1) //.
    + by rewrite size_drop /#.
    rewrite -head_drop // map1 !cats1 zip_rcons.
    + by rewrite size_map size_take /#.

    by rewrite updateSr /#.
+ skip => />; do! split.
  + exact size_ge0.
  + by smt().
  + by move => pl *; rewrite take_oversize /#.
qed.

lemma posmapconstr_redundant_loop2posmapconstr_redundant_onetime (_p : prog) :
  equiv [ PosMapConstr.redundant_loop ~ PosMapConstr.redundant_onetime :
             arg{1} = _p /\ arg{2} = _p ==> ={res} ].
proof.
proc; rewrite equiv [{1} 1 -PathSampler.Sample_LoopSnoc_eq].
by inline; auto.
qed.

lemma Pr_LeafORAM &m (prog : prog) (path : path) :
     Pr [ LeafORAM.compile(prog) @ &m :
            K < count (fun v => res v = Some path) FinVars.enum ]
  <= 2%r ^ (- K %/ 2)%r.
proof.
pose n := size (undup (map varV prog)).
pose p := 2%r ^ -h%r.

have ?: 0 <= n <= FinVars.card.
- split => [| ?].
  - case (n = 0).
    - by rewrite List.size_eq0 undup_nilp /#.
    - by smt(List.size_ge0).
  - rewrite /n /card uniq_leq_size.
    - exact undup_uniq.
    - by move => v ?; exact FinVars.enumP.

(* from leaf oram to one-time position map sampler *)
apply (ler_trans (Pr [ PosMapConstr.redundant_loop(prog) @ &m :
                         K < count (fun v => res v = Some path) FinVars.enum ])).
+ apply lerr_eq.
  byequiv (: arg{1} = prog /\ arg{2} = prog ==> ={res}) => //.
  exact leaforam2posmapconstr_redundant_loop.

apply (ler_trans (Pr [ PosMapConstr.redundant_onetime(prog) @ &m :
                         K < count (fun v => res v = Some path) FinVars.enum ])).
+ apply lerr_eq.
  byequiv (: arg{1} = prog /\ arg{2} = prog ==> ={res}) => //.
  exact posmapconstr_redundant_loop2posmapconstr_redundant_onetime.

(* from the program to a distribution expression *)
apply (ler_trans (mu (d_of_update dunipath (map varV prog))
                     (fun posmap => K < count (fun (v : vars) => posmap v = Some path) FinVars.enum))).
+ apply lerr_eq.
  byphoare (: arg = prog ==> _) => //.
  proc; inline.
  wp; sp; rnd.
  skip => /> @/d_of_update.
  by rewrite dmapE /(\o) size_map.

(* reduce a position map construction to a unduplicate position map construction *)
rewrite d_of_update_undup 1:dunipath_ll.

(* reduce a unduplicate position map construction to a list list sampling *)
apply (ler_trans (mu (dlist dunipath n) (fun l => K < count (pred1 path) l))).
+ rewrite /d_of_undup_update dmapE /(\o) /pred1.
  rewrite &(lerr_eq) &(mu_eq_support) /= => pl ?.

  have Hsize : size pl = n by smt(supp_dlist_size).

  pose posmap := update (fun (_ : vars) => None)
                        (zip (undup (map varV prog)) pl).
  have /#: count (fun (v : vars) => posmap.[v] = Some path) FinVars.enum
         = count (fun (x : path) => x = path) pl.
  - have ?: pl = squeeze_posmap prog posmap.
    - apply (eq_from_nth witness).
      - by rewrite size_map Hsize.
      - move => i @/squeeze_posmap @/(\o) [#] ??.
        rewrite (nth_map witness witness) 1:/# /= /posmap update_fetch 1,2:/# //.
        - exact undup_uniq.
    apply (eq_count_squeezed posmap pl prog) => //.
    - move => v @/posmap.
      rewrite init_from_assoc -assoc_undup_mask assoc_rev_uniq.
      - by rewrite Hsize.
      - exact undup_uniq.
      by rewrite assocTP unzip1_zip // IntOrder.lerr_eq Hsize //.

(* reduce the distribution of list of list to the distribution of list of boolean *)
rewrite (_: (fun (l : path list) => K < count (pred1 path) l)
          = ((fun i => K < i) \o (fun pl => count (pred1 path) pl))).
+ by move => @/(\o) //=.
rewrite -dmapE.
rewrite (_: (fun (pl : path list) => count (pred1 path) pl)
          = (hamming \o (map (pred1 path)))).
- move => @/(\o) /=.
  apply fun_ext => x.
  rewrite count_map /preim /pred1.
  by smt(eq_count).
rewrite -dmap_comp.
rewrite (_: (dmap (dlist dunipath n) (map (pred1 path)))
          = (dlist (dbiased p) n)).
- rewrite -dlist_dmap.
  have -> //: dmap dunipath (pred1 path) = dbiased p.
  - apply eq_distr.

    have Hcount: 2 ^ h
               = count (pred1 path) FinPath.enum
               + count (predC1 path) FinPath.enum.
    - rewrite -FinPath.cardE /FinPath.card -count_predT.
      by apply count_disjoint_union => /#.
    have HcountT : count (pred1 path) FinPath.enum = 1.
    - rewrite count_uniq_mem.
      - exact FinPath.enum_uniq.
      - by rewrite FinPath.enumP /b2i //=.
    have HcountF : count (predC1 path) FinPath.enum = 2 ^ h - 1 by smt().

    case.
    - have->: mu1 (dbiased p) true = p.
      - by rewrite dbiased1E !clamp_id 1,2:#smt:(rg_ipow2 gt0_h).
      rewrite dmap1E /(\o) {1}/pred1 dunipathE FinPath.cardE.
      have->: (fun (x : path) => pred1 path x = true) = pred1 path by smt().
      by rewrite HcountT int2rpow // 1:#smt:(gt0_h) -rpowN //.
    - have->: mu1 (dbiased p) false = 1%r - p.
      - rewrite dbiased1E !clamp_id 1,2:#smt:(rg_ipow2 gt0_h).
      rewrite dmap1E /(\o) {1}/pred1.
      rewrite dunipathE FinPath.cardE.
      have->: (fun (x : path) => pred1 path x = false) = predC1 path by smt().
      rewrite HcountF fromintD !int2rpow // 1:#smt:(gt0_h).
      field; 1: by smt(rpow_gt0).
      by rewrite /p -rpowD // RField.subrr rpow0 //.

(* before applying Chernoff bound, a special case: n = 0 *)
case (n = 0) => [-> | ?].
- by rewrite dlist0 // dmap_dunit /= dunitE #smt:(gt0_K rpow_gt0).

(* apply Chernoff bound *)
pose d := dmap (dlist (dbiased p) n) hamming.
pose m := n%r * p.
pose dt := (K + 1)%r / m - 1%r.

have ?: 0%r < m <= 1%r.
- rewrite /m /p; split.
  - by smt(gt0_ipow2).
  - have ?: 0%r <= n%r <= 2%r ^ h%r.
    + split => [| ?].
      + by smt().
      + rewrite -int2rpow 1,2:#smt:(gt0_h).
        apply (ler_trans FinVars.card%r).
        + by rewrite &(le_fromint) /#.
        by rewrite &(le_fromint) &(vars_count_ub).
    have /#: 2%r ^ h%r * ipow2 h <= 1%r.
    - by rewrite -rpowD // rpow0.

apply (ler_trans ((exp dt / (1%r + dt) ^ (1%r + dt)) ^ m)).
- case (m = 0%r) => [-> | ?].
  - by rewrite rpow0 le1_mu.
  - have->: (fun i => K < i) = (fun i => (1%r + dt) * m <= i%r).
    - apply fun_ext => i.
        have <- : K%r + 1%r = (1%r + dt) * m.
        - rewrite /dt /m.
          by field; smt(rpow_gt0).
        by rewrite -fromintD le_fromint /#.
      have->: m = E d (fun x => x%r).
      - rewrite eq_sym.

        have eqf: ((%r) \o count (pred1 true)) == BRA.big predT b2r.
        - elim=> // x xs ih @/(\o) /=; rewrite BRA.big_consT -ih.
          by rewrite fromintD /(\o) /=; congr => /#.
        rewrite /m /d exp_dmap /= 1:hasE_dmap.
        - by rewrite (eq_hasE _ _ _ eqf) &(hasED_dlist) // &(hasE_dbiased).
        rewrite (eq_exp _ _ (BRA.big predT b2r)) /=.
        - by move => xs _; apply /eqf.
        rewrite expXD_ll //.
        - exact hasE_dbiased.
        - exact dbiased_ll.
        rewrite exp_dbiased /= clamp_id // 1:#smt:(rg_ipow2 gt0_h).
        exact RField.mulrC.

      apply (Chernoff n dt p) => //.
      - by smt(gt0_K).
      - by smt(rg_ipow2).

(* showing that the chernoff bound is small enough *)
apply (chernoff_bound_small_enough dt K m).
- by smt(gt0_K).
- by smt(gt0_K).
- by smt().
- by rewrite /dt; field => /#.
qed.
