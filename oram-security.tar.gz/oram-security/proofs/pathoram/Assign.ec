(* -------------------------------------------------------------------- *)
(* Concrete implementation of the assign (eviction) operator and         *)
(* proofs of the 5 axioms from PathORAM.ec.                             *)
(*                                                                       *)
(* The implementation follows the greedy leaf-to-root eviction from the  *)
(* Path ORAM paper (Stefanov et al., 2013), matching the Lean           *)
(* formalization in ebndpo/PathOram/Protocol.lean.                       *)
(* -------------------------------------------------------------------- *)

require import AllCore List FMap FSet SmtMap IntDiv IntMin.

require import Aux.
(*---*) import ListUtils FMapUtils.

require import ORAM.

require import PathORAM.

(* ==================================================================== *)
(* Helper: restrict a map to at most k keys                              *)

op take_fmap ['a 'b] (k : int) (m : ('a, 'b) fmap) : ('a, 'b) fmap =
  let keys = oflist (take k (elems (fdom m))) in
  filter (fun (x : 'a) (_ : 'b) => x \in keys) m.

(* ==================================================================== *)
(* Eligible blocks at depth i on path p                                  *)

op eligible (pool : blocks) (p : path) (i : int) : blocks =
  filter (fun (_ : vars) (b_vi : b_varinfo) =>
    node_is_on_path (node_at_depth p (to_depthd i)) b_vi.`b_path) pool.

(* ==================================================================== *)
(* Map subtraction: remove all keys present in m2 from m1                *)

op fmap_minus ['a 'b 'c] (m1 : ('a, 'b) fmap) (m2 : ('a, 'c) fmap)
  : ('a, 'b) fmap =
  filter (fun (x : 'a) (_ : 'b) => x \notin m2) m1.

(* ==================================================================== *)
(* Chosen blocks at depth i: at most K eligible blocks                   *)

op chosen (pool : blocks) (p : path) (i : int) : blocks =
  take_fmap K (eligible pool p i).

(* ==================================================================== *)
(* One step of the eviction fold                                         *)

op step (p : path) (i : int) (acc : blocks list * blocks)
  : blocks list * blocks =
  (chosen acc.`2 p i :: acc.`1, fmap_minus acc.`2 (chosen acc.`2 p i)).

(* ==================================================================== *)
(* Concrete assign implementation                                        *)
(*                                                                       *)
(* We use foldr on range 0 (h+1) = [0; 1; ...; h].                     *)
(* foldr processes the list right-to-left, so depth h is processed       *)
(* first (leaf), then h-1, ..., then 0 (root). This gives the greedy    *)
(* leaf-to-root eviction that satisfies the farthest property.           *)

op assign_impl (s : blocks) (p : path) : blocks list * blocks =
  foldr (step p) ([], s) (range 0 (h + 1)).

(* ==================================================================== *)
(* Basic properties of take_fmap                                         *)

lemma fdom_take_fmap ['a 'b] (k : int) (m : ('a, 'b) fmap) :
  fdom (take_fmap k m) = oflist (take k (elems (fdom m))).
proof.
rewrite fsetP => x; rewrite mem_fdom /take_fmap /=.
rewrite mem_filter mem_oflist /=.
split.
+ by move => [_]; rewrite mem_oflist.
+ move => Hx; rewrite mem_oflist Hx /=.
  have : x \in elems (fdom m) by apply (mem_take k).
  by rewrite -mem_oflist elemsK mem_fdom.
qed.

lemma take_fmap_sub ['a 'b] (k : int) (m : ('a, 'b) fmap) :
  forall x, x \in take_fmap k m => x \in m.
proof. by move => x; rewrite /take_fmap /= mem_filter. qed.

lemma take_fmap_get ['a 'b] (k : int) (m : ('a, 'b) fmap) (x : 'a) :
  x \in take_fmap k m => (take_fmap k m).[x] = m.[x].
proof. move => Hx; rewrite /take_fmap /=; by apply get_filter. qed.

lemma mem_take_fmap ['a 'b] (k : int) (m : ('a, 'b) fmap) (x : 'a) :
  x \in take_fmap k m <=> (x \in m /\ x \in oflist (take k (elems (fdom m)))).
proof. rewrite /take_fmap /= mem_filter /=; smt(mem_fdom mem_oflist). qed.

lemma fsize_take_fmap ['a 'b] (k : int) (m : ('a, 'b) fmap) :
  0 <= k => fsize (take_fmap k m) <= k.
proof.
move => Hk; rewrite /fsize fdom_take_fmap.
have Huniq : uniq (take k (elems (fdom m)))
  by apply uniq_take; apply uniq_elems.
rewrite uniq_card_oflist // size_take //.
smt(cardE size_ge0).
qed.

(* If x is in m but not in take_fmap k m, then take_fmap took exactly k *)
lemma take_fmap_full ['a 'b] (k : int) (m : ('a, 'b) fmap) (x : 'a) :
  0 <= k => x \in m => x \notin take_fmap k m =>
  fsize (take_fmap k m) = k.
proof.
move => Hk Hxm Hxnot.
rewrite /fsize fdom_take_fmap.
have Huniq : uniq (take k (elems (fdom m)))
  by apply uniq_take; apply uniq_elems.
rewrite uniq_card_oflist // size_take //.
have Hxe : x \in elems (fdom m).
+ have := mem_fdom m x; have := elemsK (fdom m); smt(mem_oflist).
have Hxnot2 : !(x \in take k (elems (fdom m))).
+ rewrite mem_take_fmap in Hxnot; smt(mem_oflist).
have Hlt : k < size (elems (fdom m)).
+ case (k < size (elems (fdom m))) => // Hnlt.
  by move: Hxnot2; rewrite take_oversize /#.
by rewrite Hlt.
qed.

(* ==================================================================== *)
(* Basic properties of fmap_minus                                        *)

lemma mem_fmap_minus ['a 'b 'c] (m1 : ('a, 'b) fmap) (m2 : ('a, 'c) fmap) x :
  x \in fmap_minus m1 m2 <=> (x \in m1 /\ x \notin m2).
proof. rewrite /fmap_minus mem_filter /=; smt(). qed.

lemma fmap_minus_get ['a 'b 'c] (m1 : ('a, 'b) fmap) (m2 : ('a, 'c) fmap) x :
  x \in fmap_minus m1 m2 => (fmap_minus m1 m2).[x] = m1.[x].
proof. move => Hx; rewrite /fmap_minus; by apply get_filter. qed.

(* ==================================================================== *)
(* Properties of eligible                                                *)

lemma eligible_get (pool : blocks) (p : path) (i : int) (x : vars) :
  x \in eligible pool p i => (eligible pool p i).[x] = pool.[x].
proof. move => Hx; rewrite /eligible; by apply get_filter. qed.

lemma eligible_sub (pool : blocks) (p : path) (i : int) (x : vars) :
  x \in eligible pool p i => x \in pool.
proof. by rewrite /eligible mem_filter; move => []. qed.

(* eligibility transfers to submaps with same values *)
lemma eligible_subpool (pool pool' : blocks) (p : path) (i : int) (x : vars) :
  x \in pool' => pool'.[x] = pool.[x] =>
  x \in eligible pool p i => x \in eligible pool' p i.
proof.
move => Hx' Hget Helig.
rewrite /eligible mem_filter /=; split => //.
rewrite /eligible mem_filter /= in Helig.
smt().
qed.

(* ==================================================================== *)
(* Properties of chosen                                                  *)

lemma chosen_sub (pool : blocks) (p : path) (i : int) :
  forall x, x \in chosen pool p i => x \in pool.
proof.
move => x Hx.
have Helig : x \in eligible pool p i
  by apply (take_fmap_sub K (eligible pool p i) x).
by rewrite /eligible mem_filter in Helig; move: Helig => [].
qed.

lemma chosen_get (pool : blocks) (p : path) (i : int) (x : vars) :
  x \in chosen pool p i => (chosen pool p i).[x] = pool.[x].
proof.
move => Hx; rewrite /chosen.
have Helig : x \in eligible pool p i
  by apply (take_fmap_sub K (eligible pool p i) x).
rewrite (take_fmap_get K (eligible pool p i) x) //.
by apply eligible_get.
qed.

(* all blocks in chosen satisfy the path predicate *)
lemma all_chosen_path (pool : blocks) (p : path) (i : int) :
  all (fun (_ : vars) (b_vi : b_varinfo) =>
    node_is_on_path (node_at_depth p (to_depthd i)) b_vi.`b_path)
    (chosen pool p i).
proof.
rewrite allP => x v Hxv.
have Hx : x \in chosen pool p i by smt(domE).
have Helig : x \in eligible pool p i
  by apply (take_fmap_sub K (eligible pool p i) x).
have [_ Hpath] : (x \in pool) /\
  node_is_on_path (node_at_depth p (to_depthd i)) (oget pool.[x]).`b_path
  by rewrite /eligible mem_filter /= in Helig.
have : (chosen pool p i).[x] = pool.[x] by apply chosen_get.
smt().
qed.

(* If x is eligible but not chosen, the chosen set is full *)
lemma chosen_full (pool : blocks) (p : path) (d : int) (x : vars) :
  x \in eligible pool p d =>
  x \notin chosen pool p d =>
  fsize (chosen pool p d) = K.
proof.
move => Helig Hnotchosen.
rewrite /chosen.
apply (take_fmap_full K (eligible pool p d) x _ Helig Hnotchosen).
smt(gt0_K).
qed.

(* ==================================================================== *)
(* blocks witness = empty                                                *)


(* ==================================================================== *)
(* Bridging nth empty / nth witness (list .[_] = nth witness)            *)

lemma nth_blocks (l : blocks list) (i : int) :
  0 <= i < size l => l.[i] = nth empty l i.
proof. by move => Hi; apply nth_change_dfl. qed.

(* ==================================================================== *)
(* Fold size lemma                                                       *)

lemma foldr_size_fst (p : path) (l : int list) (acc : blocks list * blocks) :
  size (foldr (step p) acc l).`1 = size l + size acc.`1.
proof.
elim: l acc => [| x xs IH] acc /=.
+ smt().
+ by rewrite /step /= IH /= /#.
qed.

(* ==================================================================== *)
(* Pool monotonicity: the pool only shrinks during the fold              *)

lemma foldr_pool_sub (p : path) (l : int list) (pool : blocks) (x : vars) :
  x \in (foldr (step p) ([], pool) l).`2 => x \in pool.
proof.
elim: l pool => [| d ds IH] pool //=.
(* foldr on d :: ds = step p d (foldr (step p) ([], pool) ds) *)
(* (step p d inner).`2 = fmap_minus inner.`2 (chosen inner.`2 p d) *)
pose inner := foldr (step p) ([], pool) ds.
rewrite /step /= -/inner => Hx.
(* Hx: x \in fmap_minus inner.`2 (chosen inner.`2 p d) *)
have [Hx_inner _] : x \in inner.`2 /\ x \notin chosen inner.`2 p d
  by rewrite mem_fmap_minus in Hx.
exact (IH pool Hx_inner).
qed.

(* Values are preserved in the pool *)
lemma foldr_pool_get (p : path) (l : int list) (pool : blocks) (x : vars) :
  x \in (foldr (step p) ([], pool) l).`2 =>
  (foldr (step p) ([], pool) l).`2.[x] = pool.[x].
proof.
elim: l pool => [| d ds IH] pool //=.
pose inner := foldr (step p) ([], pool) ds.
rewrite /step /= -/inner => Hx.
have Hx_inner : x \in inner.`2
  by rewrite mem_fmap_minus in Hx; smt().
have Hget := IH pool Hx_inner.
rewrite (fmap_minus_get inner.`2 (chosen inner.`2 p d) x Hx).
exact Hget.
qed.

(* ==================================================================== *)
(* Property 1: assign_length                                             *)

lemma assign_impl_length (s : blocks) (p : path) :
  size (assign_impl s p).`1 = h + 1.
proof.
rewrite /assign_impl foldr_size_fst /= size_range; smt(gt0_h).
qed.

(* ==================================================================== *)
(* Property 2: assign_partition (pointwise)                              *)

lemma foldr_partition_pointwise (p : path) (l : int list)
  (pool : blocks) (x : vars) :
  pool.[x] = (f_big_union ((foldr (step p) ([], pool) l).`2
                             :: (foldr (step p) ([], pool) l).`1)).[x].
proof.
elim: l pool => [| d ds IH] pool /=.
+ by rewrite f_big_union_cons f_big_union_nil joinE mem_empty.
+ have IHpool := IH pool.
  pose inner := foldr (step p) ([], pool) ds.
  rewrite /step /= -/inner !f_big_union_cons !joinE mem_join.
  rewrite IHpool f_big_union_cons joinE.
  case (x \in f_big_union inner.`1) => Hfu.
  + by smt(mem_join).
  + case (x \in chosen inner.`2 p d) => Hc.
    - rewrite chosen_get //; smt(mem_join).
    - smt(mem_fmap_minus fmap_minus_get domE).
qed.

lemma assign_impl_partition_core (s : blocks) (p : path) :
  f_big_union [s] = f_big_union ((assign_impl s p).`2 :: (assign_impl s p).`1).
proof.
rewrite /assign_impl f_big_union_cons f_big_union_nil join0r.
apply fmap_eqP => x.
exact (foldr_partition_pointwise p (range 0 (h + 1)) s x).
qed.

lemma assign_impl_partition (s : blocks) (p : path) :
  let (newnodes, newstash) = assign_impl s p in
    f_big_union [s] = f_big_union (newstash :: newnodes).
proof.
have := assign_impl_partition_core s p.
by case: (assign_impl s p).
qed.

(* ==================================================================== *)
(* Property 3: assign_disjoint                                           *)

lemma foldr_disjoint (p : path) (l : int list) (pool : blocks) :
  f_big_disjoint ((foldr (step p) ([], pool) l).`2
                   :: (foldr (step p) ([], pool) l).`1).
proof.
elim: l pool => [| d ds IH] pool /=.
+ by apply f_big_disjoint1.
+ pose inner := foldr (step p) ([], pool) ds.
  have IHinner := IH pool.
  (* result = (chosen inner.`2 p d :: inner.`1,
               fmap_minus inner.`2 (chosen inner.`2 p d)) *)
  (* The list is [fm; c; inner.`1[0]; inner.`1[1]; ...] *)
  (* where c = chosen inner.`2 p d, fm = fmap_minus inner.`2 c *)
  rewrite -/inner /step /= -/inner.
  pose c := chosen inner.`2 p d.
  pose fm := fmap_minus inner.`2 c.
  rewrite /f_big_disjoint => i j Hi Hj Hneq x Hx.
  case (i = 0) => Hi0.
  + subst i; rewrite /= -/fm in Hx.
    have [Hx_inner Hx_nc] : x \in inner.`2 /\ x \notin c
      by rewrite /fm mem_fmap_minus in Hx.
    case (j = 1) => Hj1.
    - by subst j; rewrite /=.
    - rewrite /= -/c.
      have Hj' : 0 <= j - 2 < size inner.`1 by smt(foldr_size_fst).
      have Hj'' : 0 <= j - 1 < size (inner.`2 :: inner.`1) by smt().
      have H0 : 0 <= 0 < size (inner.`2 :: inner.`1) by smt(size_ge0).
      have := IHinner 0 (j - 1) H0 Hj'' _ x Hx_inner; smt().
  + case (i = 1) => Hi1.
    - subst i; rewrite /= -/c in Hx.
      case (j = 0) => Hj0.
      * subst j; rewrite /= -/fm /fm mem_fmap_minus /c; smt().
      * have Hx_inner : x \in inner.`2 by apply (chosen_sub inner.`2 p d).
        rewrite /= -/c.
        have Hj' : 0 <= j - 1 < size (inner.`2 :: inner.`1) by smt().
        have H0 : 0 <= 0 < size (inner.`2 :: inner.`1) by smt(size_ge0).
        have := IHinner 0 (j - 1) H0 Hj' _ x Hx_inner; smt().
    - (* i >= 2: x in inner.`1[i-2] *)
      have Hi2 : 0 <= i - 2 by smt().
      case (j = 0) => Hj0.
      * subst j; rewrite /= -/fm /fm mem_fmap_minus.
        have Hi' : 0 <= i - 1 < size (inner.`2 :: inner.`1) by smt().
        have H0 : 0 <= 0 < size (inner.`2 :: inner.`1) by smt(size_ge0).
        have := IHinner (i - 1) 0 Hi' H0 _ x; smt().
      * case (j = 1) => Hj1.
        + subst j; rewrite /= -/c.
          case (x \in c) => // Hxc.
          have Hx_inner : x \in inner.`2 by apply (chosen_sub inner.`2 p d).
          have Hi' : 0 <= i - 1 < size (inner.`2 :: inner.`1) by smt().
          have H0 : 0 <= 0 < size (inner.`2 :: inner.`1) by smt(size_ge0).
          have := IHinner 0 (i - 1) H0 Hi' _ x Hx_inner; smt().
        + (* i >= 2, j >= 2: both in inner.`1 *)
          have Hi' : 0 <= i - 1 < size (inner.`2 :: inner.`1) by smt().
          have Hj' : 0 <= j - 1 < size (inner.`2 :: inner.`1) by smt().
          have := IHinner (i - 1) (j - 1) Hi' Hj' _ x; smt().
qed.

lemma assign_impl_disjoint_core (s : blocks) (p : path) :
  f_big_disjoint ((assign_impl s p).`2 :: (assign_impl s p).`1).
proof.
rewrite /assign_impl.
exact (foldr_disjoint p (range 0 (h + 1)) s).
qed.

lemma assign_impl_disjoint (s : blocks) (p : path) :
  let (newnodes, newstash) = assign_impl s p in
    f_big_disjoint (newstash :: newnodes).
proof.
have := assign_impl_disjoint_core s p.
by case: (assign_impl s p).
qed.

(* ==================================================================== *)
(* Property 4: assign_path                                               *)

lemma foldr_path (p : path) (l : int list) (pool : blocks) (k : int) :
  0 <= k < size l =>
  all (fun (_ : vars) (b_vi : b_varinfo) =>
    node_is_on_path (node_at_depth p (to_depthd (nth 0 l k))) b_vi.`b_path)
    (nth empty (foldr (step p) ([], pool) l).`1 k).
proof.
elim: l pool k => [| d ds IH] pool k //=.
+ smt(size_ge0).
+ pose inner := foldr (step p) ([], pool) ds.
  rewrite /step /= -/inner => Hk.
  case (k = 0) => Hk0.
  + subst k; rewrite /=.
    exact (all_chosen_path inner.`2 p d).
  + have Hk' : 0 <= k - 1 < size ds by smt().
    exact (IH pool (k - 1) Hk').
qed.

lemma assign_impl_path (s : blocks) (p : path) (i : int) :
  0 <= i <= h =>
  all (fun (_ : vars) (b_vi : b_varinfo) =>
    node_is_on_path (node_at_depth p (to_depthd i)) b_vi.`b_path)
    (assign_impl s p).`1.[i].
proof.
move => Hi.
have Hsz : size (assign_impl s p).`1 = h + 1 by apply assign_impl_length.
rewrite (nth_blocks _ i) 1:/# /assign_impl.
have Hk : 0 <= i < size (range 0 (h + 1)) by rewrite size_range /#.
have := foldr_path p (range 0 (h + 1)) s i Hk.
by rewrite nth_range /#.
qed.

(* ==================================================================== *)
(* Property 5: assign_farthest                                           *)
(*                                                                       *)
(* Key insight: foldr processes depths h, h-1, ..., 0 (right-to-left).  *)
(* If block x ends up in bucket i, it was in the pool when deeper        *)
(* buckets j > i were filled. If x was eligible at depth j but not       *)
(* chosen, then bucket j has exactly K blocks (it's full).               *)

(* Elements in the stash were not chosen at any step *)
lemma foldr_stash_notin_bucket (p : path) (l : int list)
  (pool : blocks) (x : vars) (k : int) :
  x \in (foldr (step p) ([], pool) l).`2 =>
  0 <= k < size l =>
  x \notin nth empty (foldr (step p) ([], pool) l).`1 k.
proof.
move => Hx Hk.
have Hdisj := foldr_disjoint p l pool.
have Hi : 0 <= 0 < size ((foldr (step p) ([], pool) l).`2
                           :: (foldr (step p) ([], pool) l).`1)
  by smt(size_ge0).
have Hj : 0 <= k + 1 < size ((foldr (step p) ([], pool) l).`2
                               :: (foldr (step p) ([], pool) l).`1)
  by rewrite /= foldr_size_fst /= /#.
have := Hdisj 0 (k + 1) Hi Hj _ x Hx; smt().
qed.

(* Elements in bucket i are also in the intermediate pool when deeper
   buckets were filled. More precisely: x in bucket i implies x was in
   the stash of the inner fold (which contains all the later buckets). *)
lemma foldr_bucket_in_inner_pool (p : path) (l : int list)
  (pool : blocks) (x : vars) (k : int) :
  0 <= k < size l =>
  x \in nth empty (foldr (step p) ([], pool) l).`1 k =>
  x \in (foldr (step p) ([], pool) l).`2 \/
  x \in nth empty (foldr (step p) ([], pool) l).`1 k.
proof.
by move => Hk Hx; right.
qed.

(* Stash-based farthest: for x in the stash and eligible at a depth,
   the corresponding bucket is full *)
lemma foldr_stash_farthest (p : path) (l : int list)
  (pool : blocks) (x : vars) (k : int) :
  x \in (foldr (step p) ([], pool) l).`2 =>
  0 <= k < size l =>
  x \in eligible (foldr (step p) ([], pool) l).`2 p (nth 0 l k) =>
  fsize (nth empty (foldr (step p) ([], pool) l).`1 k) = K.
proof.
elim: l pool k => [| d ds IH] pool k //=.
+ smt(size_ge0).
+ pose inner := foldr (step p) ([], pool) ds.
  rewrite -/inner /step /= -/inner => Hx Hk Helig.
  case (k = 0) => Hk0.
  + subst k; rewrite /= in Helig.
    have [Hx_inner Hx_nc] : x \in inner.`2 /\ x \notin chosen inner.`2 p d
      by rewrite mem_fmap_minus in Hx.
    have Hx_elig_inner : x \in eligible inner.`2 p d.
    + rewrite /eligible mem_filter /=; split => //.
      rewrite /eligible mem_filter /= in Helig.
      smt(fmap_minus_get mem_fmap_minus).
    have := chosen_full inner.`2 p d x Hx_elig_inner Hx_nc.
    smt().
  + have Hk' : 0 <= k - 1 < size ds by smt().
    have Hx_inner : x \in inner.`2
      by rewrite mem_fmap_minus in Hx; smt().
    have Hx_elig_inner : x \in eligible inner.`2 p (nth 0 ds (k - 1)).
    + rewrite /eligible mem_filter /=; split => //.
      have Helig' : node_is_on_path (node_at_depth p (to_depthd (nth 0 ds (k - 1))))
        (oget (fmap_minus inner.`2 (chosen inner.`2 p d)).[x]).`b_path.
      * rewrite /eligible mem_filter /= in Helig; smt().
      smt(fmap_minus_get mem_fmap_minus).
    have := IH pool (k-1) Hx_inner Hk' Hx_elig_inner.
    smt().
qed.

(* Core farthest lemma for the fold *)
lemma foldr_farthest (p : path) (l : int list) (pool : blocks)
  (i j : int) (x : vars) (v : b_varinfo) :
  0 <= i < size l => 0 <= j < size l => i < j =>
  (nth empty (foldr (step p) ([], pool) l).`1 i).[x] = Some v =>
  node_is_on_path (node_at_depth p (to_depthd (nth 0 l j))) v.`b_path =>
  fsize (nth empty (foldr (step p) ([], pool) l).`1 j) = K.
proof.
elim: l pool i j => [| d ds IH] pool i j //=.
+ smt(size_ge0).
+ pose inner := foldr (step p) ([], pool) ds.
  (* foldr (d :: ds) = step p d inner *)
  (* (step p d inner).`1 = chosen inner.`2 p d :: inner.`1 *)
  (* nth k of that is: k=0 → chosen inner.`2 p d, k>0 → nth (k-1) inner.`1 *)
  move => Hi Hj Hij.
  rewrite -/inner /step /= -/inner => Hxv Hpath.
  case (i = 0) => Hi0; case (j = 0) => Hj0.
  + (* i = 0, j = 0: impossible since i < j *)
    by smt().
  + (* i = 0, j > 0 *)
    subst i; rewrite /= in Hxv.
    have Hpath' : node_is_on_path (node_at_depth p (to_depthd (nth 0 ds (j - 1)))) v.`b_path by smt().
    clear Hpath.
    have Hx_chosen : x \in chosen inner.`2 p d by smt(domE).
    have Hx_inner : x \in inner.`2 by apply (chosen_sub inner.`2 p d).
    have Hv_eq : (chosen inner.`2 p d).[x] = inner.`2.[x]
      by apply chosen_get.
    have Hj' : 0 <= j - 1 < size ds by smt().
    have Hx_elig : x \in eligible inner.`2 p (nth 0 ds (j - 1)).
    + rewrite /eligible mem_filter /=; split => //.
      have : inner.`2.[x] = Some v by smt().
      smt().
    have := foldr_stash_farthest p ds pool x (j-1) Hx_inner Hj' Hx_elig.
    smt().
  + (* i > 0, j = 0: impossible since i < j *)
    by smt().
  + (* i > 0, j > 0 *)
    have Hxv' : (nth empty inner.`1 (i - 1)).[x] = Some v by smt().
    have Hpath' : node_is_on_path (node_at_depth p (to_depthd (nth 0 ds (j - 1)))) v.`b_path by smt().
    have Hi' : 0 <= i - 1 < size ds by smt().
    have Hj' : 0 <= j - 1 < size ds by smt().
    have Hij' : i - 1 < j - 1 by smt().
    have := IH pool (i-1) (j-1) Hi' Hj' Hij' Hxv' Hpath'.
    smt().
qed.

lemma assign_impl_farthest (s : blocks) (p : path) (i : int) :
  0 <= i <= h =>
  all
    (fun (_ : vars) (b_vi : b_varinfo) =>
      forall j, i < j <= h =>
        node_is_on_path
          (node_at_depth p (to_depthd j))
          b_vi.`b_path =>
        fsize (assign_impl s p).`1.[j] = K)
    (assign_impl s p).`1.[i].
proof.
move => Hi; rewrite allP => x v Hxv j Hj Hpath.
have Hassign_sz : size (assign_impl s p).`1 = h + 1 by apply assign_impl_length.
have Hsz : size (range 0 (h + 1)) = h + 1 by rewrite size_range /#.
have Hi' : 0 <= i < size (range 0 (h + 1)) by rewrite Hsz /#.
have Hj' : 0 <= j < size (range 0 (h + 1)) by rewrite Hsz /#.
have Hnth_j : nth 0 (range 0 (h + 1)) j = j by rewrite nth_range /#.
have Hij : i < j by smt().
rewrite (nth_blocks _ j) 1:/# /assign_impl.
have Hxv' : (nth empty (foldr (step p) ([], s) (range 0 (h + 1))).`1 i).[x] = Some v.
+ by rewrite -(nth_blocks _ i) 1:/#.
have Hpath' : node_is_on_path (node_at_depth p (to_depthd (nth 0 (range 0 (h + 1)) j))) v.`b_path
  by rewrite Hnth_j.
exact (foldr_farthest p (range 0 (h + 1)) s i j x v Hi' Hj' Hij Hxv' Hpath').
qed.
