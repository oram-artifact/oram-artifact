require import AllCore List FSet FMap Distr DList Real.

require import ORAM.
require import PathORAM.

require import RAM PathObliviousness PathAbstracting.

require import Aux.
(*---*) import ListUtils FMapUtils.

require import StdOrder.
(*---*) import RealOrder.

(*******************************************************************************)
(*******************************************************************************)
(************                     Bounded ORAM                     *************)
(*******************************************************************************)
(*******************************************************************************)

module ORAMBounded = {
  include var PathORAM [-access,compile]

  proc access(oram : oram, inst : inst) : oram * value = {
    var val : value;

    val <- witness;

    if (!toverflow PathORAM.os) {
      (oram, val) <@ PathORAM.access(oram, inst);
    }

    return (oram, val);
  }

  proc compile(p : prog) : value list = {
    var i : int;
    var o : oram;
    var val : value;
    var vs : value list;

    PathORAM.leakages <- [];
    o <- FMap.empty;
    vs <- [];
    PathORAM.os <- [];

    i <- 0;
    while (i < size p) {
      (o, val) <@ access(o, p.[i]);
      os <- o :: PathORAM.os;
      vs <- val :: vs;
      i <- i + 1;
    }
    return vs;
  }
}.

(*******************************************************************************)
(*******************************************************************************)
(************              Security statement and proof            *************)
(*******************************************************************************)
(*******************************************************************************)

module type Dist_t = {
   proc find() : prog * prog
   proc dist(l : leakage list) : bool
}.

module type ORAM_t = {
  proc compile(p : prog) : value list
  proc get_leakages() : leakage list
}.

module ORAM_IND(O : ORAM_t,  D : Dist_t) = {
   proc main(b : bool) : bool = {
      var ps,l,b';
      b' <- false;
      PathORAM.os <- [];
      ps <@ D.find();
      if (size ps.`1 = size ps.`2) {
         O.compile(if b then ps.`1 else ps.`2);
         l <@ O.get_leakages();
         b' <@ D.dist(l);
      }
      return b';
   }
}.

op expandl(ap : sleakage) : leakage =
      map (fun i => (Write, node_at_depth ap (to_depthd i))) (iota_ 0 (h+1))
   ++ map (fun i => (Read, node_at_depth ap (to_depthd i))) (rev (iota_ 0 (h+1))).

op lsim(al : sleakage list) : leakage list =
        (map expandl al).

module LSim(A : Dist_t) = {
   proc find() : prog * prog = {
       var ps;
       ps <@ A.find();
       return ps;
   }

   proc dist(al : sleakage list) : bool = {
       var b;
       b <@ A.dist(lsim al);
       return b;
   }
}.

lemma PathORAM_access_ll : islossless PathORAM.access.
proof.
proc; wp.
while (-1 <= i <= h) (i + 1); first by auto => />; smt(gt0_h).
wp.
while (0 <= i <= h + 1) (h + 1 - i); first by auto => />; smt(gt0_h).
wp; rnd; wp; rnd.
by auto => />; smt(UniPath.dunipath_ll gt0_h).
qed.

(* Extracted equiv: ORAMBounded and PathORAM agree up to overflow *)
lemma compile_upto_bad :
  equiv [PathORAM.compile ~ ORAMBounded.compile :
    ={arg} ==>
    (toverflow PathORAM.os{1} <=> toverflow PathORAM.os{2}) /\
    (!toverflow PathORAM.os{2} => ={res, glob PathORAM})].
proof.
proc.
conseq (: (toverflow PathORAM.os{1} <=> toverflow PathORAM.os{2}) /\
          ((!toverflow PathORAM.os{2}) => ={o, vs, glob PathORAM})); 1: by smt().
while (#post /\ ={i,p} /\
     (! toverflow PathORAM.os{2} => ={o, vs})); last by auto.
wp; inline {2} 1.
swap {2} 3 -2; seq 0 1 : #pre; 1: by auto.
sp; if{2}; last first.
+ wp.
  call {1} (: true ==> true).
  + by apply PathORAM_access_ll.
  by auto => /> /#.
+ wp; call (: ={arg, glob PathORAM} ==> ={res, glob PathORAM}).
  + by sim.
  by auto => /> /#.
qed.

section.

declare module A <: Dist_t {-SecurePathORAM, -PathORAM, -ORAMBounded, -TapeSecurePathORAM, -TapePathORAM, -RO, -LRO}.
declare axiom A_ll : islossless A.dist.
declare axiom A_find_ll : islossless A.find.

(* Security abstraction: PathORAM produces the same leakage as SecurePathORAM *)
lemma security_abstraction &m _b :
   Pr [ ORAM_IND(PathORAM,A).main(_b) @ &m : res ] =
     Pr [ AORAM_IND(SecurePathORAM,LSim(A)).main(_b) @ &m : res].
proof.
byequiv => //.
proc.
inline LSim(A).find LSim(A).dist.
(* Align initial setup *)
seq 3 3 : (={b, glob A, ps, b'}).
+ by wp; call (:true); wp; auto.
if; 1,3: by auto.
(* Inside if: compile + get_leakages + dist *)
seq 2 2 : (={glob A} /\ l{1} = lsim l{2}).
+ inline PathORAM.get_leakages SecurePathORAM.get_leakages; wp.
  ecall (equiv_security_compile (if b then ps.`1 else ps.`2){1}); 1: by auto.
(* b' <@ A.dist(l{1}) vs b' <@ A.dist(lsim l{2}): same since l{1} = lsim l{2} *)
wp; call (:true); auto => /> /#.
qed.

lemma security_up_to_bad &m :
   `| Pr [ ORAM_IND(ORAMBounded,A).main(true) @ &m : res ] -
        Pr [ ORAM_IND(ORAMBounded,A).main(false) @ &m : res ] | <=
             Pr [ ORAM_IND(PathORAM,A).main(true) @ &m : toverflow PathORAM.os ] +
             Pr [ ORAM_IND(PathORAM,A).main(false) @ &m : toverflow PathORAM.os ].
proof.
(* Step 1: For each b, |Pr[Bounded,b] - Pr[PathORAM,b]| <= Pr[PathORAM,b : toverflow] *)
have Hbad : forall b,
  `| Pr [ ORAM_IND(ORAMBounded,A).main(b) @ &m : res ] -
              Pr [ ORAM_IND(PathORAM,A).main(b) @ &m : res ] | <=
       Pr [ ORAM_IND(PathORAM,A).main(b) @ &m : toverflow PathORAM.os ].
+ move => b0.
  byequiv : (toverflow (PathORAM.os)) => //; last by smt().
  proc => //.
  seq 3 3 : (={glob A, b, b', ps, PathORAM.os}); 1: by wp; call(:true); auto.
  if; 1,3: by auto.
  call(: toverflow PathORAM.os, ={glob PathORAM}, true); 1: by apply A_ll.
  inline {1} 2; inline {2} 2; wp.
  symmetry; call compile_upto_bad; auto; smt().
(* Step 2: PathORAM is perfectly secure via security_abstraction + abstract_security *)
have Habs := security_abstraction &m.
have Hsec := abstract_security (LSim(A)) _ &m.
+ by proc; call A_ll; auto.
(* Combine: triangle inequality *)
have := Hbad true; have := Hbad false.
by rewrite (Habs true) (Habs false) /#.
qed.

lemma main_security &m :
  `| Pr [ ORAM_IND(ORAMBounded,A).main(true) @ &m : res ] -
        Pr [ ORAM_IND(ORAMBounded,A).main(false) @ &m : res ] | <=
             2%r * 14%r * (3%r / 5%r) ^ R.
proof.
have := security_up_to_bad &m.
pose pr := 14%r * (3%r / 5%r) ^ R.
have ? : 0%r < pr by smt(RealOrder.expr_gt0).
suff : forall b, Pr [ ORAM_IND(PathORAM,A).main(b) @ &m : toverflow PathORAM.os ] <= pr by smt().
move => _b.
byphoare (: arg = _b ==> _) => /=; 2,3: by auto.
proc.
(* TODO: try to understand what this `seq` is doing. *)
seq 3 : (PathORAM.os = [] /\ b = _b) (pr) => /=.
+ by auto.
+ conseq (: _ ==> _ : =1%r) => /=; 1: by smt(RField.mulVf).
  by call (A_find_ll); auto => />.
+ if; last first.
  + hoare.
    + by smt().
    + by auto.
  seq 1 : (toverflow PathORAM.os) (pr) (1%r) (1%r - pr) (0%r).
  + by auto.
  + exlim ps => _ps.
    call(: arg = (if _b then _ps.`1 else _ps.`2)
        /\ PathORAM.os = []
        /\ size _ps.`1 = size _ps.`2
       ==> toverflow PathORAM.os).
    + by bypr; smt(overflow_bound).
    by auto.
  + by auto.
  + by conseq |>; auto.
  + by smt().
+ by conseq />; hoare; call (:true); auto.
+ by smt().
qed.

(*******************************************************************************)
(*******************************************************************************)
(************            Correctness statement and proof           *************)
(*******************************************************************************)
(*******************************************************************************)

section Correctness.

declare module D <: CDist_t {-PathORAM, -ORAMBounded, -RAM}.
declare axiom D_ll : islossless D.dist.

lemma correctness_upto_bad &m _p :
  well_formed_prog _p =>
  `| Pr [ CORRECT_IND(ORAMBounded, D).main(_p) @ &m : res ] -
     Pr [ CORRECT_IND(RAM, D).main(_p) @ &m : res ] | <=
        Pr [ PathORAM.compile(_p) @ &m : toverflow PathORAM.os ].
proof.
move => Hwf.
(* Step 1: PathORAM = RAM exactly, so D can't distinguish them *)
have Heq : Pr[CORRECT_IND(PathORAM, D).main(_p) @ &m : res]
         = Pr[CORRECT_IND(RAM, D).main(_p) @ &m : res].
+ byequiv => //; proc.
  seq 1 1 : (={vs, glob D}); last by call (: true).
  by call (equiv_correct_compile _p Hwf); auto.
(* Step 2: ORAMBounded vs PathORAM up to bad *)
have Hbad :
  `| Pr [ CORRECT_IND(ORAMBounded, D).main(_p) @ &m : res ] -
     Pr [ CORRECT_IND(PathORAM, D).main(_p) @ &m : res ] | <=
  Pr [ CORRECT_IND(PathORAM, D).main(_p) @ &m : toverflow PathORAM.os ].
+ byequiv : (toverflow (PathORAM.os)) => //.
  + symmetry; proc.
    call(: toverflow PathORAM.os, ={glob PathORAM}, true); 1: by apply D_ll.
    call compile_upto_bad; auto.
  + by smt().
  by smt().
(* Step 3: connect bad event to PathORAM.compile *)
have Hbad_eq : Pr[CORRECT_IND(PathORAM, D).main(_p) @ &m : toverflow PathORAM.os]
             = Pr[PathORAM.compile(_p) @ &m : toverflow PathORAM.os].
+ byequiv => //.
  + proc; call {1} D_ll; inline PathORAM.compile; sim.
rewrite -Heq; smt().
qed.

lemma main_correctness &m _p :
  well_formed_prog _p =>
  `| Pr [ CORRECT_IND(ORAMBounded, D).main(_p) @ &m : res ] -
     Pr [ CORRECT_IND(RAM, D).main(_p) @ &m : res ] | <=
        14%r * (3%r / 5%r) ^ R.
proof.
move => Hwf.
have := correctness_upto_bad &m _p Hwf.
by smt(overflow_bound).
qed.

end section Correctness.
