require import AllCore Bool List IntDiv FMap FSet SmtMap.
require import Distr DList.

require import ORAM.
require import PathORAM PathObliviousness.
(*---*) import UniPath.

require import RAM.

require import Aux.
(*---*) import ListUtils FMapUtils.

op varinfo2value (v : vars) (vi : varinfo) : value = vi.`value.

op t_varinfo2value (v : vars) (t_vi : t_varinfo) : value = t_vi.`t_value.

op b_varinfo2value (v : vars) (b_vi : b_varinfo) : value = b_vi.`b_value.

(* ================================================================ *)
(* b_varinfo-level lemmas: cast tree/oram entries to b_varinfo      *)
(* These are more general than the value-level lemmas below.        *)
(* ================================================================ *)

op t2b_map (t : tree) : blocks = FMap.map (fun (_ : vars) (t_vi : t_varinfo) => t2b_varinfo t_vi) t.

lemma setblocks_t2b (t : tree) (n : node) (bs : blocks) :
  all (fun (_ : vars) (b_vi : b_varinfo) => node_is_on_path n b_vi.`b_path) bs =>
  t2b_map (setblocks t n bs) = bs + t2b_map t.
proof.
move => Hvalid; rewrite /t2b_map /setblocks Hvalid /= map_join map_map; congr.
rewrite -fmap_eqP => v; rewrite !mapE /=.
by case (bs.[v]) => //= /#.
qed.

lemma fetch_t2b (s : blocks) (t : tree) (n : node) :
    t2b_map (fetch s t n).`2 + (fetch s t n).`1
  = t2b_map t + s.
proof.
have -> : (fetch s t n).`1 = fetch_stash s t n by rewrite /fetch.
have -> : (fetch s t n).`2 = FMap.filter (fun (_ : vars) (t_vi : t_varinfo) => node_of_t_varinfo t_vi <> n) t by rewrite /fetch.
(* First show: t2b_map t + fetch_stash s t n = t2b_map t + s *)
have Hfs : t2b_map t + fetch_stash s t n = t2b_map t + s.
+ rewrite /fetch_stash /t2b_map -joinA; congr.
  (* A + B = A when B is a filtered subset of A (right-biased join) *)
  rewrite -fmap_eqP => v.
  by rewrite joinE mem_map mem_filter /= !mapE filterE /= /#.
(* Now pointwise: t2b_map(filter(≠n,t)) + fetch_stash = t2b_map t + s *)
rewrite -fmap_eqP => v.
have Hfsv : (t2b_map t + fetch_stash s t n).[v] = (t2b_map t + s).[v] by rewrite Hfs.
move: Hfsv; rewrite /t2b_map !joinE.
case (v \in fetch_stash s t n) => Hvfs /=.
+ done.
+ have -> /= : !(v \in s) by smt(mem_map mem_join).
  case (v \in t) => Hvt.
  - have Hnn : node_of_t_varinfo (oget t.[v]) <> n by smt(mem_map mem_filter mem_join).
    have Hvf : v \in filter (fun (_ : vars) (t_vi : t_varinfo) => node_of_t_varinfo t_vi <> n) t
      by smt(mem_filter domE oget_some).
    by rewrite !mapE FMap.filterE; smt(domE oget_some).
  - smt(mapE mem_map mem_filter domE).
qed.

lemma fetch_t2b_disjoint (s : blocks) (t : tree) (n : node) :
  f_big_disjoint [t2b_map t; s] =>
  f_big_disjoint [t2b_map (fetch s t n).`2; (fetch s t n).`1].
proof.
have -> : (fetch s t n).`1 = fetch_stash s t n by rewrite /fetch.
have -> : (fetch s t n).`2 = FMap.filter (fun (_ : vars) (t_vi : t_varinfo) => node_of_t_varinfo t_vi <> n) t by rewrite /fetch.
rewrite /f_big_disjoint /= /t2b_map => Hdisj.
have Htree_sub : forall x, x \in map (fun (_ : vars) (t_vi : t_varinfo) => t2b_varinfo t_vi)
    (filter (fun (_ : vars) (t_vi : t_varinfo) => node_of_t_varinfo t_vi <> n) t)
  => x \in map (fun (_ : vars) (t_vi : t_varinfo) => t2b_varinfo t_vi) t
  by move => x; smt(mem_map mem_filter).
have Hfs_mem : forall x, x \in fetch_stash s t n
  => x \in s \/ x \in filter (fun (_ : vars) (t_vi : t_varinfo) => node_of_t_varinfo t_vi = n) t
  by move => x; smt(mem_join mem_filter mem_map).
have Hdisj01 : forall x, x \in map (fun (_ : vars) (t_vi : t_varinfo) => t2b_varinfo t_vi) t => x \notin s
  by move => x; have /= := Hdisj 0 1; smt().
smt(mem_map mem_filter domE oget_some).
qed.

lemma oram_split_t2b (o : oram) :
  t2b_map (map (fun (_ : vars) (vi : varinfo) => varinfo2t vi)
              (filter (fun (_ : vars) (vi : varinfo) => vi.`odepth <> None) o))
  + map (fun (_ : vars) (vi : varinfo) => varinfo2b vi)
      (filter (fun (_ : vars) (vi : varinfo) => vi.`odepth = None) o)
  = map (fun (_ : vars) (vi : varinfo) => varinfo2b vi) o.
proof.
rewrite /t2b_map map_map -fmap_eqP => v.
by rewrite joinE !mapE !filterE /= mem_map mem_filter /#.
qed.

(* ================================================================ *)
(* Value-level lemmas: derived from b_varinfo-level via             *)
(* map b_varinfo2value (preserves domains, so disjointness too)     *)
(* ================================================================ *)

(* Key relationship: t_varinfo2value = b_varinfo2value ∘ t2b_varinfo *)
lemma tv2v_eq_bv2v_t2b (v : vars) (t_vi : t_varinfo) :
  t_varinfo2value v t_vi = b_varinfo2value v (t2b_varinfo t_vi).
proof. by rewrite /t_varinfo2value /b_varinfo2value /t2b_varinfo. qed.

lemma t_val_map_eq (t : tree) :
  map t_varinfo2value t = map b_varinfo2value (t2b_map t).
proof.
rewrite /t2b_map map_map -fmap_eqP => v; rewrite !mapE.
by case (t.[v]) => //= tvi; rewrite tv2v_eq_bv2v_t2b.
qed.

(* fetch preserves combined values — corollary of fetch_t2b *)
lemma fetch_values (s : blocks) (t : tree) (n : node) :
    map t_varinfo2value (fetch s t n).`2 + map b_varinfo2value (fetch s t n).`1
    = map t_varinfo2value t + map b_varinfo2value s.
proof.
rewrite !t_val_map_eq -!map_join; congr.
exact (fetch_t2b s t n).
qed.

(* fetch preserves disjointness — corollary of fetch_t2b_disjoint *)
lemma fetch_disjoint (s : blocks) (t : tree) (n : node) :
    f_big_disjoint [map t_varinfo2value t; map b_varinfo2value s] =>
    f_big_disjoint [map t_varinfo2value (fetch s t n).`2;
                    map b_varinfo2value (fetch s t n).`1].
proof.
rewrite !t_val_map_eq /f_big_disjoint /= => Hdisj.
have := fetch_t2b_disjoint s t n _.
+ by rewrite /f_big_disjoint /=; smt(mem_map).
by rewrite /f_big_disjoint /=; smt(mem_map).
qed.

(* setblocks values decomposition — corollary of setblocks_t2b *)
lemma setblocks_values (t : tree) (n : node) (bs : blocks) :
  all (fun (_ : vars) (b_vi : b_varinfo) => node_is_on_path n b_vi.`b_path) bs =>
  map t_varinfo2value (setblocks t n bs) = map b_varinfo2value bs + map t_varinfo2value t.
proof.
by move => Hvalid; rewrite !t_val_map_eq -map_join setblocks_t2b.
qed.

(* oram split preserves values — corollary of oram_split_t2b *)
lemma oram_split_values (o : oram) :
  map t_varinfo2value
    (map (fun (_ : vars) (vi : varinfo) => varinfo2t vi)
       (filter (fun (_ : vars) (vi : varinfo) => vi.`odepth <> None) o))
  + map b_varinfo2value
      (map (fun (_ : vars) (vi : varinfo) => varinfo2b vi)
         (filter (fun (_ : vars) (vi : varinfo) => vi.`odepth = None) o))
  = map varinfo2value o.
proof.
rewrite t_val_map_eq -map_join oram_split_t2b.
rewrite -fmap_eqP => v; rewrite !mapE.
by case (o.[v]) => //= vi; rewrite /b_varinfo2value /varinfo2b /varinfo2value.
qed.

(* assign preserves value union *)
lemma assign_values_partition (s : blocks) (p : path) :
  map b_varinfo2value s =
  map b_varinfo2value (assign s p).`2
    + f_big_union (List.map (map b_varinfo2value) (assign s p).`1).
proof.
rewrite -map_f_big_union -map_join; congr.
smt(assign_partition f_big_union_cons f_big_union_nil join0r).
qed.

(* assign preserves value disjointness *)
lemma assign_values_disjoint (s : blocks) (p : path) :
    f_big_disjoint (
      map b_varinfo2value (assign s p).`2 ::
      List.map (map b_varinfo2value) (assign s p).`1).
proof.
have Hdisj : f_big_disjoint ((assign s p).`2 :: (assign s p).`1)
  by smt(assign_disjoint).
rewrite /f_big_disjoint /= size_map => i j Hi Hj Hne x.
case (i = 0) => Hi0; case (j = 0) => Hj0; subst => /=.
+ by smt().
+ rewrite (nth_map empty) 1:/#; smt(mem_map).
+ rewrite (nth_map empty) 1:/#; smt(mem_map).
+ rewrite !(nth_map empty) 1:/# 1:/#; smt(mem_map).
qed.

(* reconstructing oram from tree+stash preserves values *)
lemma oram_reconstruct_values (t : tree) (s : blocks) :
  map varinfo2value
    (map (fun (_ : vars) (t_vi : t_varinfo) => t2varinfo t_vi) t
   + map (fun (_ : vars) (b_vi : b_varinfo) => b2varinfo b_vi) s)
  = map t_varinfo2value t + map b_varinfo2value s.
proof.
rewrite -fmap_eqP => v; rewrite joinE mapE !mem_map joinE !mem_map.
case (v \in s) => Hs.
+ have [bvi Hbvi] : exists bvi, s.[v] = Some bvi by smt(domE).
  rewrite /= !mapE Hbvi /=.
  by rewrite /varinfo2value /b2varinfo /b_varinfo2value.
+ case (v \in t) => Ht.
  - have [tvi Htvi] : exists tvi, t.[v] = Some tvi by smt(domE).
    rewrite !mapE Htvi /= /varinfo2value /t2varinfo /t_varinfo2value //.
  - have Ht' : t.[v] = None by smt(domE).
    by rewrite !mapE Ht'.
qed.

(* Helper: if tree⊥stash and v∉tree, then tree⊥stash.[v<-data] *)
(* and therefore tree⊥each assign output of stash.[v<-data] *)
lemma eviction_init_disjoint (tv : (vars, value) fmap) (s : blocks)
    (v : vars) (bvi : b_varinfo) (p0 : path) :
    f_big_disjoint [tv; map b_varinfo2value s] =>
    !(v \in tv) =>
    f_big_disjoint (tv
      :: map b_varinfo2value (assign (s.[v <- bvi]) p0).`2
      :: List.map (map b_varinfo2value) (assign (s.[v <- bvi]) p0).`1).
proof.
move => Hdisj Hvnin.
have Htv_s_set : forall x, x \in tv => !(x \in map b_varinfo2value (s.[v <- bvi])).
+ move => x Hx; rewrite mem_map mem_set.
  by have /= := Hdisj 0 1 _ _ _ x; smt(mem_map).
have Hassign_disj := assign_values_disjoint (s.[v <- bvi]) p0.
rewrite /f_big_disjoint /= size_map => i j Hi Hj Hne x Hx.
case (i = 0) => Hi0; last case (j = 0) => Hj0.
+ subst; move: Hx => /= Hx.
  have Hxns : !(x \in map b_varinfo2value (s.[v <- bvi]))
    by exact (Htv_s_set x Hx).
  have Hxpart := assign_values_partition (s.[v <- bvi]) p0.
  case (j = 1) => Hj1; subst => /=.
  - by smt(mem_map mem_join).
  - have Hxnfu : !(x \in f_big_union (List.map (map b_varinfo2value) (assign (s.[v <- bvi]) p0).`1))
      by smt(mem_join).
    smt(f_big_union_notin_nth nth_map size_map).
+ subst; move: Hx.
  case (i = 1) => Hi1; subst => /=.
  - move => Hx.
    have : x \in map b_varinfo2value (s.[v <- bvi])
      by smt(assign_values_partition mem_map mem_join).
    smt().
  - rewrite (nth_map empty) 1:/# => Hx.
    have Hxfu : x \in f_big_union (List.map (map b_varinfo2value) (assign (s.[v <- bvi]) p0).`1)
      by apply (f_big_union_mem_nth _ x (i-2)); smt(size_map nth_map).
    have Hxs : x \in map b_varinfo2value (s.[v <- bvi])
      by smt(mem_join assign_values_partition).
    smt().
+ have /= := Hassign_disj (i-1) (j-1) _ _ _ x; smt(nth_map size_map mem_map).
qed.

(* TODO [low priority]: the proof for read-case and write-case are quite the same,
                        probably they're worth merging. *)
lemma equiv_correct_compile (p : prog) :
  well_formed_prog p =>
    equiv[ PathORAM.compile ~ RAM.compile :
                 arg{1} = p
              /\ arg{2} = p
             ==> res{1} = res{2}
         ].
proof.
move => @/well_formed_prog Hprog.
proc.
while (={i}
   /\ 0 <= i{1} <= size p
   /\ p{!1} = p
   /\ prog{2} = p
   /\ vs{1} = results{2}
   /\ map varinfo2value o{1} = RAM.mem{2}
   /\ (forall j, 0 <= j < i{1} => isWt p.[j] => varV p.[j] \in RAM.mem{2})
).
+ inline PathORAM.access RAM.step.
  wp 21 2.
  sp 2 1.
  match{2}.
  + (* read *)
    wp.
    (* eviction loop: processes i0 from h down to -1 *)
    while{1} (-1 <= i0{1} <= h
           /\ size newnodes{1} = h + 1
           /\ (f_big_union (
                    (map t_varinfo2value tree{1})
                 :: (map b_varinfo2value stash{1})
                 :: (map (fun blocks => map b_varinfo2value blocks)
                                (take (i0{1} + 1) newnodes{1}))))
             = RAM.mem{2}
           /\ f_big_disjoint (
                   (map t_varinfo2value tree{1})
                :: (map b_varinfo2value stash{1})
                :: (map (fun blocks => map b_varinfo2value blocks)
                                           (take (i0{1} + 1) newnodes{1})))
           /\ (forall j, 0 <= j <= h =>
                 all (fun (_ : vars) (bvi : b_varinfo) =>
                   node_is_on_path (node_at_depth p0{1} (to_depthd j)) bvi.`b_path)
                   newnodes{1}.[j])
    ) (i0{1} + 1).
    + move => &m z.
      auto => |> &hr Hi0lo Hi0hi Hsz Hdisj Hvalid Hi0ge0.
      rewrite (setblocks_values _ _ _ (Hvalid i0{hr} _)) 1:/#.
      have Htake := take_succ_snoc newnodes{hr} i0{hr} _; 1: by smt().
      move: Hdisj; rewrite !Htake map_cat map1 => Hdisj.
      split; 2: by smt().
      split; 1: by smt().

      move : Hdisj => ^Hdisj'.
      rewrite {1}/f_big_disjoint /= size_cat /= size_map size_takel 1:/# => Hdisj.

      have ? : forall v, v \notin (map t_varinfo2value tree{hr})
                      \/ v \notin (map b_varinfo2value stash{hr}).
      + by move => v; have /= /# := Hdisj 0 1.

      have ? : forall v, v \notin (map t_varinfo2value tree{hr})
                      \/ v \notin (map b_varinfo2value newnodes{hr}.[i0{hr}]).
      + move => v; have /= := Hdisj 0 (2 + i0{hr}).
        by rewrite nth_cat size_map size_takel /#.

      have ? : forall v, v \notin (map t_varinfo2value tree{hr})
                      \/ v \notin (f_big_union (map (map b_varinfo2value)
                                                    (take i0{hr} newnodes{hr}))).
      + move => v; case (v \in map t_varinfo2value tree{hr}) => // Hv.
        right; have := f_big_union_notin_head _ _ v Hdisj' Hv.
        by rewrite f_big_union_cons mem_join f_big_union_cat f_big_union_cons f_big_union_nil join0r mem_join; smt().

      have ? : forall v, v \notin (map b_varinfo2value stash{hr})
                      \/ v \notin (map b_varinfo2value newnodes{hr}.[i0{hr}]).
      + move => v; have /= := Hdisj 1 (2 + i0{hr}).
        by rewrite nth_cat size_map size_takel /#.

      have ? : forall v, v \notin (map b_varinfo2value stash{hr})
                      \/ v \notin (f_big_union (map (map b_varinfo2value)
                                                    (take i0{hr} newnodes{hr}))).
      + move => v; case (v \in map b_varinfo2value stash{hr}) => // Hv.
        right; have := f_big_union_notin_head _ _ v (f_big_disjoint_cons _ _ Hdisj') Hv.
        by rewrite f_big_union_cat f_big_union_cons f_big_union_nil join0r mem_join; smt().

      have ? : forall v, v \notin (map b_varinfo2value newnodes{hr}.[i0{hr}])
                      \/ v \notin (f_big_union (map (map b_varinfo2value)
                                                    (take i0{hr} newnodes{hr}))).
      + move => v; case (v \in map b_varinfo2value newnodes{hr}.[i0{hr}]) => // Hv.
        right.
        have Hd2 := f_big_disjoint_cons _ _ (f_big_disjoint_cons _ _ Hdisj').
        (* Hd2 : f_big_disjoint (take_maps ++ [bv nn.[i0]]) *)
        (* permute to [bv nn.[i0]] ++ take_maps, then use f_big_union_notin_head *)
        have Hd2p : f_big_disjoint (map b_varinfo2value newnodes{hr}.[i0{hr}] :: map (map b_varinfo2value) (take i0{hr} newnodes{hr})).
        + rewrite -(cat1s (map b_varinfo2value newnodes{hr}.[i0{hr}])).
          rewrite (f_big_disjoint_perm_eq _
                    (map (map b_varinfo2value) (take i0{hr} newnodes{hr})
                     ++ [map b_varinfo2value newnodes{hr}.[i0{hr}]])).
          + exact perm_catC.
          exact Hd2.
        exact (f_big_union_notin_head _ _ v Hd2p Hv).

      pose S := map b_varinfo2value stash{hr}.
      pose NN := map (map b_varinfo2value) (take i0{hr} newnodes{hr}).
      pose NNI := map b_varinfo2value newnodes{hr}.[i0{hr}].
      pose T := map t_varinfo2value tree{hr}.

      split.
      + by smt(joinA f_big_union_cons f_big_union2 cat11 f_big_union_cat
               f_big_union1 joinC FMap.mem_join).
      + rewrite /f_big_disjoint /= size_map size_takel 1:/#.
        move => i1 j Hi1 Hj Hne x Hx.
        case: (i1 = 0) => Hi10; case: (j = 0) => Hj0; subst; rewrite /= in Hx.
        + by smt().
        + (* i1=0, j>0: x in nn_i0+tree *)
          by smt(FMap.mem_join f_big_union_mem_nth size_map size_takel).
        + (* i1>0, j=0: x in stash/take, need x \notin nn_i0+tree *)
          by smt(FMap.mem_join f_big_union_mem_nth size_map size_takel).
        + (* i1>0, j>0 *)
          have /= := Hdisj i1 j _ _ _ x; 1,2,3: by smt().
          by smt(nth_cat size_map size_takel).

    wp.
    (* fetch loop *)
    while{1} (
        0 <= i0{1} <= h + 1
     /\ map t_varinfo2value tree{1}
      + map b_varinfo2value stash{1}
      = RAM.mem{2}
     /\ f_big_disjoint
          [map t_varinfo2value tree{1}; map b_varinfo2value stash{1}]
     /\ (v{1} \in oram{1} =>
              p0{1} = (oget oram{1}.[v{1}]).`path
           /\ ((oget oram{1}.[v{1}]).`odepth <> None
                /\ i0{1} <= of_depth (oget (oget oram{1}.[v{1}]).`odepth)
                => oram{1}.[v{1}] = omap t2varinfo tree{1}.[v{1}])
           /\ (of_depth (oget (oget oram{1}.[v{1}]).`odepth) < i0{1}
                \/ (oget oram{1}.[v{1}]).`odepth = None
                => !(v{1} \in tree{1})))
     /\ (!(v{1} \in oram{1}) => !(v{1} \in tree{1}))
    ) (h + 1 - i0{1}).
    + move => &m z.
      auto => |> &hr *; do split; 1,2,7: by smt().
      + by smt(fetch_values).
      + by smt(fetch_disjoint).
      + (* v \in oram => path, tree correspondence, and v \notin tree' *)
        move => Hvin; do split; first by smt().
        - (* odepth<>None => i0+1 <= depth => oram.[v] = omap t2varinfo tree'.[v] *)
          move => Hge Hge' @/fetch @/fetch_stash /=.
          rewrite get_filter -1:/# mem_filter /=; split; first by smt().
          rewrite &(contra_congr Node.size) /node_of_t_varinfo /node_at_depth.
          rewrite /Node.size !to_nodedK size_takel 1,2,3,4,5:#smt:(of_depthP of_pathP).
          rewrite to_depthdK 1:/# size_takel 1:#smt:(of_pathP) /#.
        - (* depth < i0+1 => v \notin tree' *)
          move => Hlt @/fetch @/fetch_stash /=.
          rewrite mem_filter /= negb_and.
          case (of_depth (oget (oget oram{hr}.[v{hr}]).`odepth) < i0{hr}) => Hlt'.
          + (* depth < i0: v already not in tree *)
            by left; smt().
          + (* depth = i0 or odepth = None *)
            case ((oget oram{hr}.[v{hr}]).`odepth = None) => Hodepth.
            - (* odepth = None => v \notin tree *)
              by left; smt().
            - (* odepth <> None, depth = i0: v's node is being fetched *)
              by right => /=; smt(of_depthK).
      + (* v \notin oram => v \notin tree' *)
        move => Hvnin @/fetch @/fetch_stash /=.
        by smt(mem_filter).
    auto => |> &1 &2 *.
    split.
    + do split.
      + by smt(gt0_h).
      + exact (oram_split_values o{1}).
      + by smt(mem_map mem_filter).
      + (* v ∈ oram => p0 = path /\ (0 <= depth => oram.[v] = omap t2varinfo tree_init.[v]) /\ ... *)
        move => Hvin; do split.
        - by smt(domE oget_some).
        - (* oram.[v] = omap t2varinfo tree_init.[v] *)
          move => Hodepth _.
          have [vi Hvi] : exists vi, o{1}.[varV p.[i{2}]] = Some vi by smt(domE).
          have Hod : vi.`odepth <> None by smt(oget_some).
          rewrite mapE FMap.filterE Hvi /= Hod /= /t2varinfo /varinfo2t /=.
          by smt(some_oget).
        - by smt(of_depthP mem_map mem_filter).
      + by smt(mem_map mem_filter).
    + move => i0_L stash_L tree_L; split; first by smt().
      move => Hi0L_h Hi0L_lo Hi0L_hi Hmem ? Hvin_inv Hvnin_inv.
      split => HisWt_case.
      * (* isWt branch — vacuous since instruction is Rd *)
        by smt().
      * (* !isWt branch — real case *)
        split.
        + (* Eviction loop init *)
          split; first by smt(gt0_h).
          split; first by smt(assign_length).
          rewrite take_oversize; first by smt(assign_length).
          split.
          - (* value equality *)
            rewrite !f_big_union_cons -(assign_values_partition) map_set.
            rewrite -fmap_eqP => v.
            rewrite joinE.
            case (v = varV p.[i{2}]) => Hv.
            + rewrite mem_set Hv /= get_setE /=.
              rewrite /b_varinfo2value /varinfo2value /= mapE /=.
              (* Need v \in o to show o.[v] = Some vi *)
              have Hvin : varV p.[i{2}] \in o{1} by smt(mem_map).
              by smt(domE oget_some).
            + (* v <> varV p.[i{2}]: the set doesn't affect v *)
              by rewrite mem_set Hv /= get_setE Hv /= #smt:(joinE).
          - (* disjointness + assign_path *)
            have Hvnin_tree : varV p.[i{2}] \notin tree_L.
            + case (varV p.[i{2}] \in o{1}) => Hvin.
              - have [_ [_ H3]] := Hvin_inv Hvin.
                by apply H3; left; smt(of_depthP gt0_h).
              - by exact (Hvnin_inv Hvin).
            split.
            + by apply eviction_init_disjoint; smt(mem_map).
            + move => j Hj1 Hj2; apply assign_path; smt().
        + (* Eviction loop → final *)
          move => i0_L0 tree_L'; split; first by smt().
          move => Hi0neg Hi0lo Hi0hi Hsz Hval Hdisj _.
          have Hi0eq : i0_L0 = -1 by smt().
          subst i0_L0.
          move: Hval Hdisj => /= Hval Hdisj.
          split; first by smt().
          split.
          - (* return value: varV (Rd v) = v, so both sides equal *)
            have -> : varV p.[i{2}] = v{2} by smt().
            by rewrite mapE /varinfo2value /=.
          - (* oram reconstruction *)
            by smt(oram_reconstruct_values take_le0 f_big_union_nil join0r).

  + (* write *)
    wp 15 2.
    (* eviction loop: processes i0 from h down to -1 *)
    while{1} (
          -1 <= i0{1} <= h
       /\ size newnodes{1} = h + 1
       /\ (f_big_union (
                (map t_varinfo2value tree{1})
             :: (map b_varinfo2value stash{1})
             :: (map (fun blocks => map b_varinfo2value blocks)
                            (take (i0{1} + 1) newnodes{1}))))
         = RAM.mem{2}
       /\ f_big_disjoint (
               (map t_varinfo2value tree{1})
            :: (map b_varinfo2value stash{1})
            :: (map (fun blocks => map b_varinfo2value blocks)
                                       (take (i0{1} + 1) newnodes{1}))
          )
       /\ (forall j, 0 <= j <= h =>
             all (fun (_ : vars) (bvi : b_varinfo) =>
               node_is_on_path (node_at_depth p0{1} (to_depthd j)) bvi.`b_path)
               newnodes{1}.[j])
    ) (i0{1} + 1).
    + move => &m z.
      auto => |> &hr Hi0lo Hi0hi Hsz Hdisj0 Hvalid Hguard.
      rewrite (setblocks_values _ _ _ (Hvalid i0{hr} _)) 1:/#.
      have Htake := take_succ_snoc newnodes{hr} i0{hr} _; 1: by smt().
      move: Hdisj0; rewrite !Htake map_cat map1 => Hdisj0.
      split; 2: by smt().
      split; 1: by smt().
      (* Remaining: value_eq /\ disjointness *)
      move : Hdisj0 => ^Hdisj'.
      rewrite {1}/f_big_disjoint /= size_cat /= size_map size_takel 1:/# => Hdisj.

      have ? : forall v, v \notin (map t_varinfo2value tree{hr}) \/ v \notin (map b_varinfo2value stash{hr}).
      + by move => v; have /= /# := Hdisj 0 1.

      have ? : forall v, v \notin (map t_varinfo2value tree{hr}) \/ v \notin (map b_varinfo2value newnodes{hr}.[i0{hr}]).
      + move => v; have /= := Hdisj 0 (2 + i0{hr}). by rewrite nth_cat size_map size_takel /#.

      have ? : forall v, v \notin (map t_varinfo2value tree{hr}) \/ v \notin (f_big_union (map (map b_varinfo2value) (take i0{hr} newnodes{hr}))).
      + move => v; case (v \in map t_varinfo2value tree{hr}) => // Hv.
        right; have := f_big_union_notin_head _ _ v Hdisj' Hv.
        by rewrite f_big_union_cons mem_join f_big_union_cat f_big_union_cons f_big_union_nil join0r mem_join; smt().

      have ? : forall v, v \notin (map b_varinfo2value stash{hr}) \/ v \notin (map b_varinfo2value newnodes{hr}.[i0{hr}]).
      + move => v; have /= := Hdisj 1 (2 + i0{hr}). by rewrite nth_cat size_map size_takel /#.

      have ? : forall v, v \notin (map b_varinfo2value stash{hr}) \/ v \notin (f_big_union (map (map b_varinfo2value) (take i0{hr} newnodes{hr}))).
      + move => v; case (v \in map b_varinfo2value stash{hr}) => // Hv.
        right; have := f_big_union_notin_head _ _ v (f_big_disjoint_cons _ _ Hdisj') Hv.
        by rewrite f_big_union_cat f_big_union_cons f_big_union_nil join0r mem_join; smt().

      have ? : forall v, v \notin (map b_varinfo2value newnodes{hr}.[i0{hr}]) \/ v \notin (f_big_union (map (map b_varinfo2value) (take i0{hr} newnodes{hr}))).
      + move => v; case (v \in map b_varinfo2value newnodes{hr}.[i0{hr}]) => // Hv.
        right; have Hd2 := f_big_disjoint_cons _ _ (f_big_disjoint_cons _ _ Hdisj').
        have Hd2p : f_big_disjoint (map b_varinfo2value newnodes{hr}.[i0{hr}] :: map (map b_varinfo2value) (take i0{hr} newnodes{hr})).
        + rewrite -(cat1s (map b_varinfo2value newnodes{hr}.[i0{hr}])) (f_big_disjoint_perm_eq _ (map (map b_varinfo2value) (take i0{hr} newnodes{hr}) ++ [map b_varinfo2value newnodes{hr}.[i0{hr}]])); first by smt(perm_catC).
          exact Hd2.
        exact (f_big_union_notin_head _ _ v Hd2p Hv).

      pose S := map b_varinfo2value stash{hr}.
      pose NN := map (map b_varinfo2value) (take i0{hr} newnodes{hr}).
      pose NNI := map b_varinfo2value newnodes{hr}.[i0{hr}].
      pose T := map t_varinfo2value tree{hr}.

      split.
      + by smt(joinA f_big_union_cons f_big_union2 cat11 f_big_union_cat
               f_big_union1 joinC FMap.mem_join).
      + rewrite /f_big_disjoint /= size_map size_takel 1:/#.
        move => i1 j Hi1 Hj Hne x Hx.
        case: (i1 = 0) => Hi10; case: (j = 0) => Hj0; subst; rewrite /= in Hx.
        + by smt().
         + (* i1=0, j>0: x in nn_i0+tree *)
          by smt(FMap.mem_join f_big_union_mem_nth size_map size_takel).
        + (* i1>0, j=0: x in stash/take, need x \notin nn_i0+tree *)
          by smt(FMap.mem_join f_big_union_mem_nth size_map size_takel).
        + (* i1>0, j>0 *)
          have /= := Hdisj i1 j _ _ _ x; 1,2,3: by smt().
          by smt(nth_cat size_map size_takel).

    wp.
    (* fetch loop *)
    while{1} (
        0 <= i0{1} <= h + 1
     /\ map t_varinfo2value tree{1}
      + map b_varinfo2value stash{1}
      = RAM.mem{2}
     /\ f_big_disjoint
          [map t_varinfo2value tree{1}; map b_varinfo2value stash{1}]
     /\ (v{1} \in oram{1} =>
              p0{1} = (oget oram{1}.[v{1}]).`path
           /\ ((oget oram{1}.[v{1}]).`odepth <> None
                /\ i0{1} <= of_depth (oget (oget oram{1}.[v{1}]).`odepth)
                => oram{1}.[v{1}] = omap t2varinfo tree{1}.[v{1}])
           /\ (of_depth (oget (oget oram{1}.[v{1}]).`odepth) < i0{1}
                \/ (oget oram{1}.[v{1}]).`odepth = None
                => !(v{1} \in tree{1})))
     /\ (!(v{1} \in oram{1}) => !(v{1} \in tree{1}))
    ) (h + 1 - i0{1}).
    + move => &m z.
      auto => |> &hr *; do split; 1,2,7: by smt().
      + by smt(fetch_values).
      + by smt(fetch_disjoint).
      + move => Hvin; do split; first by smt().
        - (* odepth<>None => i0+1 <= depth => oram.[v] = omap t2varinfo tree'.[v] *)
          move => Hge Hge' @/fetch @/fetch_stash /=.
          rewrite get_filter -1:/# mem_filter /=; split; first by smt().
          rewrite &(contra_congr Node.size) /node_of_t_varinfo /node_at_depth.
          rewrite /Node.size !to_nodedK size_takel 1,2,3,4,5:#smt:(of_depthP of_pathP).
          rewrite to_depthdK 1:/# size_takel 1:#smt:(of_pathP) /#.
        - (* depth < i0+1 => v \notin tree' *)
          move => Hlt @/fetch @/fetch_stash /=.
          rewrite mem_filter /= negb_and.
          case (of_depth (oget (oget oram{hr}.[v{hr}]).`odepth) < i0{hr}) => Hlt'.
          + (* depth < i0: v already not in tree *)
            by left; smt().
          + (* depth = i0 or odepth = None *)
            case ((oget oram{hr}.[v{hr}]).`odepth = None) => Hodepth.
            - (* odepth = None => v \notin tree *)
              by left; smt().
            - (* odepth <> None, depth = i0: v's node is being fetched *)
              (* TODO: try to understand why of_depthK is enough. *)
              by right => /=; smt(of_depthK).
      + by move => Hvnin @/fetch @/fetch_stash /=; smt(mem_filter).
    auto => |> &1 &2 *.
    split.
    + do split.
      + by smt(gt0_h).
      + exact (oram_split_values o{1}).
      + by smt(mem_map mem_filter).
      + move => Hvin; do ! split.
        - by smt(domE oget_some).
        - move => Hodepth _.
          have [vi Hvi] : exists vi, o{1}.[varV p.[i{2}]] = Some vi by smt(domE).
          have Hod : vi.`odepth <> None by smt(oget_some).
          rewrite mapE FMap.filterE Hvi /= Hod /= /t2varinfo /varinfo2t /=.
          by smt(some_oget).
        - by smt(of_depthP mem_map mem_filter).
      + by smt(mem_map mem_filter).
    + move => i0_L stash_L tree_L; split; first by smt().
      move => Hi0L_h Hi0L_lo Hi0L_hi Hmem ? Hvin_inv Hvnin_inv.
      split => HisWt_case.
      * (* isWt branch — real case for Wt *)
        have Hvnin_tree : !(varV p.[i{2}] \in tree_L).
        + case (varV p.[i{2}] \in o{1}) => Hvin.
          - have [_ [_ H3]] := Hvin_inv Hvin.
            by apply H3; left; smt(of_depthP gt0_h).
          - by exact (Hvnin_inv Hvin).
        split.
        + (* Eviction loop init *)
          split; first by smt(gt0_h).
          split; first by smt(assign_length).
          rewrite take_oversize; first by smt(assign_length).
          split.
          - (* value equality *)
            rewrite !f_big_union_cons.
            rewrite -(assign_values_partition) map_set -Hmem.
            (* tv + bv.[v <- val] = (tv + bv).[v <- val] when v \notin tv *)
            have Hvnin_tv : !(varV p.[i{2}] \in map t_varinfo2value tree_L)
              by smt(mem_map).
            have Hv_eq : varV p.[i{2}] = t{2}.`1 by smt().
            have Hval_eq : oget (valV p.[i{2}]) = t{2}.`2 by smt().
            rewrite -fmap_eqP => w.
            rewrite !joinE !get_setE !mem_set.
            case (w = varV p.[i{2}]) => Hw /=.
            + by rewrite /b_varinfo2value /= Hval_eq -Hv_eq Hw.
            + by rewrite -Hv_eq Hw /= joinE.
          - (* disjointness + assign_path *)
            split.
            + by apply eviction_init_disjoint; smt(mem_map).
            + move => j Hj1 Hj2; apply assign_path; smt().
        + (* Eviction loop → final *)
          move => i0_L0 tree_L'; split; first by smt().
          move => Hi0neg Hi0lo Hi0hi Hsz Hval Hdisj _.
          have Hi0eq : i0_L0 = -1 by smt().
          subst i0_L0.
          move: Hval Hdisj; rewrite (_: (-1) + 1 = 0) 1:/# /= => Hval Hdisj.
          split; first by smt().
          split.
          - (* return value *)
            smt(get_setE mapE mem_map).
          - (* oram reconstruction + domain tracking *)
            rewrite oram_reconstruct_values.
            smt(get_setE mapE mem_map mem_set take_le0 f_big_union_nil join0r).
      * (* !isWt branch — vacuous since instruction is Wt *)
        by smt().
auto => />; split.
+ exact List.size_ge0.
+ split; first by rewrite map_empty.
  by smt().
qed.

op expandl(ap : sleakage) : leakage =
      map (fun i => (Write, node_at_depth ap (to_depthd i))) (iota_ 0 (h+1))
   ++ map (fun i => (Read, node_at_depth ap (to_depthd i))) (rev (iota_ 0 (h+1))).

op lsim(al : sleakage list) : leakage list =
        (map expandl al).

(* ================================================================ *)
(* Path-level lemmas: derived from b_varinfo-level via              *)
(* map b_varinfo2path (same pattern as value-level)                 *)
(* ================================================================ *)

op varinfo2path (v : vars) (vi : varinfo) : path = vi.`path.

op t_varinfo2path (v : vars) (t_vi : t_varinfo) : path = t_vi.`t_path.

op b_varinfo2path (v : vars) (b_vi : b_varinfo) : path = b_vi.`b_path.

lemma tp2p_eq_bp2p_t2b (v : vars) (t_vi : t_varinfo) :
  t_varinfo2path v t_vi = b_varinfo2path v (t2b_varinfo t_vi).
proof. by rewrite /t_varinfo2path /b_varinfo2path /t2b_varinfo. qed.

lemma t_path_map_eq (t : tree) :
  map t_varinfo2path t = map b_varinfo2path (t2b_map t).
proof.
rewrite /t2b_map map_map -fmap_eqP => v; rewrite !mapE.
by case (t.[v]) => //= tvi; rewrite tp2p_eq_bp2p_t2b.
qed.

(* fetch preserves combined paths — corollary of fetch_t2b *)
lemma fetch_paths (s : blocks) (t : tree) (n : node) :
    map t_varinfo2path (fetch s t n).`2 + map b_varinfo2path (fetch s t n).`1
    = map t_varinfo2path t + map b_varinfo2path s.
proof.
rewrite !t_path_map_eq -!map_join; congr.
exact (fetch_t2b s t n).
qed.

(* fetch preserves path disjointness — corollary of fetch_t2b_disjoint *)
lemma fetch_paths_disjoint (s : blocks) (t : tree) (n : node) :
    f_big_disjoint [map t_varinfo2path t; map b_varinfo2path s] =>
    f_big_disjoint [map t_varinfo2path (fetch s t n).`2;
                    map b_varinfo2path (fetch s t n).`1].
proof.
rewrite !t_path_map_eq /f_big_disjoint /= => Hdisj.
have := fetch_t2b_disjoint s t n _.
+ by rewrite /f_big_disjoint /=; smt(mem_map).
by rewrite /f_big_disjoint /=; smt(mem_map).
qed.

(* setblocks paths decomposition — corollary of setblocks_t2b *)
lemma setblocks_paths (t : tree) (n : node) (bs : blocks) :
  all (fun (_ : vars) (b_vi : b_varinfo) => node_is_on_path n b_vi.`b_path) bs =>
  map t_varinfo2path (setblocks t n bs) = map b_varinfo2path bs + map t_varinfo2path t.
proof.
by move => Hvalid; rewrite !t_path_map_eq -map_join setblocks_t2b.
qed.

(* oram split preserves paths — corollary of oram_split_t2b *)
lemma oram_split_paths (o : oram) :
  map t_varinfo2path
    (map (fun (_ : vars) (vi : varinfo) => varinfo2t vi)
       (filter (fun (_ : vars) (vi : varinfo) => vi.`odepth <> None) o))
  + map b_varinfo2path
      (map (fun (_ : vars) (vi : varinfo) => varinfo2b vi)
         (filter (fun (_ : vars) (vi : varinfo) => vi.`odepth = None) o))
  = map varinfo2path o.
proof.
rewrite t_path_map_eq -map_join oram_split_t2b.
rewrite -fmap_eqP => v; rewrite !mapE.
by case (o.[v]) => //= vi; rewrite /b_varinfo2path /varinfo2b /varinfo2path.
qed.

(* assign preserves path union *)
lemma assign_paths_partition (s : blocks) (p : path) :
  map b_varinfo2path s =
  map b_varinfo2path (assign s p).`2
    + f_big_union (List.map (map b_varinfo2path) (assign s p).`1).
proof.
rewrite -map_f_big_union -map_join; congr.
smt(assign_partition f_big_union_cons f_big_union_nil join0r).
qed.

(* assign preserves path disjointness *)
lemma assign_paths_disjoint (s : blocks) (p : path) :
    f_big_disjoint (
      map b_varinfo2path (assign s p).`2 ::
      List.map (map b_varinfo2path) (assign s p).`1).
proof.
have Hdisj : f_big_disjoint ((assign s p).`2 :: (assign s p).`1)
  by smt(assign_disjoint).
rewrite /f_big_disjoint /= size_map => i j Hi Hj Hne x.
case (i = 0) => Hi0; case (j = 0) => Hj0; subst => /=.
+ by smt().
+ rewrite (nth_map empty) 1:/#; smt(mem_map).
+ rewrite (nth_map empty) 1:/#; smt(mem_map).
+ rewrite !(nth_map empty) 1:/# 1:/#; smt(mem_map).
qed.

(* reconstructing oram from tree+stash preserves paths *)
lemma oram_reconstruct_paths (t : tree) (s : blocks) :
  map varinfo2path
    (map (fun (_ : vars) (t_vi : t_varinfo) => t2varinfo t_vi) t
   + map (fun (_ : vars) (b_vi : b_varinfo) => b2varinfo b_vi) s)
  = map t_varinfo2path t + map b_varinfo2path s.
proof.
rewrite -fmap_eqP => v; rewrite joinE mapE !mem_map joinE !mem_map.
case (v \in s) => Hs.
+ have [bvi Hbvi] : exists bvi, s.[v] = Some bvi by smt(domE).
  rewrite /= !mapE Hbvi /=.
  by rewrite /varinfo2path /b2varinfo /b_varinfo2path.
+ case (v \in t) => Ht.
  - have [tvi Htvi] : exists tvi, t.[v] = Some tvi by smt(domE).
    rewrite !mapE Htvi /= /varinfo2path /t2varinfo /t_varinfo2path //.
  - have Ht' : t.[v] = None by smt(domE).
    by rewrite !mapE Ht'.
qed.

(* Path-level version of eviction_init_disjoint *)
lemma eviction_init_disjoint_paths (tp : (vars, path) fmap) (s : blocks)
    (v : vars) (bvi : b_varinfo) (p0 : path) :
    f_big_disjoint [tp; map b_varinfo2path s] =>
    !(v \in tp) =>
    f_big_disjoint (tp
      :: map b_varinfo2path (assign (s.[v <- bvi]) p0).`2
      :: List.map (map b_varinfo2path) (assign (s.[v <- bvi]) p0).`1).
proof.
move => Hdisj Hvnin.
have Htv_s_set : forall x, x \in tp => !(x \in map b_varinfo2path (s.[v <- bvi])).
+ move => x Hx; rewrite mem_map mem_set.
  by have /= := Hdisj 0 1 _ _ _ x; smt(mem_map).
have Hassign_disj := assign_paths_disjoint (s.[v <- bvi]) p0.
rewrite /f_big_disjoint /= size_map => i j Hi Hj Hne x Hx.
case (i = 0) => Hi0; last case (j = 0) => Hj0.
+ subst; move: Hx => /= Hx.
  have Hxns : !(x \in map b_varinfo2path (s.[v <- bvi]))
    by exact (Htv_s_set x Hx).
  have Hxpart := assign_paths_partition (s.[v <- bvi]) p0.
  case (j = 1) => Hj1; subst => /=.
  - by smt(mem_map mem_join).
  - have Hxnfu : !(x \in f_big_union (List.map (map b_varinfo2path) (assign (s.[v <- bvi]) p0).`1))
      by smt(mem_join).
    smt(f_big_union_notin_nth nth_map size_map).
+ subst; move: Hx.
  case (i = 1) => Hi1; subst => /=.
  - move => Hx.
    have : x \in map b_varinfo2path (s.[v <- bvi])
      by smt(assign_paths_partition mem_map mem_join).
    smt().
  - rewrite (nth_map empty) 1:/# => Hx.
    have Hxfu : x \in f_big_union (List.map (map b_varinfo2path) (assign (s.[v <- bvi]) p0).`1)
      by apply (f_big_union_mem_nth _ x (i-2)); smt(size_map nth_map).
    have Hxs : x \in map b_varinfo2path (s.[v <- bvi])
      by smt(mem_join assign_paths_partition).
    smt().
+ have /= := Hassign_disj (i-1) (j-1) _ _ _ x; smt(nth_map size_map mem_map).
qed.

lemma equiv_security_compile (p : prog) :
  equiv[ PathORAM.compile ~ SecurePathORAM.compile :
           arg{1} = p /\ arg{2} = p
             ==> PathORAM.leakages{1}
               = lsim SecurePathORAM.leakages{2}
       ].
proof.
proc.
  inline PathORAM.access SecurePathORAM.step.
  wp; sp.
  (* Main while loop coupling *)
  conseq (: _ ==>
    PathORAM.leakages{1} = map expandl SecurePathORAM.leakages{2}).
  while (
    PathORAM.leakages{1} = map expandl SecurePathORAM.leakages{2}
    /\ ={i, p}
    /\ map varinfo2path o{1} = posmap{2}
  ); last first.
  + auto => /> @/varinfo2path /=.
    by rewrite map_empty.
  inline PathORAM.access SecurePathORAM.step.
  (* Align deterministic assignments, then couple random samples *)
  sp 5 2.
  seq 1 1 : (#pre /\ ={rp}); first by auto.
  sp 1 1.
  seq 1 1 : (#pre /\ np{1} = newp{2}); first by auto.
  (* wp from end to consume trailing code on both sides *)
  wp 9 1.
  (* Eviction loop — only on left *)
  while{1} (
       -1 <= i0{1} <= h
    /\ p0{1} = ap{2}
    /\ size newnodes{1} = h + 1
    /\ opleak{1} = map (fun j => (Write, node_at_depth p0{1} (to_depthd j)))
                        (iota_ (i0{1} + 1) (h - i0{1}))
                ++ map (fun j => (Read, node_at_depth p0{1} (to_depthd j)))
                        (rev (iota_ 0 (h + 1)))
    /\ (f_big_union (
                (map t_varinfo2path tree{1})
             :: (map b_varinfo2path stash{1})
             :: (map (fun blocks => map b_varinfo2path blocks)
                            (take (i0{1} + 1) newnodes{1}))))
         = posmap0{2}
    /\ f_big_disjoint (
            (map t_varinfo2path tree{1})
         :: (map b_varinfo2path stash{1})
         :: (map (fun blocks => map b_varinfo2path blocks)
                                    (take (i0{1} + 1) newnodes{1})))
    /\ (forall j, 0 <= j <= h =>
          all (fun (_ : vars) (bvi : b_varinfo) =>
            node_is_on_path (node_at_depth p0{1} (to_depthd j)) bvi.`b_path)
            newnodes{1}.[j])
  ) (i0{1} + 1).
  + move => &m0 z.
    auto => |> &hr Hi0lo Hi0hi Hsz Hdisj0 Hvalid Hguard.
    rewrite (setblocks_paths _ _ _ (Hvalid i0{hr} _)) 1:/#.
    have Htake := take_succ_snoc newnodes{hr} i0{hr} _; 1: by smt().
    move: Hdisj0; rewrite !Htake map_cat map1 => Hdisj0.
    split; last by smt().
    split; first by smt().
    split.
    (* opleak *)
    + have -> : iota_ i0{hr} (h - (i0{hr} - 1)) = i0{hr} :: iota_ (i0{hr} + 1) (h - i0{hr}).
      + by rewrite (_ : h - (i0{hr} - 1) = (h - i0{hr}) + 1) 1:/# iotaS 1:/#.
      by smt(cat_cons).
    (* path equality and disjointness *)
    move : Hdisj0 => ^Hdisj'.
    rewrite {1}/f_big_disjoint /= size_cat /= size_map size_takel 1:/# => Hdisj.
    have ? : forall v, v \notin (map t_varinfo2path tree{hr}) \/ v \notin (map b_varinfo2path stash{hr}).
    + by move => v; have /= /# := Hdisj 0 1.
    have ? : forall v, v \notin (map t_varinfo2path tree{hr}) \/ v \notin (map b_varinfo2path newnodes{hr}.[i0{hr}]).
    + move => v; have /= := Hdisj 0 (2 + i0{hr}). by rewrite nth_cat size_map size_takel /#.
    have ? : forall v, v \notin (map t_varinfo2path tree{hr}) \/ v \notin (f_big_union (map (map b_varinfo2path) (take i0{hr} newnodes{hr}))).
    + move => v; case (v \in map t_varinfo2path tree{hr}) => // Hv.
      right; have := f_big_union_notin_head _ _ v Hdisj' Hv.
      by rewrite f_big_union_cons mem_join f_big_union_cat f_big_union_cons f_big_union_nil join0r mem_join; smt().
    have ? : forall v, v \notin (map b_varinfo2path stash{hr}) \/ v \notin (map b_varinfo2path newnodes{hr}.[i0{hr}]).
    + move => v; have /= := Hdisj 1 (2 + i0{hr}). by rewrite nth_cat size_map size_takel /#.
    have ? : forall v, v \notin (map b_varinfo2path stash{hr}) \/ v \notin (f_big_union (map (map b_varinfo2path) (take i0{hr} newnodes{hr}))).
    + move => v; case (v \in map b_varinfo2path stash{hr}) => // Hv.
      right; have := f_big_union_notin_head _ _ v (f_big_disjoint_cons _ _ Hdisj') Hv.
      by rewrite f_big_union_cat f_big_union_cons f_big_union_nil join0r mem_join; smt().
    have ? : forall v, v \notin (map b_varinfo2path newnodes{hr}.[i0{hr}]) \/ v \notin (f_big_union (map (map b_varinfo2path) (take i0{hr} newnodes{hr}))).
    + move => v; case (v \in map b_varinfo2path newnodes{hr}.[i0{hr}]) => // Hv.
      right; have Hd2 := f_big_disjoint_cons _ _ (f_big_disjoint_cons _ _ Hdisj').
      have Hd2p : f_big_disjoint (map b_varinfo2path newnodes{hr}.[i0{hr}] :: map (map b_varinfo2path) (take i0{hr} newnodes{hr})).
      + rewrite -(cat1s (map b_varinfo2path newnodes{hr}.[i0{hr}])) (f_big_disjoint_perm_eq _ (map (map b_varinfo2path) (take i0{hr} newnodes{hr}) ++ [map b_varinfo2path newnodes{hr}.[i0{hr}]])); first by smt(perm_catC).
        exact Hd2.
      exact (f_big_union_notin_head _ _ v Hd2p Hv).
    pose S := map b_varinfo2path stash{hr}.
    pose NN := map (map b_varinfo2path) (take i0{hr} newnodes{hr}).
    pose NNI := map b_varinfo2path newnodes{hr}.[i0{hr}].
    pose T := map t_varinfo2path tree{hr}.
    split.
    + by smt(joinA f_big_union_cons f_big_union2 cat11 f_big_union_cat
             f_big_union1 joinC FMap.mem_join).
    + rewrite /f_big_disjoint /= size_map size_takel 1:/#.
      move => i1 j Hi1 Hj Hne x Hx.
      case: (i1 = 0) => Hi10; case: (j = 0) => Hj0; subst; rewrite /= in Hx.
      + by smt().
      + by smt(FMap.mem_join f_big_union_mem_nth size_map size_takel).
      + by smt(FMap.mem_join f_big_union_mem_nth size_map size_takel).
      + have /= := Hdisj i1 j _ _ _ x; 1,2,3: by smt().
        by smt(nth_cat size_map size_takel).
  wp.
  (* Read loop — only on left *)
  while{1} (
       0 <= i0{1} <= h + 1
    /\ p0{1} = ap{2}
    /\ np{1} = newp{2}
    /\ opleak{1} = map (fun j => (Read, node_at_depth p0{1} (to_depthd j)))
                        (rev (iota_ 0 i0{1}))
    /\ map t_varinfo2path tree{1} + map b_varinfo2path stash{1}
     = posmap0{2}
    /\ f_big_disjoint
         [(map t_varinfo2path tree{1}); (map b_varinfo2path stash{1})]
    /\ (v{1} \in oram{1} =>
             p0{1} = (oget oram{1}.[v{1}]).`path
          /\ ((oget oram{1}.[v{1}]).`odepth <> None
               /\ i0{1} <= of_depth (oget (oget oram{1}.[v{1}]).`odepth)
               => oram{1}.[v{1}] = omap t2varinfo tree{1}.[v{1}])
          /\ (of_depth (oget (oget oram{1}.[v{1}]).`odepth) < i0{1}
               \/ (oget oram{1}.[v{1}]).`odepth = None
               => !(v{1} \in tree{1})))
    /\ (!(v{1} \in oram{1}) => !(v{1} \in tree{1}))
  ) (h + 1 - i0{1}).
  + move => &m0 z.
    auto => |> &hr *.
    split; last by smt().
    split; first by smt().
    split.
    + have -> : iota_ 0 (i0{hr} + 1) = rcons (iota_ 0 i0{hr}) i0{hr}.
      + by rewrite iotaSr 1:/#.
      by smt(rev_rcons cat_cons).
    split; first by smt(fetch_paths).
    split; first by smt(fetch_paths_disjoint).
    split.
    + (* v \in oram => path, tree correspondence, and v \notin tree' *)
      move => Hvin; do split; first by smt().
      - (* odepth<>None => i0+1 <= depth => oram.[v] = omap t2varinfo tree'.[v] *)
        move => Hge Hge' @/fetch @/fetch_stash /=.
        rewrite get_filter -1:/# mem_filter /=; split; first by smt().
        rewrite &(contra_congr Node.size) /node_of_t_varinfo /node_at_depth.
        rewrite /Node.size !to_nodedK size_takel 1,2,3,4,5:#smt:(of_depthP of_pathP).
        rewrite to_depthdK 1:/# size_takel 1:#smt:(of_pathP) /#.
      - (* depth < i0+1 => v \notin tree' *)
        move => Hlt @/fetch @/fetch_stash /=.
        rewrite mem_filter /= negb_and.
        case (of_depth (oget (oget oram{hr}.[v{hr}]).`odepth) < i0{hr}) => Hlt'.
        + (* depth < i0: v already not in tree *)
          by left; smt().
        + (* depth = i0 or odepth = None *)
          case ((oget oram{hr}.[v{hr}]).`odepth = None) => Hodepth.
          - (* odepth = None => v \notin tree *)
            by left; smt().
          - (* odepth <> None, depth = i0: v's node is being fetched *)
            by right => /=; smt(of_depthK).
    + (* v \notin oram => v \notin tree' *)
      move => Hvnin @/fetch @/fetch_stash /=.
      by smt(mem_filter).
  (* Init and final *)
  have position_eq : forall (oo : oram) (vv : vars),
    position oo vv = (map varinfo2path oo).[vv].
  + by move => oo vv; rewrite /position mapE /varinfo2path.
  auto => |> &1 &2 *.
  split.
  + split; first by smt(gt0_h).
    split; first by smt().
    split; first by smt(iota0).
    split; first by exact (oram_split_paths o{1}).
    split; first by smt(mem_map mem_filter).
    split.
    + (* v ∈ oram => p0 = path /\ tree corr /\ v \notin tree *)
      move => Hvin; do split.
      - by smt(domE oget_some).
      - (* oram.[v] = omap t2varinfo tree_init.[v] *)
        move => Hodepth _.
        have := Hvin.
        rewrite domE -some_not_none.
        elim => vi Hvi.
        have Hod : vi.`odepth <> None by smt(oget_some).
        rewrite mapE FMap.filterE Hvi /= Hod /= /t2varinfo /varinfo2t /=.
        by smt(some_oget).
      - by smt(of_depthP mem_map mem_filter).
    + by smt(mem_map mem_filter).
  + move => i0_L stash_L tree_L.
    split; first by smt().
    move => Hi0L_h Hi0L_lo Hi0L_hi Hnp Hmem Hdisj Hvin_inv Hvnin_inv.
    (* Derive v \notin tree_L at exit (i0_L = h+1) *)
    have Hvnin_tree : !(varV p{!2}.[i{2}] \in tree_L).
    + case (varV p{!2}.[i{2}] \in o{1}) => Hvin.
      - have := Hvin_inv Hvin.
        move => [_ [_ Hvnt]]; apply Hvnt; left.
        by smt(of_depthP gt0_h).
      - by exact (Hvnin_inv Hvin).
    (* isWt/!isWt: both branches have identical path-level proofs *)
    split => HisWt.
    + (* isWt case *)
      split.
      - (* Eviction loop init *)
        split; first by smt(gt0_h).
        split; first by smt(assign_length).
        rewrite take_oversize; first by smt(assign_length).
        split.
        * (* opleak equality *)
          by smt(iota0).
        split.
        * (* path equality *)
          rewrite !f_big_union_cons -(assign_paths_partition) map_set -Hmem.
          rewrite -fmap_eqP => w.
          rewrite !joinE !get_setE !mem_set.
          case (w = varV p{!2}.[i{2}]) => Hw /=.
          + by rewrite /b_varinfo2path /=.
          + by rewrite joinE.
        * (* disjointness + assign_path *)
          split.
          + by apply eviction_init_disjoint_paths; smt(mem_map).
          + move => j Hj1 Hj2; apply assign_path; smt().
      - (* Eviction loop → final *)
        move => i0_L0 tree_L'.
        split; first by smt().
        move => Hi0neg Hi0lo Hi0hi Hsz Hval Hdisj' _.
        have Hi0eq : i0_L0 = -1 by smt().
        subst i0_L0.
        move: Hval Hdisj'; rewrite (_: (-1) + 1 = 0) 1:/# /= => Hval Hdisj'.
        split.
        * (* leakage *)
          by rewrite /expandl -position_eq; smt().
        * (* oram path reconstruction *)
          rewrite oram_reconstruct_paths.
          by smt(get_setE mapE mem_map mem_set take_le0 f_big_union_nil join0r).
    + (* !isWt case: same proof — b_value differs but b_varinfo2path only uses b_path *)
      split.
      - (* Eviction loop init *)
        split; first by smt(gt0_h).
        split; first by smt(assign_length).
        rewrite take_oversize; first by smt(assign_length).
        split.
        * (* opleak equality *)
          by smt(iota0).
        split.
        * (* path equality *)
          rewrite !f_big_union_cons -(assign_paths_partition) map_set -Hmem.
          rewrite -fmap_eqP => w.
          rewrite !joinE !get_setE !mem_set.
          case (w = varV p{!2}.[i{2}]) => Hw /=.
          + by rewrite /b_varinfo2path /=.
          + by rewrite joinE.
        split.
        * (* disjointness *)
          by apply eviction_init_disjoint_paths; smt(mem_map).
        * (* assign_path *)
          move => j Hj1 Hj2; apply assign_path; smt().
      - (* Eviction loop → final *)
        move => i0_L0 tree_L'.
        split; first by smt().
        move => Hi0neg Hi0lo Hi0hi Hsz Hval Hdisj' _.
        have Hi0eq : i0_L0 = -1 by smt().
        subst i0_L0.
        move: Hval Hdisj'; rewrite (_: (-1) + 1 = 0) 1:/# /= => Hval Hdisj'.
        split.
        * (* leakage *)
          by rewrite /expandl -position_eq; smt().
        * (* oram path reconstruction *)
          rewrite oram_reconstruct_paths.
          by smt(get_setE mapE mem_map mem_set take_le0 f_big_union_nil join0r).
qed.
