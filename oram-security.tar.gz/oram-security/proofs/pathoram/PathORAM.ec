require import AllCore List FMap SmtMap IntDiv IntMin.

require import Aux.
(*---*) import ListUtils FMapUtils.

require import ORAM.
(*---*) import UniPath.

(* ==================================================================== *)
type varinfo = { path : path ; odepth : depth option ; value : value; }.

type oram = (vars, varinfo) fmap.

type t_varinfo = { t_path : path ; t_depth : depth ; t_value : value; }.

type tree = (vars, t_varinfo) fmap.

type b_varinfo = { b_path : path ; b_value : value }.

type blocks = (vars, b_varinfo) fmap.

(* ==================================================================== *)
(* Transforming APIs for different kinds of varinfo *)

op node_of_t_varinfo (t_vi : t_varinfo) : node =
  to_noded (take (of_depth t_vi.`t_depth) (of_path t_vi.`t_path)).

op t2b_varinfo (t_vi : t_varinfo) : b_varinfo =
  {| b_path = t_vi.`t_path; b_value = t_vi.`t_value |}.

op varinfo2t (vi : varinfo) : t_varinfo =
  {| t_path = vi.`path; t_depth = oget vi.`odepth; t_value = vi.`value |}.

op varinfo2b (vi : varinfo) : b_varinfo =
  {| b_path = vi.`path; b_value = vi.`value |}.

op t2varinfo (t_vi : t_varinfo) : varinfo =
  {| path = t_vi.`t_path; odepth = Some t_vi.`t_depth; value = t_vi.`t_value |}.

op b2varinfo (b_vi : b_varinfo) : varinfo =
  {| path = b_vi.`b_path; odepth = None; value = b_vi.`b_value |}.

(* ==================================================================== *)
(* Tree-based APIs *)

(* The assign operator is non-deterministic and axiomized. *)
op assign (s : blocks) (p : path) : blocks list * blocks.

(* assign produces h+1 buckets *)
axiom assign_length (s : blocks) (p : path) :
  size (assign s p).`1 = h + 1.

(* assign preserves the union *)
axiom assign_partition (s : blocks) (p : path) :
  let (newnodes, newstash) = assign s p in
    f_big_union [s] = f_big_union (newstash :: newnodes).

(* assign preserves disjointness *)
axiom assign_disjoint (s : blocks) (p : path) :
  let (newnodes, newstash) = assign s p in
    f_big_disjoint (newstash :: newnodes).

(* assign respects the eviction path and the position of each block *)
axiom assign_path (s : blocks) (p : path) (i : int) :
  0 <= i <= h =>
  all (fun (_ : vars) (b_vi : b_varinfo) =>
    node_is_on_path (node_at_depth p (to_depthd i)) b_vi.`b_path)
    (assign s p).`1.[i].

axiom assign_farthest (s : blocks) (p : path) (i : int) :
  0 <= i <= h =>
  all
    (fun (_ : vars) (b_vi : b_varinfo) =>
      forall j, i < j <= h =>
        node_is_on_path
          (node_at_depth p (to_depthd j))
          b_vi.`b_path =>
        fsize (assign s p).`1.[j] = K)
    (assign s p).`1.[i].

op setblocks (t : tree) (n : node) (bs : blocks) : tree =
  if (all (fun (_, b_vi) => node_is_on_path n b_vi.`b_path) bs) then
    FMap.map
      (fun (_, b_vi) => {| t_path = b_vi.`b_path;
                           t_depth = depth_of_node n;
                           t_value = b_vi.`b_value |})
      bs
    + t
  else witness.

op position (o : oram) (v : vars) : path option =
  omap path o.[v].

op fetch_stash (s : blocks) (t : tree) (n : node) : blocks =
  FMap.map
    (fun (_, t_vi) => t2b_varinfo t_vi)
    (FMap.filter (fun (_, t_vi) => node_of_t_varinfo t_vi = n) t)
  + s.

(* fetch: move blocks at node n from tree to stash (removing from tree) *)
op fetch (s : blocks) (t : tree) (n : node) : blocks * tree =
  (fetch_stash s t n,
   FMap.filter (fun (_, t_vi) => node_of_t_varinfo t_vi <> n) t).

module PathORAM = {
  var leakages : leakage list
  var os       : oram list

  proc get_leakages() = { return leakages; }

  proc access(oram : oram, inst : inst) : oram * value = {
    var v         : vars;
    var i         : int;
    var n         : node;
    var p, rp, np : path;
    var data      : value;
    var opleak    : leakage;
    var stash     : blocks;
    var tree      : tree;
    var newnodes  : blocks list;

    tree  <- FMap.map
               (fun (_, vi) => varinfo2t vi)
               (FMap.filter (fun (_, vi) => vi.`odepth <> None) oram);
    stash <- FMap.map
               (fun (_, vi) => varinfo2b vi)
               (FMap.filter (fun (_, vi) => vi.`odepth = None) oram);
    v <- varV inst;

    (* Fetch the position, sample if there is no position. *)
    (* line 1: x <- position[a] *)
    rp   <$ dunipath;
    p    <- odflt rp (position oram v);

    (* line 2: position[a] = x* <- UniformRandom(0...2^L) *)
    np <$ dunipath;

    (* lines 3-5: for l in {0,...,L}, S <- S U ReadBucket(P(x,l)) *)
    opleak <- [];
    i <- 0;

    while (i <= h) {
      n             <- node_at_depth p (to_depthd i);
      (stash, tree) <- fetch stash tree n;
      opleak        <- (Read, n) :: opleak;
      i             <- i + 1;
    }

    (* lines 6-9: data <- Read block a from S *)
    data <- oget (omap value oram.[v]);

    (* lines 7-9: if op = write then update stash *)
    if (isWt inst) {
      data <- oget (valV inst);
    }

    (* This is a mix of line 2 and line 8, as we simplified position map. *)
    (* update stash: remove old entry, add with new path and data *)
    stash <- stash.[v <- {| b_path = np ; b_value = data |}];

    (* lines 10-15: eviction from leaf to root *)
    (newnodes, stash) <- assign stash p;
    i <- h;
    while (0 <= i) {
      n          <- node_at_depth p (to_depthd i);
      tree       <- setblocks tree n newnodes.[i];
      opleak     <- (Write, n) :: opleak;
      i          <- i - 1;
    }

    leakages <- opleak :: leakages;

    oram <- FMap.map
              (fun (_, t_vi) => t2varinfo t_vi)
              tree
          + FMap.map
              (fun (_, b_vi) => b2varinfo b_vi)
              stash;

    return (oram, data);
  }

  proc compile(p : prog) : value list = {
    var i    : int;
    var o    : oram;
    var val  : value;
    var vs   : value list;

    leakages <- [];

    o  <- FMap.empty;
    vs <- [];
    os <- [];

    i <- 0;
    while (i < size p) {
      (o, val) <@ access(o, p.[i]);
      os <- o :: os;
      vs <- val :: vs;
      i  <- i + 1;
    }
    return vs;
  }
}.

(* ==================================================================== *)
(* bound for the overflow at stash *)
op R : int.

(* Check whether there is an overflow anywhere in the ORAM tree         *)
op overflow (o : oram) : bool =
  exists (n : node),
    R < fsize (filter (fun (_, vi) => vi.`odepth = None) o).

op toverflow (os : oram list) : bool =
  exists o, o \in os /\ overflow o.

axiom overflow_bound &m _p:
     Pr [ PathORAM.compile(_p) @ &m : toverflow PathORAM.os ]
  <= 14%r * 0.6 ^ R.
